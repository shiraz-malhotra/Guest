const {config} = require('./../config/serversetup');

const express=require('express');
var router=express.Router();

/* REST GET all request */

function initialSetup(name,columns){


    db.query("CREATE TABLE class_master(\
        class_id int NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),\
        class_name varchar(500) NOT NULL,\
        parent_class_id int,\
        status varchar(20),\
        PRIMARY KEY (class_id))", function (err, data) {
        if (err) logger.error(err);
        else logger.info({message:"class_master table created"});
    });

    db.query("CREATE TABLE attribute_master(\
        attribute_id int NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),\
        attribute_name varchar(500) NOT NULL,\
        class_id int,\
        status varchar(20),\
        mandatory varchar(1) check (mandatory in ('0', '1')),\
        PRIMARY KEY (attribute_id))", function (err, data) {
        if (err) logger.error(err);
        else logger.info({message:"class_master table created"});
    });

    db.query(`CREATE TABLE config_items(
        ci_id int NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
        ci_code varchar(20) NOT NULL,
        ci_name varchar(500) NOT NULL,
        class_id int NOT NULL,
        description VARCHAR(5000),
        company_id int NOT NULL,
        company_name varchar(500) NOT NULL,
        status varchar(10) NOT NULL,
        category_id int NOT NULL,
        sub_category_id int NOT NULL, 
        metallic varchar(500),
        environment varchar(500),
        group_id int NOT NULL, 
        group_name varchar(500) NOT NULL,
        owner_id int NOT NULL,
        owner_name varchar(500) NOT NULL,
        location_id int NOT NULL,
        location_name varchar(500) NOT NULL,
        manufacturer varchar(500),
        dataset varchar(500),
        support_company_id int NOT NULL,
        support_company_name varchar(500) NOT NULL,
        business_owner_id int NOT NULL,
        business_owner_name varchar(500) NOT NULL,
        technical_owner_id int NOT NULL,
        technical_owner_name varchar(500) NOT NULL,    
        created_by integer,
	    updated_by integer,
	    created_at bigint,
	    updated_at bigint,
        PRIMARY KEY (ci_id))`, function (err, data) {
            if (err) logger.error(err);
            else logger.info({message:"configuration_item table created"});
    });
    
    db.query("CREATE TABLE relationship_master(\
  		r_id int NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),\
  		r_name varchar(500) NOT NULL,\
  		status varchar(1) check(status in ('0','1')),\
  		PRIMARY KEY (r_id))", function (err, data) {
        if (err) logger.error(err);
        else logger.info({message:"relationship_master table created"});
    });

    db.query('create table ci_ci_relationship(\
	ci_ci_id int not null GENERATED ALWAYS AS IDENTITY(START WITH 1 INCREMENT BY 1),\
  	ci_id int not null,\
  	ci_id_related int not null,\
  	r_id int,\
  	created_at TIMESTAMP WITH DEFAULT CURRENT TIMESTAMP,\
    created_by varchar(50),\
    module varchar(500)\
  	PRIMARY KEY(ci_ci_id)\
)', function (err, data) {
        if (err) logger.error(err);
        else logger.info({message:"ci_ci_relationship table created"});
    });

    db.query('CREATE TABLE ci_attribute_mapping(\
        ci_id int NOT NULL,\
        attr_id int NOT NULL,\
        value varchar(500))', function (err, data) {
        if (err) logger.error(err);
        else logger.info({message:"ci_attribute_mapping table created"});
    });

    db.query("CREATE TABLE category_master(\
        category_id int NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),\
        category_name varchar(500 )NOT NULL,\
        status varchar(20) NOT NULL,\
        class_id int NOT NULL ,\
        PRIMARY KEY (category_id))", function (err, data) {
        if (err) logger.error(err);
        else logger.info({message:"category_master table created"});
    });

    db.query("CREATE TABLE sub_category_master(\
        sub_category_id int NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),\
        sub_category_name varchar(500 )NOT NULL,\
        status varchar(20) NOT NULL,\
        category_id int NOT NULL,\
        PRIMARY KEY (sub_category_id))", function (err, data) {
        if (err) logger.error(err);
        else logger.info({message:"category_master table created"});
    });

    db.query("CREATE TABLE category_master_v2(\
        category_id int NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),\
        category_name varchar(500 )NOT NULL,\
        sub_category_name varchar(500 )NOT NULL,\
        status varchar(20) NOT NULL,\
        class_id int NOT NULL ,\
        PRIMARY KEY (category_id))", function (err, data) {
        if (err) logger.error(err);
        else logger.info({message:"category_master table created"});
    });
}
router.get("/setup",function(req,res,next){
   initialSetup();
   res.status(200).json({message:"success"});
})

module.exports = router;

/**
 *

-- Enter SQL statements below or load a SQL script into the editor from the toolbar.
INSERT INTO category_master_v2(category_name,sub_category_name,status,class_id)
SELECT category_master.category_name,COALESCE(sub_category_name, '-') AS sub_category_name,category_master.status,category_master.class_id from category_master LEFT JOIN sub_category_master ON  category_master.category_id=sub_category_master.category_id

select category_id,category_name from category_master where category_id not in (select category_id from sub_category_master)

SELECT  category_master.category_id,category_master.category_name,sub_category_master.sub_category_name from category_master LEFT JOIN sub_category_master ON  category_master.category_id=sub_category_master.category_id
 */