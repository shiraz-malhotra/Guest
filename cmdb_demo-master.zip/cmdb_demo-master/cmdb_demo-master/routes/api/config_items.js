const {runQuery,epochToDateFormat,timeZoneCalc,dateFormatToEpoch,keysToBeSearchedInJWT,foundationApiCall} = require('./../../config/functions');

const {patch_call_cmdb_interface,checkIsExistInDb} = require('./../../config/functions');
const config  = require('./../../config/config.json');
const express=require('express');
const axios=require('axios');
var router=express.Router();
const _=require('lodash');
const moment=require('moment');
var datetime = require('node-datetime');

const CMDB_SNOW_INTEGRATION=(process.env.CMDB_SNOW_INTEGRATION||'no').toUpperCase();




console.log('CMDB_SNOW_INTEGRATION ',CMDB_SNOW_INTEGRATION)

/* code generator */
codeGeneratorMethod=(code,id) =>{
    var res=code;
    for(i=0;i<15-(code.length+id.toString().length);i++){
        res+='0';
    }
    res+=id.toString();
    return res;
} 

/**
 * Constant names  
 */


 const ci_code_prefix="ASTCI";

/* REST POST cmdb-spcm-interface request */
router.post("/cmdb-spcm-interface",async function(req,res,next){
 
    //  const attributes=_.pick(req.body,['attributes']).attributes;   
  
     // const attributes_query='INSERT INTO ci_attribute_mapping (ci_id,attr_id,value) values (?,?,?)';
     
  
      // if(attributes.length>0){        
      //    const reformattedArray = attributes.map(async function(obj) {        
      //     const result= await runQuery(attributes_query,[obj.ci_id,obj.attr_id,obj.value]);
      //         return result;
      //      });
      // }
  
  
      const constantQuery=`SELECT FIELD1_KEY,FIELD1_VALUE FROM MENULIST WHERE MODULE='SPCM_CMDB_INTERFACE'`;
  
      const constantQueryResult=await runQuery(constantQuery,[]);
  
      const statusArr={ Deployed:0,Suspended:0,Obsolete:0}
      let service_class_id=2,manufacturer_id=35;
      constantQueryResult.forEach((tempConstant)=>{              
          statusArr.Deployed=tempConstant.FIELD1_KEY=='Deployed'?tempConstant.FIELD1_VALUE:statusArr.Deployed;
          statusArr.Suspended=tempConstant.FIELD1_KEY=='Suspended'?tempConstant.FIELD1_VALUE:statusArr.Suspended;
          statusArr.Obsolete=tempConstant.FIELD1_KEY=='Obsolete'?tempConstant.FIELD1_VALUE:statusArr.Obsolete;
          service_class_id=tempConstant.FIELD1_KEY=='class_id'?tempConstant.FIELD1_VALUE:service_class_id;
          manufacturer_id=tempConstant.FIELD1_KEY=='manufacturer_id'?tempConstant.FIELD1_VALUE:manufacturer_id;
      })
  
  
      var body=_.pick(req.body,['ci_name','company_id','company_name','status',
                      'description','created_by','support_company_id','support_company_name',
                      'business_owner_id','business_owner_name', 'technical_owner_id','technical_owner_name',
              'editable','spcm_category_id','spcm_category_name','group_id','group_name','spcm_offering_id' ]); 
      body.ci_code="ci_code123";
      body.class_id=service_class_id;
      body.manufacturer=manufacturer_id;
      body.editable="N";
      body.CATEGORY_ID=0;
      body.SUB_CATEGORY_ID=0; 
      body.OWNER_ID=0;
      body.OWNER_NAME="";
      body.LOCATION_ID=0;
      body.LOCATION_NAME="";   
      body.status=statusArr[body.status]||0; 
  
      logger.info(`${req.ip} Config Item Post request for `,body);
      var valuesArr=[],keysArr=[],comma=[];
      for(key in body){
          keysArr.push(key);
          comma.push("?");
          valuesArr.push(body[key]);
      }
      keysArr.push('created_at');
      try{
          var executeQuery1 = "SELECT ci_id FROM FINAL TABLE (INSERT INTO config_items ("+keysArr.toString()+") values ("+comma.toString()+",CURRENT TIMESTAMP))";
          var data = await runQuery(executeQuery1,valuesArr);
          var new_ci_code=codeGeneratorMethod(ci_code_prefix,data[0].CI_ID);
          console.log(new_ci_code);
          var executeQuery2 = "SELECT * FROM FINAL TABLE (UPDATE config_items SET ci_code=? WHERE ci_id="+data[0].CI_ID+")";
          var idata = await runQuery(executeQuery2,[new_ci_code]);
          logger.info(`${req.ip} REST Post request completed for `,body); 
          res.status(200).json(idata[0]); 
  
      }catch(error){
          console.log("Error is : ",error);
          res.status(400).send("Error Occurred");
          return next(error);
      }
});


 /* REST patch cmdb-spcm-interface request */
 router.patch("/cmdb-spcm-interface/:id",async function(req,res,next){

    var id=req.params.id;      
    try {
  
   // const attributes=_.pick(req.body,['attributes']).attributes;  

  //  const attributes_query='UPDATE ci_attribute_mapping SET value=? WHERE ci_id=? AND attr_id=?';
  
    // try {
    //         if(attributes.length>0){        
    //         const reformattedArray = attributes.map(async function(obj) {        
    //             const result=obj.value!=''? await runQuery(attributes_query,[obj.value,obj.ci_id,obj.attr_id]):false;
    //                 return result;
    //             });
    //         }
    //     } catch (error) {
    //          next(error);   
    //     }

    const constantQuery=`SELECT FIELD1_KEY,FIELD1_VALUE FROM MENULIST WHERE FIELD1_NAME='ServiceClassStatus' AND MODULE='SPCM_CMDB_INTERFACE'`;

    const constantQueryResult=await runQuery(constantQuery,[]);

    const statusArr={ Deployed:0,Suspended:0,Obsolete:0}

    constantQueryResult.forEach((tempConstant)=>{              
        statusArr.Deployed=tempConstant.FIELD1_KEY=='Deployed'?tempConstant.FIELD1_VALUE:statusArr.Deployed;
        statusArr.Suspended=tempConstant.FIELD1_KEY=='Suspended'?tempConstant.FIELD1_VALUE:statusArr.Suspended;
        statusArr.Obsolete=tempConstant.FIELD1_KEY=='Obsolete'?tempConstant.FIELD1_VALUE:statusArr.Obsolete;
    })


    var body=_.pick(req.body,['ci_name','company_id','company_name','status',
    'description','updated_by','support_company_id','support_company_name',
    'business_owner_id','business_owner_name', 'technical_owner_id','technical_owner_name',
    'editable','spcm_category_id','spcm_category_name','group_id','group_name']);

    body.status=statusArr[body.status]||0;

    logger.info(`${req.ip} Config Item patch request for `,body);
    var valuesArr=[],keysArr=[];
    for(key in body){
        keysArr.push(key+"= ?");        
        valuesArr.push(body[key]);
    }
    keysArr.push("updated_at=CURRENT_TIMESTAMP");
    var executeQuery = "SELECT * FROM FINAL TABLE (UPDATE config_items SET "+keysArr.toString()+" WHERE ci_id="+id+")";
    var data = await runQuery(executeQuery,valuesArr);
    logger.info(`${req.ip} REST Update By ID request completed for ${id}`);   
    res.status(200).json(data); 
    } catch (error) {
        res.status(400).send("Error Occurred");
        next(error);
    }
          
 })


 const unique_query=`SELECT COUNT(*) as duplicate FROM config_items
                    WHERE UPPER(ci_name) Like ?`;


/* REST POST request */
router.post("/", async function(req,res,next){

    try {
    // console.log("jwt token is :",req.headers['x-user-payload']);
    var encodedJwt = req.headers['x-user-payload'];
    var jwt = req.decodedJWT;
    var body=_.pick(req.body,['ci_name','class_id','asset_tag','company_id','company_name','status',
                    'category_id','sub_category_id','group_id','group_name','owner_id',
                'owner_name','location_id','location_name','dataset','manufacturer',
                'environment','metallic','description','created_by',
            'support_company_id','support_company_name','business_owner_id','business_owner_name',
            'technical_owner_id','technical_owner_name']); 
    body.ci_code="ci_code123";
    body = keysToBeSearchedInJWT(body,jwt);
    const isExist=await checkIsExistInDb(unique_query,[body.ci_name.toUpperCase()]);

    if(!isExist ){
    var valuesArr=[],keysArr=[],comma=[];
    for(key in body){
        keysArr.push(key);
        comma.push("?");
        valuesArr.push(body[key]);
    }
    keysArr.push('created_at ');
    comma.push("?");
    var created_at_val = moment().unix();
    valuesArr.push(created_at_val);

    var executeQuery1 = "SELECT ci_id FROM FINAL TABLE (INSERT INTO config_items ("+keysArr.toString()+") values ("+comma.toString()+"))";
    var data = await runQuery(executeQuery1,valuesArr);
    var new_ci_code=codeGeneratorMethod(ci_code_prefix,data[0].CI_ID);
    console.log(new_ci_code);
    var executeQuery2 = "SELECT * FROM FINAL TABLE (UPDATE config_items SET ci_code=? WHERE ci_id="+data[0].CI_ID+")";
    var idata = await runQuery(executeQuery2,[new_ci_code]);
    logger.info(`${req.ip} REST Post request completed for `,body);
    var x = await foundationApiCall(idata[0],'post',encodedJwt);
    res.status(200).json(idata);
}//if
else{
       
    const ci_name="CI name already exist";
    res.status(500).json([{ci_name}]); 
}
    } catch (error) {
        res.status(400).send("Error Occurred");
         next(error);   
    }
          
 });
 

 
router.get("/invalidCi/:id",async function(req,res,next){
    try{
    var getQuery = "SELECT  EXT_SYS_ID ,EXT_SOURCE ,JOB_ID, ERR_CODE , ERR_DESCRIPTION   FROM TEMP_CONFIG_ITEMS WHERE JOB_ID = "+req.params.id+" AND CI_TRANS_STATUS = 'INVALID';"
    console.log("getQuery is : ",getQuery);
    var getData = await runQuery(getQuery,[]);
    console.log("REST GET request completed for job_id : ",req.params.id);

    res.status(200).json(getData);
    }catch(error){
        console.log("Error is: ",Error);
        res.send(400).send("Error Occurred");
    }

});

router.get("/getColumnsForCiTable",async function(req,res,next){
    try{
        var executeQuery = "SELECT NAME FROM  SYSIBM.SYSCOLUMNS WHERE  TBNAME = 'CIVIEW'";
        var executeData = await runQuery(executeQuery,[]);
        var y,colName=[] ;
        for(key in executeData){
            y = executeData[key];
            colName.push(y.NAME);
        }
        res.status(200).json(colName);
    }catch(error){
        console.log("ERROR IS :",error);
        res.status(400).send("Error Occurred");
        
    }

});




/* REST patch request */
router.patch("/:id",async function(req,res,next){    

    try {
        
    var encodedJwt = req.headers['x-user-payload'];
    var jwt = req.decodedJWT;
    let reqParamArray=['ci_name','class_id','asset_tag','company_id','company_name','status',
    'category_id','sub_category_id','group_id','group_name','owner_id',
'owner_name','location_id','location_name','dataset','manufacturer',
'environment','metallic','description','updated_by',
'support_company_id','support_company_name','business_owner_id','business_owner_name',
'technical_owner_id','technical_owner_name'];
    var id=req.params.id; 


       
    var body=_.pick(req.body,reqParamArray); 
    body = keysToBeSearchedInJWT(body,jwt);
    const patch_unique_query=`${unique_query} AND CI_ID NOT IN (?)`;

    const isExist=await checkIsExistInDb(patch_unique_query,[body.ci_name.toUpperCase(),id]) ;

    if(!isExist ){
      
    logger.info(`${req.ip} Config Item patch request for `,body);
    var valuesArr=[],keysArr=[];
    for(key in body){
        keysArr.push(key+"= ?");        
        valuesArr.push(body[key]);
    }
    keysArr.push("updated_at=CURRENT_TIMESTAMP");
    var executeQuery = "SELECT * FROM FINAL TABLE (UPDATE config_items SET "+keysArr.toString()+" WHERE ci_id="+id+")";
    var data = await runQuery(executeQuery,valuesArr);
    console.log("calling foundationApiCall method from inside the PATCH call")
    var x = await foundationApiCall(data[0],'patch',encodedJwt);
    logger.info(`${req.ip} REST Update By ID request completed for ${id}`);
    res.status(200).json(data); 
    }else{
       
        const ci_name="CI name already exist";
        res.status(500).json([{ci_name}]); 
    }
} catch (error) {
    console.log("Error is :",error);
    res.status(400).send("Error Occurred");
    next(error);
}

 })

router.get('/checkForUserExistence', async function(req,res,next){
    try{
       
        let conditionString='';
        const orderByString=' ORDER BY created_at DESC ';
  
    
        logger.info(`${req.ip} REST Get All request received`);  
    
        if(req.query.user_id){
            conditionString+=" where (technical_owner_id = "+req.query.user_id+" OR business_owner_id = "+req.query.user_id+" )";
        }
        var executeQuery = "WITH new_config_items AS (SELECT md.field1_key as dataset_name,mf.field1_key as manufacturer_name,me.field1_key as environment_name,ms.field1_key as status_name,mm.field1_key as metallic_name,ci_id,ci_code,ci_name,ci.class_id,ci.editable,ci.spcm_category_id,ci.spcm_category_name,ci.created_at,ci.updated_at,ci.created_by,ci.updated_by,class_name,CONCAT(Cast(category_name as Varchar(500)) , CONCAT ('|',Cast(sub_category_name as Varchar(500)))) AS category_name,description,ci.company_id,company_name,ci.status,metallic,environment,group_name,owner_name,location_id,location_name,manufacturer,dataset,support_company_id, support_company_name,business_owner_id,business_owner_name,technical_owner_id,technical_owner_name,asset_tag from config_items as ci\
        left join class_master as cm on ci.class_id=cm.class_id\
        left join category_master_v2 as cat on cat.category_id=ci.category_id\
        left join menulist as ms on ci.status=ms.FIELD1_VALUE AND ms.field1_name='Status'\
        left join menulist as mm on ci.metallic=mm.FIELD1_VALUE AND mm.field1_name='Metallic'\
        left join menulist as me on ci.environment=me.FIELD1_VALUE AND me.field1_name='Environment'\
        left join menulist as mf on ci.manufacturer=mf.FIELD1_VALUE AND mf.field1_name='Manufacturer'\
        left join menulist as md on ci.dataset=md.FIELD1_VALUE AND md.field1_name='Dataset'  ) \
        SELECT *  FROM new_config_items "+conditionString+orderByString;
        console.log("executeQuery is :",executeQuery);
        var data = await runQuery(executeQuery,[]);
        res.status(200).json(data);
    }catch(error){
        res.status(400).send("Error Occurred");
        console.log("Error is :",error);
        return next(error);
    }
})


/*GET all CIs */
router.get('/',async function(req,res,next){
    try {
        var jwt = req.decodedJWT;
        var dateFormat = jwt.date_format;
        var jwtOffset = jwt.offset;
            
       
    
        const queryParams=_.pick(req.query,['searchByList','multipleValueList']); 
        const searchParams=_.pick(req.query,['searchByName','searchByValue']);//1
    
        const sortParams=_.pick(req.query,['sortBy','order']);
        var companyIdd = _.pick(req.query,['companyId']);
        if(companyIdd.companyId !== undefined && companyIdd.companyId !== null && companyIdd.companyId!== '')
            companyIdd = companyIdd.companyId;
        else
            companyIdd = jwt.associated_company_id;
        
        // const paginationParams=_.pick(req.query,['page','limit']);
        // const pageLimit=parseInt(paginationParams.limit||10);
        // const page=parseInt(paginationParams.page||1);
    
    
    
        let conditionString='';
       // const orderByString=' ORDER BY created_at DESC ';
      
        let isQueryBy=typeof queryParams.searchByList !== 'undefined' && queryParams.searchByList  !== null;
        let isQueryValue=typeof queryParams.multipleValueList !== 'undefined' && queryParams.multipleValueList!== null;
       
        if(isQueryBy&&isQueryValue){
            var searchArray = queryParams.searchByList.split(",");
            var multipleValueListArray = queryParams.multipleValueList.split("|");
        
    
            conditionString=' WHERE ';
    
            if(searchArray.length==multipleValueListArray.length){
                for(let i=0;i<searchArray.length;i++){
    
    
                    let inValueArray=multipleValueListArray[i].split(",");
                    
                    let inValue='';
                    
                    for(let j=0;j<inValueArray.length;j++){
                        inValue+=j===inValueArray.length-1?`\'${inValueArray[j]}\'`:`\'${inValueArray[j]}\',`;
                        
                    }  
                    
                
                    let tempVar=i===searchArray.length-1?`${searchArray[i]} IN (${inValue}) `:`${searchArray[i]} IN (${inValue}) AND `;
                    console.log("tempVar: ",tempVar);
                            
                    conditionString+=tempVar;  
                    
                }   
            }
         
    
        }
        let isSearchByName=typeof searchParams.searchByName !== 'undefined' && searchParams.searchByName  !== null;
        let isSearchByValue=typeof searchParams.searchByValue !== 'undefined' && searchParams.searchByValue!== null;
    
        if(isSearchByName&&isSearchByValue){
            
            conditionString=' WHERE ';
            var key1 = searchParams.searchByName.toUpperCase();
            var value1 = searchParams.searchByValue.toUpperCase();
            if(key1=="STATUS"){
    
                
                var initQuery="select FIELD1_VALUE from (select FIELD1_KEY,FIELD1_VALUE from MENULIST where UPPER(FIELD1_NAME) = 'STATUS') where UPPER(FIELD1_KEY)LIKE '%"+value1+"%'";
              
                const statusData = await runQuery(initQuery,[]);
                
                
                var valuesArr=[];
                for(key in statusData){
                    valuesArr.push(statusData[key].FIELD1_VALUE);
                }
                var valueToBeCompared=valuesArr.join();
                conditionString+=(" UPPER("+key1+") IN ( "+valueToBeCompared+" )");
                
                
            }else{
            conditionString+=" UPPER("+key1+") LIKE '%"+value1+"%'";
            }
    
        }
        logger.info(`${req.ip} REST Get All request received`);  
        str="";
        if(req.query.searchValue){ 
           str+=" AND (  UPPER(ci_name) LIKE '%"+req.query.searchValue.toUpperCase()+"%' OR  \
           UPPER(class_name) LIKE '%"+req.query.searchValue.toUpperCase()+"%' OR  \
           UPPER(company_name) LIKE '%"+req.query.searchValue.toUpperCase()+"%' )";
        }
        const queryStmt="WITH new_config_items AS (SELECT md.field1_key as dataset_name,mf.field1_key as manufacturer_name,me.field1_key as environment_name,ms.field1_key as status_name,mm.field1_key as metallic_name,ci_id,ci_code,ci_name,ci.class_id,ci.editable,ci.spcm_category_id,ci.spcm_category_name,ci.created_at,ci.updated_at,ci.created_by,ci.updated_by,class_name,CONCAT(Cast(category_name as Varchar(500)) , CONCAT ('|',Cast(sub_category_name as Varchar(500)))) AS category_name,description,ci.company_id,company_name,ci.status,metallic,environment,group_name,owner_name,location_id,location_name,manufacturer,dataset,support_company_id, support_company_name,business_owner_id,business_owner_name,technical_owner_id,technical_owner_name,asset_tag from config_items as ci\
        left join class_master as cm on ci.class_id=cm.class_id\
        left join category_master_v2 as cat on cat.category_id=ci.category_id\
        left join menulist as ms on ci.status=ms.FIELD1_VALUE AND ms.field1_name='Status'\
        left join menulist as mm on ci.metallic=mm.FIELD1_VALUE AND mm.field1_name='Metallic'\
        left join menulist as me on ci.environment=me.FIELD1_VALUE AND me.field1_name='Environment'\
        left join menulist as mf on ci.manufacturer=mf.FIELD1_VALUE AND mf.field1_name='Manufacturer'\
        left join menulist as md on ci.dataset=md.FIELD1_VALUE AND md.field1_name='Dataset' where company_id in( "+companyIdd+" ) "+str+" ) ";
    
        //const queryCounts=await db.query(queryStmt+' SELECT count(ci_id) as TOTALCOUNT FROM new_config_items '+conditionString).then(data=>data[0].TOTALCOUNT);
        // var executeQuery = queryStmt+' SELECT count(ci_id) as TOTALCOUNT FROM new_config_items '+conditionString ;
        // const queryCount=await runQuery(executeQuery,[]);
        // const queryCounts = queryCount[0].TOTALCOUNT;
    
        // const meta={};
        // meta.limit=pageLimit;
        // meta.rowCount=parseInt(queryCounts);    
        // meta.totalPageCount=Math.ceil(queryCounts/pageLimit);
        // meta.currentPage=page<=meta.totalPageCount&&page>0?page:1;
        // meta.type="success";   
        // meta.code=200;
      
        // const offset=( meta.currentPage-1)*pageLimit;     
    
    
        const orderValue=sortParams.order||'DESC';
        let orderBy=` ORDER BY ci_id ${orderValue}`;
        if(sortParams.sortBy){
            orderBy=` ORDER BY ${sortParams.sortBy} ${orderValue} `;
         //   orderBy=sortParams.sortBy==='GoalDuration'?`ORDER BY goal_duration ${orderValue}`:orderBy;        
        }
        
            var executeQuery = queryStmt+' SELECT *  FROM new_config_items '+conditionString+orderBy;
            console.log("ExecuteQuery is :",executeQuery);
            var data = await runQuery(executeQuery,[]);
            data =await epochToDateFormat(dateFormat,jwtOffset,data);
            res.status(200).json(data);
         
        }catch (error) {
            console.log("Error is: ",error);
            res.status(400).send("Error Occurred");
            return next(error);
        }
    
          
});

router.get('/classesPresentInCITable/:id',async function(req,res,next){
    try{
        var executeQuery = "SELECT class_id, class_name FROM class_master WHERE class_id IN(SELECT DISTINCT class_id FROM config_items WHERE company_id = "+req.params.id+");"
        console.log("EXECUTE QUERY IS :",executeQuery);
        var data = await runQuery(executeQuery,[]);
        logger.info(`${req.ip} REST Get All request received`);  
        res.status(200).json(data);

    }catch(error){
        res.status(400).send("Error Occurred");
        console.log("Error is :",error);
        return next(error);
    }

});

router.get('/ciDetailsByClassId',async function(req,res,next){
    try{
    var jwt = req.decodedJWT;
    let conditionString='';
    const orderByString=' ORDER BY created_at DESC ';
  
    
    logger.info(`${req.ip} REST Get All request received`);  

    if(req.query.class_id){
        conditionString+=" where class_id="+req.query.class_id;
    }

    var executeQuery = "WITH new_config_items AS (SELECT md.field1_key as dataset_name,mf.field1_key as manufacturer_name,me.field1_key as environment_name,ms.field1_key as status_name,mm.field1_key as metallic_name,ci_id,ci_code,ci_name,ci.class_id,ci.editable,ci.spcm_category_id,ci.spcm_category_name,ci.created_at,ci.updated_at,ci.created_by,ci.updated_by,class_name,CONCAT(Cast(category_name as Varchar(500)) , CONCAT ('|',Cast(sub_category_name as Varchar(500)))) AS category_name,description,ci.company_id,company_name,ci.status,metallic,environment,group_name,owner_name,location_id,location_name,manufacturer,dataset,support_company_id, support_company_name,business_owner_id,business_owner_name,technical_owner_id,technical_owner_name,asset_tag from config_items as ci\
    left join class_master as cm on ci.class_id=cm.class_id\
    left join category_master_v2 as cat on cat.category_id=ci.category_id\
    left join menulist as ms on ci.status=ms.FIELD1_VALUE AND ms.field1_name='Status'\
    left join menulist as mm on ci.metallic=mm.FIELD1_VALUE AND mm.field1_name='Metallic'\
    left join menulist as me on ci.environment=me.FIELD1_VALUE AND me.field1_name='Environment'\
    left join menulist as mf on ci.manufacturer=mf.FIELD1_VALUE AND mf.field1_name='Manufacturer'\
    left join menulist as md on ci.dataset=md.FIELD1_VALUE AND md.field1_name='Dataset'  ) \
    SELECT *  FROM new_config_items "+conditionString+orderByString;
    var data = await runQuery(executeQuery,[]);
    res.status(200).json(data);

    }catch(error){
        res.status(400).send("Error Occurred");
        console.log("Error is : ",error);
        return next(error);
    }   
})

router.get('/ciDetailsByCompany',async function(req,res,next){
    try{
    var jwt = req.decodedJWT;
    let conditionString='';
    const orderByString=' ORDER BY created_at DESC ';
  
    
    logger.info(`${req.ip} REST Get All request received`);  
    
    if(req.query.company_id){
        conditionString+=" where status_name LIKE 'Deployed' AND company_id="+req.query.company_id;
    }else{
        var company_id = jwt.associated_company_id;
        conditionString+=" where status_name LIKE 'Deployed' AND company_id IN ("+company_id+")";
    }
    var executeQuery = "WITH new_config_items AS (SELECT md.field1_key as dataset_name,mf.field1_key as manufacturer_name,me.field1_key as environment_name,ms.field1_key as status_name,mm.field1_key as metallic_name,ci_id,ci_code,ci_name,ci.class_id,ci.editable,ci.spcm_category_id,ci.spcm_category_name,ci.created_at,ci.updated_at,ci.created_by,ci.updated_by,class_name,CONCAT(Cast(category_name as Varchar(500)) , CONCAT ('|',Cast(sub_category_name as Varchar(500)))) AS category_name,description,ci.company_id,company_name,ci.status,metallic,environment,group_name,owner_name,location_id,location_name,manufacturer,dataset,support_company_id, support_company_name,business_owner_id,business_owner_name,technical_owner_id,technical_owner_name,asset_tag from config_items as ci\
    left join class_master as cm on ci.class_id=cm.class_id\
    left join category_master_v2 as cat on cat.category_id=ci.category_id\
    left join menulist as ms on ci.status=ms.FIELD1_VALUE AND ms.field1_name='Status'\
    left join menulist as mm on ci.metallic=mm.FIELD1_VALUE AND mm.field1_name='Metallic'\
    left join menulist as me on ci.environment=me.FIELD1_VALUE AND me.field1_name='Environment'\
    left join menulist as mf on ci.manufacturer=mf.FIELD1_VALUE AND mf.field1_name='Manufacturer'\
    left join menulist as md on ci.dataset=md.FIELD1_VALUE AND md.field1_name='Dataset'  ) \
    SELECT *  FROM new_config_items "+conditionString+orderByString;
    console.log("EXECUTE QUERY :",executeQuery);
    var data = await runQuery(executeQuery,[]);
    res.status(200).json(data);

    }catch(error){
        res.status(400).send("Error Occurred");
        console.log("Error is : ",error);
        return next(error);
    }   
});


router.get('/ciByCompanyAndUserId',async function(req,res,next){
    try{

        var jwt = req.decodedJWT , params={} , headers = req.headers;
        params["companyId"] = headers.company_id
        params["userId"]= headers.user_id;
        
        params = keysToBeSearchedInJWT(params,jwt);
        let conditionString='';
        const orderByString=' ORDER BY created_at DESC ';
        logger.info(`${req.ip} REST Get All request received`);  
        
        conditionString+=" where status_name LIKE 'Deployed' AND company_id="+params.companyId + " AND (business_owner_id = "+params.userId+" OR technical_owner_id = "+params.userId+")";
    
    
        var executeQuery = "WITH new_config_items AS (SELECT md.field1_key as dataset_name,mf.field1_key as manufacturer_name,me.field1_key as environment_name,ms.field1_key as status_name,mm.field1_key as metallic_name,ci_id,ci_code,ci_name as name ,ci.class_id,ci.editable,ci.spcm_category_id,ci.spcm_category_name,ci.created_at,ci.updated_at,ci.created_by,ci.updated_by,class_name,CONCAT(Cast(category_name as Varchar(500)) , CONCAT ('|',Cast(sub_category_name as Varchar(500)))) AS category_name,description,ci.company_id,company_name,ci.status,metallic,environment,group_name,owner_name,location_id,location_name,manufacturer,dataset,support_company_id, support_company_name,business_owner_id,business_owner_name,technical_owner_id,technical_owner_name,asset_tag from config_items as ci\
        left join class_master as cm on ci.class_id=cm.class_id\
        left join category_master_v2 as cat on cat.category_id=ci.category_id\
        left join menulist as ms on ci.status=ms.FIELD1_VALUE AND ms.field1_name='Status'\
        left join menulist as mm on ci.metallic=mm.FIELD1_VALUE AND mm.field1_name='Metallic'\
        left join menulist as me on ci.environment=me.FIELD1_VALUE AND me.field1_name='Environment'\
        left join menulist as mf on ci.manufacturer=mf.FIELD1_VALUE AND mf.field1_name='Manufacturer'\
        left join menulist as md on ci.dataset=md.FIELD1_VALUE AND md.field1_name='Dataset'  ) \
        SELECT *  FROM new_config_items "+conditionString+orderByString;
        console.log("EXECUTE QUERY :",executeQuery);
        var data = await runQuery(executeQuery,[]);
        
        if(data.length != 0){
            for(var key in data){
                
                var  executeQuery3 = "SELECT CI_ATTRIBUTE_MAPPING.CI_ID , CI_ATTRIBUTE_MAPPING.VALUE , ATTRIBUTE_NAME FROM CI_ATTRIBUTE_MAPPING LEFT JOIN ATTRIBUTE_MASTER ON  CI_ATTRIBUTE_MAPPING.ATTR_ID = ATTRIBUTE_MASTER.ATTRIBUTE_ID\
                WHERE CI_ID = "+data[key].CI_ID+"  AND ATTRIBUTE_NAME in ('Model ID','Serial Number'); "; 
                console.log("executeQuery3 query is  is :",executeQuery3 );
                var executeData3 = await runQuery(executeQuery3,[]); 
                console.log("ExecuteData3 is :",executeData3);
                
                var dat =data[key];
                if(executeData3.length == 2){               
                    for(var x in executeData3){
                        
                        console.log("executeData3[x] is :",executeData3[x]);
                        var str = executeData3[x].ATTRIBUTE_NAME;
                        str = str.toUpperCase(); //Convert STring to uppercase
                        str = str.replace(/ /g, "_"); //for replacing spaces with '_'
                        dat[str]= executeData3[x].VALUE;
                    }
                }else if(executeData3.length ==1){
                    if(executeData3[0].ATTRIBUTE_NAME == 'Model ID'){
                        var str = executeData3[0].ATTRIBUTE_NAME;
                        str = str.toUpperCase(); //Convert STring to uppercase
                        str = str.replace(/ /g, "_"); //for replacing spaces with '_'
                        dat[str]= executeData3[0].VALUE;
                        dat['SERIAL_NUMBER'] = "";
                    }else{
                        var str = executeData3[0].ATTRIBUTE_NAME;
                        str = str.toUpperCase(); //Convert STring to uppercase
                        str = str.replace(/ /g, "_"); //for replacing spaces with '_'
                        dat[str]= executeData3[0].VALUE;
                        dat['MODEL_ID'] = "";
                    }

                }
                else{
                  
                    dat['SERIAL_NUMBER'] = '';
                    dat['MODEL_ID'] = '';
                }
            }
        }


        
        
        res.status(200).json(data);

    }catch(error){
        res.status(400).send("Error Occurred");
        console.log("Error is : ",error);
        return next(error);
    }   
})


/*GET all CIs */
router.get('/V2',async function(req,res,next){

    try {
    var jwt = req.decodedJWT;
    var dateFormat = jwt.date_format;
    var jwtOffset = jwt.offset;
        
   

    const queryParams=_.pick(req.query,['searchByList','multipleValueList']); 
    const searchParams=_.pick(req.query,['searchByName','searchByValue']);//1

    const sortParams=_.pick(req.query,['sortBy','order']);

    const paginationParams=_.pick(req.query,['page','limit']);
    const pageLimit=parseInt(paginationParams.limit||10);
    const page=parseInt(paginationParams.page||1);



    let conditionString='';
   // const orderByString=' ORDER BY created_at DESC ';
  
    let isQueryBy=typeof queryParams.searchByList !== 'undefined' && queryParams.searchByList  !== null;
    let isQueryValue=typeof queryParams.multipleValueList !== 'undefined' && queryParams.multipleValueList!== null;
   
    if(isQueryBy&&isQueryValue){
        var searchArray = queryParams.searchByList.split(",");
        var multipleValueListArray = queryParams.multipleValueList.split("|");
    

        conditionString=' WHERE ';

        if(searchArray.length==multipleValueListArray.length){
            for(let i=0;i<searchArray.length;i++){


                let inValueArray=multipleValueListArray[i].split(",");
                
                let inValue='';
                
                for(let j=0;j<inValueArray.length;j++){
                    inValue+=j===inValueArray.length-1?`\'${inValueArray[j]}\'`:`\'${inValueArray[j]}\',`;
                    
                }  
                
            
                let tempVar=i===searchArray.length-1?`${searchArray[i]} IN (${inValue}) `:`${searchArray[i]} IN (${inValue}) AND `;
                console.log("tempVar: ",tempVar);
                        
                conditionString+=tempVar;  
                
            }   
        }
     

    }
    let isSearchByName=typeof searchParams.searchByName !== 'undefined' && searchParams.searchByName  !== null;
    let isSearchByValue=typeof searchParams.searchByValue !== 'undefined' && searchParams.searchByValue!== null;

    if(isSearchByName&&isSearchByValue){
        
        conditionString=' WHERE ';
        var key1 = searchParams.searchByName.toUpperCase();
        var value1 = searchParams.searchByValue.toUpperCase();
        if(key1=="STATUS"){

            
            var initQuery="select FIELD1_VALUE from (select FIELD1_KEY,FIELD1_VALUE from MENULIST where UPPER(FIELD1_NAME) = 'STATUS') where UPPER(FIELD1_KEY)LIKE '%"+value1+"%'";
          
            const statusData = await runQuery(initQuery,[]);
            
            
            var valuesArr=[];
            for(key in statusData){
                valuesArr.push(statusData[key].FIELD1_VALUE);
            }
            var valueToBeCompared=valuesArr.join();
            conditionString+=(" UPPER("+key1+") IN ( "+valueToBeCompared+" )");
            
            
        }else{
        conditionString+=" UPPER("+key1+") LIKE '%"+value1+"%'";
        }

    }
    logger.info(`${req.ip} REST Get All request received`);  
    str="";
    if(req.query.searchValue){ 
       str+=" AND (  UPPER(ci_name) LIKE '%"+req.query.searchValue.toUpperCase()+"%' OR  \
       UPPER(class_name) LIKE '%"+req.query.searchValue.toUpperCase()+"%' OR  \
       UPPER(company_name) LIKE '%"+req.query.searchValue.toUpperCase()+"%' )";
    }
    const queryStmt="WITH new_config_items AS (SELECT md.field1_key as dataset_name,mf.field1_key as manufacturer_name,me.field1_key as environment_name,ms.field1_key as status_name,mm.field1_key as metallic_name,ci_id,ci_code,ci_name,ci.class_id,ci.editable,ci.spcm_category_id,ci.spcm_category_name,ci.created_at,ci.updated_at,ci.created_by,ci.updated_by,class_name,CONCAT(Cast(category_name as Varchar(500)) , CONCAT ('|',Cast(sub_category_name as Varchar(500)))) AS category_name,description,ci.company_id,company_name,ci.status,metallic,environment,group_name,owner_name,location_id,location_name,manufacturer,dataset,support_company_id, support_company_name,business_owner_id,business_owner_name,technical_owner_id,technical_owner_name,asset_tag from config_items as ci\
    left join class_master as cm on ci.class_id=cm.class_id\
    left join category_master_v2 as cat on cat.category_id=ci.category_id\
    left join menulist as ms on ci.status=ms.FIELD1_VALUE AND ms.field1_name='Status'\
    left join menulist as mm on ci.metallic=mm.FIELD1_VALUE AND mm.field1_name='Metallic'\
    left join menulist as me on ci.environment=me.FIELD1_VALUE AND me.field1_name='Environment'\
    left join menulist as mf on ci.manufacturer=mf.FIELD1_VALUE AND mf.field1_name='Manufacturer'\
    left join menulist as md on ci.dataset=md.FIELD1_VALUE AND md.field1_name='Dataset' where company_id in( "+jwt.associated_company_id +" ) "+str+" ) ";

    //const queryCounts=await db.query(queryStmt+' SELECT count(ci_id) as TOTALCOUNT FROM new_config_items '+conditionString).then(data=>data[0].TOTALCOUNT);
    var executeQuery = queryStmt+' SELECT count(ci_id) as TOTALCOUNT FROM new_config_items '+conditionString ;
    const queryCount=await runQuery(executeQuery,[]);
    const queryCounts = queryCount[0].TOTALCOUNT;

    const meta={};
    meta.limit=pageLimit;
    meta.rowCount=parseInt(queryCounts);    
    meta.totalPageCount=Math.ceil(queryCounts/pageLimit);
    meta.currentPage=page<=meta.totalPageCount&&page>0?page:1;
    meta.type="success";   
    meta.code=200;
  
    const offset=( meta.currentPage-1)*pageLimit;     


    const orderValue=sortParams.order||'DESC';
    let orderBy=` ORDER BY ci_id ${orderValue}`;
    if(sortParams.sortBy){
        orderBy=` ORDER BY ${sortParams.sortBy} ${orderValue} `;
     //   orderBy=sortParams.sortBy==='GoalDuration'?`ORDER BY goal_duration ${orderValue}`:orderBy;        
    }
    
        var executeQuery = queryStmt+' SELECT *  FROM new_config_items '+conditionString+orderBy+" LIMIT ? OFFSET ? ";
        var data = await runQuery(executeQuery,[pageLimit,offset]);
        data =await epochToDateFormat(dateFormat,jwtOffset,data);
        res.status(200).json({meta,data});
     
    }catch (error) {
        console.log("Error is: ",error);
        res.status(400).send("Error Occurred");
        return next(error);
    }

});

/* router.get("/relationship",function(req,res,next){
    db.query("with result(ci_id,ci_name,DESCRIPTION,ci_id_related,class_id,class_name,url,created_by,created_at) as\
	(select rcici.ci_id,rci.ci_name,rci.DESCRIPTION,rcici.ci_id_related,rci.class_id,rcm.class_name,rcm.url,rcici.created_by,rcici.created_at \
				from ci_ci_relationship as rcici \
				left join config_items as rci on rcici.ci_id=rci.ci_id\
				left join class_master as rcm on rci.class_id=rcm.class_id\
				 where UPPER(module) LIKE '%"+req.query.module.toUpperCase()+"%' AND rcici.ci_id=?\
		union\
	 select rcici.ci_id,rci.ci_name,rci.DESCRIPTION,rcici.ci_id_related,rci.class_id,rcm.class_name,rcm.url,rcici.created_by,rcici.created_at \
				from ci_ci_relationship as rcici \
				left join config_items as rci on rcici.ci_id=rci.ci_id\
				left join class_master as rcm on rci.class_id=rcm.class_id\
				 where UPPER(module) LIKE '%"+req.query.module.toUpperCase()+"%' AND rcici.ci_id_related=?\
		)\
	,prefinal(ci_id,ci_name,DESCRIPTION,ci_id_related,class_id,class_name,url,class_id_related,class_name_related,ci_name_related,url_related,created_by,created_at) as (\
	  select r.ci_id,r.ci_name,r.DESCRIPTION,r.ci_id_related,r.class_id,r.class_name,r.url,ci.class_id as class_id_related,cm.class_name,ci.ci_name as ci_name_related,cm.url as url_related,r.created_by,r.created_at from\
	  result as r left join config_items as ci on r.ci_id_related=ci.ci_id\
	  left join class_master as cm on ci.class_id=cm.class_id\
	  )\
select p.*,r_name from prefinal as p\
	left join class_class_relationship as ccr on p.class_id=ccr.class_id and p.class_id_related=ccr.class_id_related\
	left join relationship_master as r on ccr.r_id=r.r_id",[req.query.ci_id,req.query.ci_id],function(err,data){
            if(err) return next(err);    
            logger.info(`${req.ip} REST get config item relationship request completed for `,data);   
            res.status(200).json(data);  
             } ) 
}) */

router.delete("/relationship",async function(req,res,next){
    try {

        

        const source= req.query.source||'UI';

        const initQuery=' select CCR.*,CI_NAME,COMPANY_NAME from config_items as CIs left join CI_CI_RELATIONSHIP as CCR on CIs.ci_id=CCR.ci_id_related where CCR.ci_id=? AND CCR.ci_id_related=?  '

        const params=  [req.query.ci_id,req.query.ci_id_related];

        // const initData=await db.query(initQuery,params).then((dbRes) => dbRes[0]);
        const initDat = await runQuery(initQuery,params);
        const initData = initDat[0];
        

        const dbQUery='delete from CI_CI_RELATIONSHIP where ci_id=? AND ci_id_related=?';
        //const data=await db.query(dbQUery,params).then((dbRes) => dbRes[0]);
        const dat = await runQuery(dbQUery,params);
        const data = dat[0];

        if(CMDB_SNOW_INTEGRATION=='YES'&&source=='UI'){

               
            const payload={
                "ciId": initData.CI_ID, 
                "ciNameRelated":initData.CI_NAME, 
                "clientConsumerName": initData.COMPANY_NAME,               
                "module": initData.MODULE, 
                "repStatus": "Queued", 
                "replicationType": "Delete",
                "createdBy": initData.CREATED_BY
              }
              

           console.log(payload,'payload')

              axios({
                method: 'post',
                url: ' http://xsmreplicator.mybluemix.net/xsmreplicator/api/rep-out-act-ci',
                data: payload
            })
            .then(function (response) {
                console.log(response.data);
            })
            .catch(function (error) {
                console.log(error);
            });


        }

       return   res.status(200).json({success:true,data});  


    } catch (error) {
        res.status(400).send("Error Occurred");
        return next(error); 
    }
 

});

router.get("/relationship",async function(req,res,next){
    var jwt = req.decodedJWT;
    var dateFormat = jwt.date_format;
    var offset = jwt.offset;
    var executeQuery = "with result(ci_id,ci_name,DESCRIPTION,ci_id_related,class_id,class_name,url,created_by,created_at,relationship_type,ci_id_number,ci_id_reported) as\
	(select rcici.ci_id,rci.ci_name,rci.DESCRIPTION,rcici.ci_id_related,rci.class_id,rcm.class_name,rcm.url,rcici.created_by,rcici.created_at,rcici.relationship_type,rcici.ci_id_number,rcici.ci_id_reported\
				from ci_ci_relationship as rcici\
				left join config_items as rci on rcici.ci_id=rci.ci_id\
				left join class_master as rcm on rci.class_id=rcm.class_id\
				 where UPPER(module) LIKE '%"+req.query.module.toUpperCase()+"%' AND rcici.ci_id=?\
		union\
	 select rcici.ci_id,rci.ci_name,rci.DESCRIPTION,rcici.ci_id_related,rci.class_id,rcm.class_name,rcm.url,rcici.created_by,rcici.created_at ,rcici.relationship_type,rcici.ci_id_number,rcici.ci_id_reported\
				from ci_ci_relationship as rcici\
				left join config_items as rci on rcici.ci_id=rci.ci_id\
				left join class_master as rcm on rci.class_id=rcm.class_id\
				 where UPPER(module) LIKE '%"+req.query.module.toUpperCase()+"%' AND rcici.ci_id_related=?\
		)\
	,prefinal(ci_id,ci_name,DESCRIPTION,ci_id_related,class_id,class_name,url,class_id_related,class_name_related,ci_name_related,description_related,url_related,created_by,created_at,relationship_type,ci_id_number,ci_id_reported) as (\
	  select r.ci_id,r.ci_name,r.DESCRIPTION,r.ci_id_related,r.class_id,r.class_name,r.url,ci.class_id as class_id_related,cm.class_name,ci.ci_name as ci_name_related,ci.description as description_related,cm.url as url_related,r.created_by,r.created_at,r.relationship_type,r.ci_id_number,r.ci_id_reported from\
	  result as r left join config_items as ci on r.ci_id_related=ci.ci_id\
	  left join class_master as cm on ci.class_id=cm.class_id\
	  )\
select p.*,r_name from prefinal as p\
	left join class_class_relationship as ccr on p.class_id=ccr.class_id and p.class_id_related=ccr.class_id_related\
    left join relationship_master as r on ccr.r_id=r.r_id ORDER BY p.CREATED_AT desc";
    try{
        var data = await runQuery(executeQuery,[req.query.ci_id,req.query.ci_id]);
        data =await epochToDateFormat(dateFormat,offset,data);
        logger.info(`${req.ip} REST get config item relationship request completed for `,data); 
        res.status(200).json(data);


    }catch(error){
        console.log("error is : ",error);
        res.status(400).send("Error Occurred");
        return next(error);
    }
});   

//get relationship details using ci_id(which is ci_id_related of ci_ci_relationship table)
router.get("/relationship/:id",async function(req,res,next){
    var jwt = req.decodedJWT;
    var dateFormat = jwt.date_format;
    var offset = jwt.offset;
    try{
        var executeQuery = "select * from ci_ci_relationship where ci_id_related =?";
        var data = await runQuery(executeQuery,[req.params.id]);
        data =await epochToDateFormat(dateFormat,offset,data);
        logger.info(`${req.ip} REST get config item relationship request completed for `,data);
        res.status(200).json(data);


    }catch(error){
        console.log("Error is  : ",error);
        res.status(400).send("Error Occurred");
        return next(error);

    }
});


router.get("/relationship/pagination/v2",async function(req,res,next){
    var executeQuery = "select ccr.*,ci.CI_NAME as CI_NAME_RELATED,ci.DESCRIPTION as DESCRIPTION_RELATED,cm.class_id as CLASS_ID_RELATED,cm.class_name as CLASS_NAME_RELATED\
    from ci_ci_relationship as ccr\
    left join config_items as ci on ci.ci_id=ccr.ci_id_related\
    left join class_master as cm on cm.CLASS_ID=ci.CLASS_ID \
    where ccr.ci_id=? and UPPER(module) LIKE ? ORDER BY ccr.CREATED_AT desc ";
    
    try{
        var data = await runQuery(executeQuery,[req.query.ci_id,req.query.module.toUpperCase()]);
        logger.info(`${req.ip} REST get config item relationship request completed for `,data); 
        res.status(200).json(data); 

    }catch(error){
        console.log("Error is : ",error);
        res.status(400).send("Error Occurred");
        return next(error);
    }
});








/* router.get("/relationship",function(req,res,next){
    db.query("with result(ci_id,ci_name,DESCRIPTION,r_name,ci_id_related,class_id,class_name,url,created_by,created_at) as\
	(select rcici.ci_id,rci.ci_name,rci.DESCRIPTION,rm.r_name,rcici.ci_id_related,rci.class_id,rcm.class_name,rcm.url,rcici.created_by,rcici.created_at \
				from ci_ci_relationship as rcici \
				left join config_items as rci on rcici.ci_id=rci.ci_id\
				left join class_master as rcm on rci.class_id=rcm.class_id\
	 			left join relationship_master as rm on rcici.r_id=rm.r_id\
				 where UPPER(module) LIKE '%"+req.query.module.toUpperCase()+"%' AND rcici.ci_id=?\
		union\
	 select rcici.ci_id,rci.ci_name,rci.DESCRIPTION,rm.r_name,rcici.ci_id_related,rci.class_id,rcm.class_name,rcm.url,rcici.created_by,rcici.created_at \
				from ci_ci_relationship as rcici \
				left join config_items as rci on rcici.ci_id=rci.ci_id\
				left join class_master as rcm on rci.class_id=rcm.class_id\
	 			left join relationship_master as rm on rcici.r_id=rm.r_id\
				 where UPPER(module) LIKE '%"+req.query.module.toUpperCase()+"%' AND rcici.ci_id_related=?\
		)\
	  select r.ci_id,r.ci_name,r.DESCRIPTION,r.r_name,r.ci_id_related,r.class_id,r.class_name,r.url,ci.class_id as class_id_related,cm.class_name as class_name_related,ci.ci_name as ci_name_related,ci.description as description_related,cm.url as url_related,r.created_by,r.created_at from\
	  result as r left join config_items as ci on r.ci_id_related=ci.ci_id\
	  left join class_master as cm on ci.class_id=cm.class_id",[req.query.ci_id,req.query.ci_id],function(err,data){
            if(err) return next(err);   
            logger.info(`${req.ip} REST get config item relationship request completed for `,data);   
            res.status(200).json(data);  
             } ) 
}) */
/*GET CI by id */
router.get('/:id',async function(req,res,next){
    var jwt = req.decodedJWT;
    var dateFormat = jwt.date_format;
    var offset = jwt.offset;
    
    var executeQuery = "SELECT md.field1_key as dataset_name,mf.field1_key as manufacturer_name,me.field1_key as environment_name,ms.field1_key as status_name,mm.field1_key as metallic_name,ci_id,ci_code,ci_name,class_name,ci.class_id,ci.editable,ci.spcm_category_id,ci.spcm_category_name,ci.created_at,ci.updated_at,ci.created_by,ci.updated_by,company_id,company_name,ci.class_id,cat.category_id,CONCAT(Cast(category_name as Varchar(500)) , CONCAT ('|',Cast(sub_category_name as Varchar(500)))) AS category_name,description,ci.status,metallic,environment,group_id,group_name,owner_id,owner_name,location_id,location_name,manufacturer,dataset,support_company_id, support_company_name,business_owner_id,business_owner_name,technical_owner_id,technical_owner_name,asset_tag from config_items as ci\
    left join class_master as cm on ci.class_id=cm.class_id\
    left join category_master_v2 as cat on cat.category_id=ci.category_id\
 left join menulist as ms on ci.status=ms.FIELD1_VALUE AND ms.field1_name='Status'\
    left join menulist as mm on ci.metallic=mm.FIELD1_VALUE AND mm.field1_name='Metallic'\
    left join menulist as me on ci.environment=me.FIELD1_VALUE AND me.field1_name='Environment'\
    left join menulist as mf on ci.manufacturer=mf.FIELD1_VALUE AND mf.field1_name='Manufacturer'\
    left join menulist as md on ci.dataset=md.FIELD1_VALUE AND md.field1_name='Dataset'\
    WHERE ci_id=?";
    try{
        var data = await runQuery(executeQuery,[req.params.id]);
        if(data.length == 0){
            res.status(200).json([]);
        }else{
            data = await epochToDateFormat(dateFormat,offset,data);
            console.log("DATA is :",data[0]);
            res.status(200).json(data[0]);
        }
    }catch(error){
        console.log("Error is : ",error);
        res.status(400).send("Error Occurred");
        return next(error);
    }
    
    
});

/*GET CI attributes by id */
router.get('/:id/attributes',async function(req,res,next){
    var executeQuery = "with result (class_id,parent_class_id,class_name,status) as \
    (\
      select r.class_id,r.parent_class_id,r.class_name,r.status\
      from class_master r\
      where r.class_id IN (\
      Select class_id \
        from config_items\
        where ci_id=?\
      )\
      union all\
      select p.class_id,p.parent_class_id,p.class_name,p.status\
      from result c,class_master p\
      where c.parent_class_id=p.class_id\
      )\
        Select DISTINCT attribute_id,attribute_name,mandatory,status,class_id,value \
        from attribute_master as am left join ci_attribute_mapping as cam\
        on am.attribute_id=cam.attr_id AND cam.ci_id=?\
        where class_id IN (\
        select class_id from result)";
        try{
            var data = await runQuery(executeQuery,[req.params.id,req.params.id]);
            res.status(200).json(data);


        }catch(error){
            console.log("Error is :",error);
            res.status(400).send("Error Occurred");
            return next(error);
        }
});

/*GET CI attributes by id */
router.get('/:id/attributes/:attr_id',async function(req,res,next){    

    var executeQuery = "  Select attribute_id,attribute_name,mandatory,status,class_id,value \
    from attribute_master as am left join ci_attribute_mapping as cam\
    on am.attribute_id=cam.attr_id AND cam.ci_id=?\
    where  am.attribute_id=?";
    try{
        var data = await runQuery(executeQuery,[req.params.id,req.params.attr_id]);
        logger.info(`${req.ip} REST get ci attributes by id request completed for `,data);
        res.status(200).json(data[0]);
    }catch(error){
        console.log("Error is : ",error);
        res.status(400).send("Error Occurred");
        return next(error);

    }
        
 })


/*post CI attributes by id */
router.post('/:id/attributes',async function(req,res,next){

    var body=_.pick(req.body,['attr_id','value']); 
    body.ci_id=req.params.id;
    try{
        var encodedJwt = req.headers['x-user-payload'];
        var jwt = req.decodedJWT;
        console.log("FROM INSIDE ATTRIBUTE POST");
        var executeQuery = "SELECT * FROM FINAL TABLE (INSERT INTO ci_attribute_mapping (ci_id,attr_id,value) values (?,?,?))";
        var data = await runQuery(executeQuery,[body.ci_id,body.attr_id,body.value]);
        console.log("data from inside attribute post is :",data);
        var x = await foundationApiCall(data[0],'post',encodedJwt);
        logger.info(`${req.ip} REST post CI attributes by id request completed for `,body);
        res.status(200).json(data[0]);

    }catch(error){
        console.log("Error is :",error);
        res.status(400).send("Error Occurred");
    }

    // used for muliple arrtibutes in single list
    // var attArr=[];
    // for(var i = 0; i<body.length; i++){       
    //     var myobject  = '('+configid+','+body[i].attr_id+','+body[i].value+')';
    //     attArr.push(myobject);
    // }  
    // db.query("SELECT * FROM FINAL TABLE (INSERT INTO ci_attribute_mapping values "+attArr.toString()+")",function(err,data){
    //     if(err) return next(err);         
    //     logger.info(`${req.ip} post CI attributes by id request completed for ${id}`);   
    //         res.status(200).json(data);          
            
    // })

});

/*patch CI attributes by id */
router.patch('/:id/attributes/:att_id',async function(req,res,next){
    
    var body=_.pick(req.body,['value']); 
    body.ci_id=req.params.id;
    body.attr_id=req.params.att_id;


    try{
        var encodedJwt = req.headers['x-user-payload'];
        var jwt = req.decodedJWT;
        console.log("FROM INSIDE ATTRIBUTE PATCH");
        var executeQuery = "SELECT * FROM FINAL TABLE (UPDATE ci_attribute_mapping SET value=? WHERE ci_id=? AND attr_id=?  )";
        var data = await runQuery(executeQuery,[body.value,body.ci_id,body.attr_id]);
        console.log("data from inside attribute patch is :",data);
        var x = await foundationApiCall(data[0],'patch',encodedJwt);
        logger.info(`${req.ip} REST patch CI attributes request completed for `,data);   
        res.status(200).json(data[0]); 


    }catch(error){
        console.log("Error is: ",error);
        res.status(400).send("Error Occurred");
        return next(error);
    }
    // db.query("SELECT * FROM FINAL TABLE (UPDATE ci_attribute_mapping SET value=? WHERE ci_id=? AND attr_id=?  )",[body.value,body.ci_id,body.attr_id],function(err,data){
    //     if(err) return next(err);    
    //     logger.info(`${req.ip} REST patch CI attributes request completed for `,data);   
    //      res.status(200).json(data[0]);             
    // })
         
});

router.get('/:id/hierarchy/',async function(req,res,next){
    console.log(req.query);
    if(req.query.hierarchy=="upward"){
        str1=" where rcici.ci_id="+req.params.id+") r";
        str2=" where c.ci_id_related=p.ci_id";
        str3=" ";
    }
    else{
        str1=" where rcici.ci_id_related="+req.params.id+") r ";
        str2=" where c.ci_id=p.ci_id_related";
        str3=" select ci.ci_id,ci_name,null,ci.class_id,class_name,url\
                from config_items ci left join class_master cm on ci.class_id=cm.class_id\
                where ci.ci_id="+req.params.id;
    }
    if(!req.query.hierarchy){
        console.log("yo");
        var executeQuery1 = "with result(ci_id,ci_name,ci_id_related,class_id,class_name,url) as\
        (select r.ci_id,r.ci_name,r.ci_id_related,r.class_id,r.class_name,r.url\
             from (select rcici.ci_id,rci.ci_name,rcici.ci_id_related,rci.class_id,rcm.class_name,rcm.url \
                    from ci_ci_relationship as rcici \
                    left join config_items as rci on rcici.ci_id=rci.ci_id\
                    left join class_master as rcm on rci.class_id=rcm.class_id\
                     where rcici.ci_id_related="+req.params.id+") r \
             UNION ALL\
             select p.ci_id,p.ci_name,p.ci_id_related,p.class_id,p.class_name,p.url\
             from result c,(select pcici.ci_id,pci.ci_name,pcici.ci_id_related,pci.class_id,pcm.class_name,pcm.url from\
                 ci_ci_relationship pcici\
             left join config_items as pci on pcici.ci_id=pci.ci_id\
             left join class_master as pcm on pci.class_id=pcm.class_id) p\
              where c.ci_id=p.ci_id_related\
         )\
        ,prefinal (ci_id,ci_name,ci_id_related,class_id,class_name,url) as (\
         select * from result union  select ci.ci_id,ci_name,null,ci.class_id,class_name,url\
                    from config_items ci left join class_master cm on ci.class_id=cm.class_id\
                    where ci.ci_id="+req.params.id
         +"),final(ci_id,ci_name,ci_id_related,class_id,class_name,url,class_id_related,class_name_related,url_related) as (\
            select p.ci_id,p.ci_name,p.ci_id_related,p.class_id,p.class_name,p.url,ci.class_id as class_id_related,cm.class_name as class_name_related,cm.url as url_related\
            from prefinal as p left join config_items as ci on p.ci_id_related=ci.ci_id\
            left join class_master as cm on ci.class_id=cm.class_id)\
            select f.*,rm.r_name\
            from final as f left join class_class_relationship as ccr on (f.class_id=ccr.class_id AND f.class_id_related=ccr.class_id_related)\
            OR (f.class_id=ccr.class_id_related AND f.class_id_related=ccr.class_id)\
            left join relationship_master as rm on ccr.r_id=rm.r_id";

        var executeQuery2 = "with result(ci_id,ci_name,ci_id_related,class_id,class_name,url) as\
        (select r.ci_id,r.ci_name,r.ci_id_related,r.class_id,r.class_name,r.url\
             from (select rcici.ci_id,rci.ci_name,rcici.ci_id_related,rci.class_id,rcm.class_name,rcm.url \
                    from ci_ci_relationship as rcici \
                    left join config_items as rci on rcici.ci_id=rci.ci_id\
                    left join class_master as rcm on rci.class_id=rcm.class_id\
                     where rcici.ci_id="+req.params.id+") r\
             UNION ALL\
             select p.ci_id,p.ci_name,p.ci_id_related,p.class_id,p.class_name,p.url\
             from result c,(select pcici.ci_id,pci.ci_name,pcici.ci_id_related,pci.class_id,pcm.class_name,pcm.url from\
                 ci_ci_relationship pcici\
             left join config_items as pci on pcici.ci_id=pci.ci_id\
             left join class_master as pcm on pci.class_id=pcm.class_id) p\
               where c.ci_id_related=p.ci_id\
         )\
        ,prefinal (ci_id,ci_name,ci_id_related,class_id,class_name,url) as (\
         select * from result union),final(ci_id,ci_name,ci_id_related,class_id,class_name,url,class_id_related,class_name_related,url_related) as (\
            select p.ci_id,p.ci_name,p.ci_id_related,p.class_id,p.class_name,p.url,ci.class_id as class_id_related,cm.class_name as class_name_related,cm.url as url_related\
            from prefinal as p left join config_items as ci on p.ci_id_related=ci.ci_id\
            left join class_master as cm on ci.class_id=cm.class_id)\
            select f.*,rm.r_name\
            from final as f left join class_class_relationship as ccr on (f.class_id=ccr.class_id AND f.class_id_related=ccr.class_id_related)\
            OR (f.class_id=ccr.class_id_related AND f.class_id_related=ccr.class_id)\
            left join relationship_master as rm on ccr.r_id=rm.r_id";
            try{
                var data = await runQuery(executeQuery1,[]);
                console.log("Result is :",data);
                var dataa = await runQuery(executeQuery2,[]);

                dataa.forEach(function(val){
                    data.push(val);
                })
                res.status(200).json(data);
            }catch(error){
                console.log("Error outside is : ",error);
                res.status(400).send("Error Occurred");
                return(next(error));
            }
    }
    else{
        var executeQuery = "with result(ci_id,ci_name,ci_id_related,class_id,class_name,url) as\
        (select r.ci_id,r.ci_name,r.ci_id_related,r.class_id,r.class_name,r.url\
             from (select rcici.ci_id,rci.ci_name,rcici.ci_id_related,rci.class_id,rcm.class_name,rcm.url \
                    from ci_ci_relationship as rcici \
                    left join config_items as rci on rcici.ci_id=rci.ci_id\
                    left join class_master as rcm on rci.class_id=rcm.class_id\
                    "+str1+"\
             UNION ALL\
             select p.ci_id,p.ci_name,p.ci_id_related,p.class_id,p.class_name,p.url\
             from result c,(select pcici.ci_id,pci.ci_name,pcici.ci_id_related,pci.class_id,pcm.class_name,pcm.url from\
                 ci_ci_relationship pcici\
             left join config_items as pci on pcici.ci_id=pci.ci_id\
             left join class_master as pcm on pci.class_id=pcm.class_id) p\
              "+str2+"\
         )\
        ,prefinal (ci_id,ci_name,ci_id_related,class_id,class_name,url) as (\
         select * from result union "+str3
         +"),final(ci_id,ci_name,ci_id_related,class_id,class_name,url,class_id_related,class_name_related as (\
            select p.ci_id,p.ci_name,p.ci_id_related,p.class_id,p.class_name,p.url,ci.class_id as class_id_related,cm.class_name as class_name_related\
            from prefinal as p left join config_items as ci on p.ci_id_related=ci.ci_id\
            left join class_master as pcm on pci.class_id=pcm.class_id)\
            select f.*,rm.r_name\
            from final as f left join class_class_relationship as ccr on (f.class_id=ccr.class_id AND f.class_id_related=ccr.class_id_related)\
            OR (f.class_id=ccr.class_id_related AND f.class_id_related=ccr.class_id)\
            left join relationship_master as rm on ccr.r_id=rm.r_id";
            try{
                var data = await runQuery(executeQuery,[]); 
                logger.info(`${req.ip} REST get class hierarchy by class id request completed for `,data); 
                res.status(200).json(data);

            }catch(error){
                console.log("Error is : ",error);
                res.status(400).send("Error Occurred");
                return next(error);
            }
    }
})

router.post("/relationship",async function(req,res,next){

    try 
    {
        var jwt = req.decodedJWT;
        var dateFormat = jwt.date_format;
    
        var body=_.pick(req.body,['ci_id','ci_id_related','created_by','r_id','module','relationship_type','ci_id_number','ci_id_reported','created_at']); 
        const ci_name=req.body['ci_name_related'];
        console.log("ci_name: "+ci_name);
        body.created_at = moment().unix();

        console.log("ci_id_reported before converted to epoch:",body.ci_id_reported);
        body.ci_id_reported = await dateFormatToEpoch(body.ci_id_reported,dateFormat);
        console.log("ci_id_reported after converted into epoch:",body.ci_id_reported);
        body = keysToBeSearchedInJWT(body,jwt);
        let intApiCall=true;
        
        if(ci_name){

            intApiCall=false;
            const initQuery='SELECT CI_ID FROM CONFIG_ITEMS WHERE UPPER(CI_NAME) LIKE ? LIMIT 1';
            // let initData= await db.query(initQuery,[ci_name.toUpperCase()]);
            let initData = await runQuery(initQuery,[ci_name.toUpperCase()]);
            console.log(initData);
        
            if(initData.length>0){
                body.ci_id_related=initData[0].CI_ID;
            }
        }
        logger.info(`${req.ip} config item relationship post request for `,body);

        if(body.ci_id_related)
        {
            console.log("1");
            var valuesArr=[],keysArr=[],comma=[];
            console.log("body is : ",body);
            for(key in body){
                keysArr.push(key);
                comma.push("?");
                valuesArr.push(body[key]);
            }
            const dbQuery1 = "select * from FINAL TABLE(INSERT INTO ci_ci_relationship ("+keysArr.toString()+") values ("+comma.toString()+"))";
            console.log("dbquery :",dbQuery1);
            try{
                var data  = await runQuery(dbQuery1,valuesArr) ;
                logger.info(`${req.ip} REST post config item relationship request completed for `,data);
                if(CMDB_SNOW_INTEGRATION=='YES'&&intApiCall){

                    const configQuery='SELECT CI_NAME,COMPANY_NAME FROM CONFIG_ITEMS WHERE CI_ID=? LIMIT 1';
                    // let configData= await db.query(configQuery,[data[0].CI_ID_RELATED]);
                    let configData = await runQuery(configQuery,[data[0].CI_ID_RELATED]);
                    const payload={
                        "ciId": data[0].CI_ID, 
                        "ciNameRelated":configData[0].CI_NAME, 
                        "clientConsumerName": configData[0].COMPANY_NAME,               
                        "module": data[0].MODULE, 
                        "repStatus": "Queued", 
                        "replicationType": "Create",
                        "createdBy": data[0].CREATED_BY,
                        "ciNumber":data[0].CI_ID_NUMBER
                    }
                    console.log(payload,'payload');

                    axios({
                        method: 'post',
                        url: 'http://xsmreplicator.mybluemix.net/xsmreplicator/api/rep-out-create-ci',
                        data: payload
                    })
                    .then(function (response) {
                        console.log(response.data);
                    })
                    .catch(function (error) {
                        console.log(error);
                    });
                }
                return  res.status(200).json(data); 

            }catch(error){
                console.log("Error is : ",error);
                res.status(400).json({message:"This ci_id is already related"});
                return next(error);
            }
          
        }else{ 
            return  res.status(400).json({message:"NO ci_id_related found"});
        }
             
    }catch (error) {
        res.status(400).send("Error Occurred");
        return next(error);
    }
});






module.exports = router;





/**
 * ALTER TABLE CI_CI_RELATIONSHIP
  ADD CONSTRAINT ucCodes UNIQUE (CI_ID_RELATED, CI_ID)
 */

 /**
  * 
  ALTER TABLE CONFIG_ITEMS
ADD  support_company_id int NOT NULL,
support_company_name varchar(500) NOT NULL,
business_owner_id int NOT NULL,
business_owner_name varchar(500) NOT NULL,
technical_owner_id int NOT NULL,
technical_owner_name varchar(500) NOT NULL;


ALTER TABLE CONFIG_ITEMS
ADD  support_company_id int NOT NULL DEFAULT 0;
ALTER TABLE CONFIG_ITEMS
ADD support_company_name varchar(500) NOT NULL DEFAULT '';

ALTER TABLE CONFIG_ITEMS
ADD business_owner_id int NOT NULL DEFAULT 0;

ALTER TABLE CONFIG_ITEMS
ADD business_owner_name varchar(500) NOT NULL DEFAULT '';

ALTER TABLE CONFIG_ITEMS
ADD technical_owner_id int NOT NULL DEFAULT 0;
ALTER TABLE CONFIG_ITEMS
ADD technical_owner_name varchar(500) NOT NULL DEFAULT '';



ALTER TABLE CONFIG_ITEMS
ADD Asset_Tag varchar(500);





{
	
	"ci_name":"helloIAMTEtsing",
	"class_id":1,
	"company_id":1,
	"company_name":"hcl",
	"status":5,
	"category_id":1,
	"sub_category_id":1,
	"group_id":1,
	"group_name":"abc",
	"owner_id":1,
	"owner_name":"abc",
	"location_id":1,"location_name":"abc","dataset":"abc","manufacturer":"abc",
             "environment":1,"metallic":1,"description":"adasdasasda","created_by":1,
            "support_company_id":1,"support_company_name":"abc","business_owner_id":1,"business_owner_name":"acd",
            "technical_owner_id":1,"technical_owner_name":"abc" 
}
  */


  /**
   * 
  
{ ci_name: 'N10m sit amet dolor feugia123',
  class_id: 2,
  company_id: 3215,
  company_name: 'Hindustan Unilever Limited',
  description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc at euismod risus. Donec dui ligula, tincidunt id condimentum ut, mattis quis ex. Sed ac aliquam odio. Etiam convallis, lorem non lobortis egestas, metus magna posuere arcu, eget bibendum purus augue vel urna. Sed mollis eu nulla sagittis lobortis. Mauris
sollicitudin nunc eu mattis blandit. Sed ac iaculis mauris. Nam sit amet dolor feugiat, tempus neque ut, facilisis turpis.',
  spcm_category_id: 1672,
  spcm_category_name: 'HEALTH',
  status: 30,
  created_by: null,
  updated_by: null,
  business_owner_id: 4006,
  business_owner_name: 'HCLT  CIM',
  support_company_id: 3215,
  support_company_name: 'Hindustan Unilever Limited',
  technical_owner_id: 3996,
  technical_owner_name: 'HUL  Portfolio Manager',
  group_id: 2093,
  group_name: 'HUL Portfolio Management' }


{ "ci_name": "N10m sit amet dolor feugia123",
  "class_id": 2,
  "company_id": 3215,
  "company_name": "Hindustan Unilever Limited",
  "description": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc at euismod risus. Donec dui ligula, tincidunt id condimentum ut, mattis quis ex. Sed ac aliquam odio. Etiam convallis, lorem non lobortis egestas, metus magna posuere arcu, eget bibendum purus augue vel urna. Sed mollis eu nulla sagittis lobortis. Mauris sollicitudin nunc eu mattis blandit. Sed ac iaculis mauris. Nam sit amet dolor feugiat, tempus neque ut, facilisis turpis.",
  "spcm_category_id": 1672,
  "spcm_category_name": "HEALTH",
  "status": 30,
   "updated_by": null,
  "business_owner_id": 4006,
  "business_owner_name": "HCLT  CIM",
  "support_company_id": 3215,
  "support_company_name": "Hindustan Unilever Limited",
  "technical_owner_id": 3996,
  "technical_owner_name": "HUL  Portfolio Manager",
  "group_id": 2093,
  "group_name": "HUL Portfolio Management" }


   * 
   */