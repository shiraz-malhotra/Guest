const {runQuery} = require('./../../config/functions');
var express=require('express');
var router=express.Router();


router.get("/",async function(req,res,next){
    /* var str="SELECT distinct(field1_key),field1_value from menulist";
    if(req.query.field1_name||req.query.module)
        str+=" WHERE ";
    str+=req.query.field1_name?" field1_name='"+req.query.field1_name+"' AND ":"";
    str+=req.query.module?" module='"+req.query.module+"'":"";
    console.log(str);

    db.query(str,function(err,data){
        if(err) return next(err);
        else
            res.status(200).json(data);
            
    }) */
    
    try{
        var exexcuteQuery = "SELECT distinct(field1_key),field1_value,FIELD2_VALUE AS ORDER from menulist WHERE field1_name=? AND module=? ORDER BY FIELD2_VALUE,field1_key ASC";
        var data = await runQuery(exexcuteQuery,[req.query.field1_name,req.query.module]);
        res.status(200).json(data);
    }catch(error){
        console.log("Error is : ",error);
        res.status(400).send("Error Occurred");
        return next(error);
    }
});


router.get("/statusTransitions",async function(req,res,next){
    try{
        var exexcuteQuery = "SELECT distinct(field3_key) as field1_key,field3_value as field1_value from menulist WHERE field1_name='StatusTransitions' AND module='CI' AND FIELD1_VALUE=? ORDER BY field3_value ASC";
        var data = await runQuery(exexcuteQuery,[req.query.statusId||0]);
        res.status(200).json(data);
        
    }catch(error){
        console.log("Error is : ",error);
        res.status(400).send("Error Occurred");
        return next(error);
    }
})

module.exports = router;