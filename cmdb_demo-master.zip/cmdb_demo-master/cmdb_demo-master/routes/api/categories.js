const {config} = require('./../../config/serversetup');
const express=require('express');
const {runQuery,keysToBeSearchedInJWT} = require('./../../config/functions');
var router=express.Router();
const _=require('lodash');

const categoriesTable="category_master_v2";
const selectColumnList=`category_id, CONCAT(Cast(category_name as Varchar(500)) , CONCAT ('|',Cast(sub_category_name as Varchar(500)))) AS category_name,status,class_id`;

/*GET categories on the basis of location */
router.get('/location',async function(req,res,next){
    try{

        var jwt = req.decodedJWT;
        var params={} , headers = req.headers;
        params["companyId"] = headers.company_id
        params["locations"]= headers.locations
        params = keysToBeSearchedInJWT(params,jwt);
        
        var executeQuery = "SELECT CATEGORY_NAME AS Mobile_Model_Category,  CONCAT(Cast(category_name as Varchar(500)) , CONCAT ('_',Cast(sub_category_name as Varchar(500))))  AS NAME , CATEGORY_LOCATION_MAP.CATEGORY_LOCATION_ID, CATEGORY_LOCATION_MAP.CATEGORY_LOCATION_NAME,CATEGORY_LOCATION_MAP.COMPANY_ID,CATEGORY_LOCATION_MAP.COMPANY_NAME FROM CATEGORY_LOCATION_MAP\
        INNER JOIN CATEGORY_MASTER_V2 ON CATEGORY_LOCATION_MAP.CATEGORY_ID = CATEGORY_MASTER_V2.CATEGORY_ID\
        WHERE CATEGORY_LOCATION_MAP.COMPANY_ID = "+params.companyId+" AND CATEGORY_MASTER_V2.CLASS_ID =(SELECT CLASS_ID FROM CLASS_MASTER WHERE CLASS_NAME ='Mobile Devices') AND CATEGORY_LOCATION_ID = "+params.locations+";";
        console.log("executeQuery : ",executeQuery);
        var data = await runQuery(executeQuery,[]);
        res.status(200).json(data);
     
    }catch(error){
        console.log("Error is : ",Error);
        res.status(400).send("Error Occurred");
        return next(error);
    }
})

/*GET All category */
router.get('/',async function(req,res,next){       
    try{
        var executeQuery = `SELECT ${selectColumnList} FROM ${categoriesTable} `;
        var data = await runQuery(executeQuery,[]);
        logger.info(`${req.ip} REST get all category request completed`,data);
        res.status(200).json(data);
    }catch(error){
        console.log("Error is :",error);
        res.status(400).send("Error Occurred");
        return next(error);
    } 
})
/*GET category by id*/
router.get('/:cat_id',async function(req,res,next){   
    try{
        
        var executeQuery = `SELECT ${selectColumnList} FROM ${categoriesTable} WHERE category_id=?`;
        var data = await runQuery(executeQuery,[req.params.cat_id]);
        logger.info(`${req.ip} REST get by category id request completed`,data);
        res.status(200).json(data);

    }catch(error){

        console.log("Error is : ",error);
        res.status(400).send("Error Occurred");
        return next(error);
    }              
})


/*post category*/
router.post('/',async function(req,res,next){       
    var body=_.pick(req.body,['category_name','sub_category_name','status','class_id']); 
    try{

        var executeQuery = `SELECT ${selectColumnList} FROM FINAL TABLE (INSERT INTO ${categoriesTable} (category_name,sub_category_name,status,class_id) values (?,?,?,?))`;
        var data = await runQuery(executeQuery,[body.category_name,body.sub_category_name,body.status,body.class_id]);
        logger.info(`${req.ip} REST post CI attributes by id request completed for `,body);  
        res.status(200).json(data);

    }catch(error){

        console.log("Error is : ",error);
        res.status(400).send("Error Occurred");
        return next(error);
    }            
})

/*patch category according to category_id*/
router.patch('/:cat_id',async function(req,res,next){    
    
    var cat_id=req.params.cat_id;   
    var body=_.pick(req.body,['category_name','sub_category_name','status','class_id']); 

    var valuesArr=[],keysArr=[];
    for(key in body){
        keysArr.push(key+"= ?");        
        valuesArr.push(body[key]);
    }
    try{
        var executeQuery = `SELECT ${selectColumnList} FROM FINAL TABLE (UPDATE ${categoriesTable} SET `+keysArr.toString()+` WHERE category_id=`+cat_id+`)`;
        var data = await runQuery(executeQuery,valuesArr);
        logger.info(`${req.ip} REST patch category by id request completed for `,data);  
        res.status(200).json(data[0]) ;
        
    }catch(error){
        console.log("Error inside patch get(/:cat:id) is : ",error);
        res.status(400).send("Error Occurred");
        return next(error);
    }
})

/**
 * Sub categories start here
 */

 /*GET All sub categories */
 router.get('/:cat_id/subcategories',async function(req,res,next){   
    
    try{
        var executeQuery = "SELECT * FROM sub_category_master WHERE category_id=? ";
        var data = await runQuery(executeQuery,[req.params.cat_id]);
        logger.info(`${req.ip} REST get all sub categories request completed`);   
        res.status(200).json(data);

    }catch(error){
        console.log("Error inside get(/:cat_id/subcategories)");
        res.status(400).send("Error Occurred");
        return next(error);
    }
});

 /*GET sub categories  by id*/
 router.get('/:cat_id/subcategories/:sub_cat_id',async function(req,res,next){   
    
    try{
        var executeQuery = "SELECT * FROM sub_category_master WHERE category_id=? AND sub_category_id=?";
        var data = await runQuery(executeQuery,[req.params.cat_id,req.params.sub_cat_id]);
        logger.info(`${req.ip} REST get sub categories by id request completed`,data[0]);   
        res.status(200).json(data);

    }catch(error){
        console.log("Error inside get(/:cat_id/subcategories/:sub_cat_id) is :",error);
        res.status(400).send("Error Occurred");
        return next(error);
        
    }
})

/*post category*/
router.post('/:cat_id/subcategories/',async function(req,res,next){       
    
    var body=_.pick(req.body,['sub_category_name','status']); 
    body.category_id=req.params.cat_id;
    try{
        var executeQuery = "SELECT * FROM FINAL TABLE (INSERT INTO sub_category_master (sub_category_name,status,category_id) values (?,?,?))";
        var data =  await runQuery(executeQuery,[body.sub_category_name,body.status,body.category_id]);
        logger.info(`${req.ip} REST post CI attributes by id request completed for `,body);
        res.status(200).json(data[0]); 


    }catch(error){
        console.log("Error inside  post('/:cat_id/subcategories/:sub_cat_id') is : ",error);
        res.status(400).send("Error Occurred");
        return next(error);
    }              
})

/*patch request sub categories */
router.patch('/:cat_id/subcategories/:sub_cat_id',async function(req,res,next){       
    
    var sub_cat_id=req.params.sub_cat_id; 
    var cat_id=req.params.cat_id;   
    
    var body=_.pick(req.body,['sub_category_name','status']); 

    var valuesArr=[],keysArr=[];
    for(key in body){
        keysArr.push(key+"= ?");        
        valuesArr.push(body[key]);
    }
    try{
          var executeQuery = "SELECT * FROM FINAL TABLE (UPDATE sub_category_master SET "+keysArr.toString()+" WHERE category_id="+cat_id+" AND sub_category_id="+sub_cat_id+")"
          var data = await runQuery(executeQuery,valuesArr);
          logger.info(`${req.ip} REST patch sub category by cat/sub_id request completed for `,data);
          res.status(200).json(data[0]); 

    }catch(error){
        console.log("Error inside patch('/:cat_id/subcategories/:sub_cat_id') is :  ",error);
        res.status(400).send("Error Occurred");
        return next(error);        

    }
});

module.exports = router;