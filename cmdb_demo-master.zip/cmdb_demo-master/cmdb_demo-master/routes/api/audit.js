const {config} = require('./../../config/serversetup');
const {epochToDateFormat, runQuery} = require('./../../config/functions');
const express=require('express');
var router=express.Router();
const _=require('lodash');
const moment=require('moment');

/**
 * constant for audit
 */
const loggerName="audit";
const dbTableName="audit";
const dbTableId="item_id";

const fieldArray=["METALLIC","ENVIRONMENT","MANUFACTURER","DATASET",
                "STATUS","CATEGORY_ID","SUB_CATEGORY_ID","LOCATION_NAME",
                "GROUP_NAME","OWNER_NAME","COMPANY_NAME","CLASS"];

/**
 * queries for chain entities
 */



//const getAllQuery=`SELECT * FROM ${dbTableName}`;
//const getByIdQuery=`SELECT * FROM ${dbTableName} WHERE ${dbTableId}=?`;

const getAllQuery=`SELECT
*
,CASE 
    WHEN AUDIT_FIELD='METALLIC' THEN (select FIELD1_KEY from MENULIST WHERE FIELD1_NAME='Metallic' AND FIELD1_VALUE=FROM)
    WHEN AUDIT_FIELD='ENVIRONMENT' THEN (select FIELD1_KEY from MENULIST WHERE FIELD1_NAME='Environment' AND FIELD1_VALUE=FROM)
    WHEN AUDIT_FIELD='MANUFACTURER' THEN (select FIELD1_KEY from MENULIST WHERE FIELD1_NAME='Manufacturer' AND FIELD1_VALUE=FROM)
    WHEN AUDIT_FIELD='DATASET' THEN (select FIELD1_KEY from MENULIST WHERE FIELD1_NAME='Dataset' AND FIELD1_VALUE=FROM)
    WHEN AUDIT_FIELD='STATUS' THEN (select FIELD1_KEY from MENULIST WHERE FIELD1_NAME='Status' AND FIELD1_VALUE=FROM)
    WHEN AUDIT_FIELD='CATEGORY_ID' THEN (select CONCAT(Cast(category_name as Varchar(500)) , CONCAT ('|',Cast(sub_category_name as Varchar(500)))) AS CATEGORY_NAME from CATEGORY_MASTER_V2 WHERE CAST(CATEGORY_ID AS CHAR(20))=FROM) 
    WHEN AUDIT_FIELD='SUB_CATEGORY_ID' THEN (select SUB_CATEGORY_NAME from SUB_CATEGORY_MASTER WHERE CAST(SUB_CATEGORY_ID AS CHAR(20))=FROM) 
    WHEN AUDIT_FIELD='LOCATION_NAME' THEN (select LOCATION_NAME from CONFIG_ITEMS WHERE CAST(LOCATION_ID AS CHAR(20)) =FROM FETCH FIRST 1 ROWS ONLY) 
    WHEN AUDIT_FIELD='GROUP_NAME' THEN (select GROUP_NAME from CONFIG_ITEMS WHERE CAST(GROUP_ID AS CHAR(20))=FROM FETCH FIRST 1 ROWS ONLY)
    WHEN AUDIT_FIELD='OWNER_NAME' THEN (select OWNER_NAME from CONFIG_ITEMS WHERE CAST(OWNER_ID AS CHAR(20))=FROM FETCH FIRST 1 ROWS ONLY)
    WHEN AUDIT_FIELD='COMPANY_NAME' THEN (select COMPANY_NAME from CONFIG_ITEMS WHERE CAST(COMPANY_ID AS CHAR(20))=FROM FETCH FIRST 1 ROWS ONLY)
    WHEN AUDIT_FIELD='CLASS' THEN (select CLASS_NAME from CLASS_MASTER WHERE CAST(CLASS_ID AS CHAR(20))=FROM FETCH FIRST 1 ROWS ONLY)
    ELSE FROM
 END AS FROMNAME,
 CASE 
        WHEN AUDIT_FIELD='METALLIC' THEN (select FIELD1_KEY from MENULIST WHERE FIELD1_NAME='Metallic' AND FIELD1_VALUE=TO)  
        WHEN AUDIT_FIELD='ENVIRONMENT' THEN (select FIELD1_KEY from MENULIST WHERE FIELD1_NAME='Environment' AND FIELD1_VALUE=TO)
        WHEN AUDIT_FIELD='MANUFACTURER' THEN (select FIELD1_KEY from MENULIST WHERE FIELD1_NAME='Manufacturer' AND FIELD1_VALUE=TO)
        WHEN AUDIT_FIELD='DATASET' THEN (select FIELD1_KEY from MENULIST WHERE FIELD1_NAME='Dataset' AND FIELD1_VALUE=TO)
        WHEN AUDIT_FIELD='STATUS' THEN (select FIELD1_KEY from MENULIST WHERE FIELD1_NAME='Status' AND FIELD1_VALUE=TO)
        WHEN AUDIT_FIELD='CATEGORY_ID' THEN (select CONCAT(Cast(category_name as Varchar(500)) , CONCAT ('|',Cast(sub_category_name as Varchar(500)))) AS CATEGORY_NAME from CATEGORY_MASTER_V2 WHERE CAST(CATEGORY_ID AS CHAR(20))=TO) 
        WHEN AUDIT_FIELD='SUB_CATEGORY_ID' THEN (select SUB_CATEGORY_NAME from SUB_CATEGORY_MASTER WHERE CAST(SUB_CATEGORY_ID AS CHAR(20))=TO) 
        WHEN AUDIT_FIELD='LOCATION_NAME' THEN (select LOCATION_NAME from CONFIG_ITEMS WHERE CAST(LOCATION_ID AS CHAR(20)) =TO FETCH FIRST 1 ROWS ONLY) 
        WHEN AUDIT_FIELD='GROUP_NAME' THEN (select GROUP_NAME from CONFIG_ITEMS WHERE CAST(GROUP_ID AS CHAR(20))=TO FETCH FIRST 1 ROWS ONLY)
        WHEN AUDIT_FIELD='OWNER_NAME' THEN (select OWNER_NAME from CONFIG_ITEMS WHERE CAST(OWNER_ID AS CHAR(20))=TO FETCH FIRST 1 ROWS ONLY) 
        WHEN AUDIT_FIELD='COMPANY_NAME' THEN (select COMPANY_NAME from CONFIG_ITEMS WHERE CAST(COMPANY_ID AS CHAR(20))=TO FETCH FIRST 1 ROWS ONLY)
        WHEN AUDIT_FIELD='CLASS' THEN (select CLASS_NAME from CLASS_MASTER WHERE CAST(CLASS_ID AS CHAR(20))=TO FETCH FIRST 1 ROWS ONLY)
        ELSE TO
    END AS TONAME
FROM ${dbTableName} `;


const getByIdQuery=`${getAllQuery} WHERE ${dbTableId}=? `;

/**
 * Get all request for audit
 */

router.get('/',async function(req,res,next){ 
    try{
        let data = await runQuery(getAllQuery,[]);
        logger.info(`${req.ip} REST get all ${loggerName} request completed`);

        data = data.map(function(item){
            let m = moment.unix(item.CREATED_ON);
            item.CREATED_ON = m.format("DD-MM-YYYY HH:mm:ss");
            return item;
        });
        res.status(200).json(data);
        
    }catch(error){
        console.log("Error inside get(/) of audit.js is :",error);
        res.status(400).send("Error occured");
        return next(error);
    }                 
});

/*GET  by id request for audit*/
router.get('/:id',async function(req,res,next){       

    var jwt = req.decodedJWT;
    var dateFormat = jwt.date_format;
    var offset = jwt.offset;
    const queryParams=_.pick(req.query,['queryBy']); 
    let queryString='';
    if(queryParams.queryBy !== undefined && queryParams.queryBy != null){
        queryParams.queryBy=queryParams.queryBy.toUpperCase()
        if (fieldArray.indexOf(queryParams.queryBy) > -1) {
            queryString=` AND UPPER(AUDIT_FIELD) LIKE '${queryParams.queryBy}'`;
        }
    }
    try{

        var executeQuery =getByIdQuery+queryString+' ORDER BY CREATED_ON DESC '; 
        let data = await runQuery(executeQuery,[parseInt(req.params.id)]);
        logger.info(`${req.ip} REST get all according to item_id and audit_field  ${loggerName} request completed`);
        data = await epochToDateFormat(dateFormat,offset,data);
        res.status(200).json(data);

    }catch(error){
        console.log("Error is : ",error);
        res.status(400).send("Error occurred");
        return next(error);

    }               
})

module.exports = router;


/**
     * @swagger
     * definitions:
     *   User:
     *     properties:
     *       firstName:
     *         type: string
     *       lastName:
     *         type: string
     *       email:
     *         type: string
     *       password:
     *         type: string
     *       role:
     *         type: string
     */

        /**
         * @swagger
         * /user/{id}:
         *   get:
         *     tags:
         *       - User
         *     description: Get specific user
         *     produces:
         *       - application/json
	 *     parameters:
	 *       - name: id
	 *         description: User id
	 *         in: path
	 *         required: true
	 *         type: string
         *     responses:
         *       200:
         *         description: Get user by id
         */