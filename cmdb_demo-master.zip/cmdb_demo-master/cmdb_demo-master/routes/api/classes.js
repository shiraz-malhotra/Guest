const {config} = require('./../../config/serversetup');
const {epochToDateFormat,runQuery} = require('./../../config/functions');
const express=require('express');
var router=express.Router();
const _=require('lodash');

/*GET All classes */
router.get('/',async function(req,res,next){       
    
    try{
        var executeQuery = "SELECT * FROM class_master ORDER BY class_name ASC";
        var data = await runQuery(executeQuery,[]);
        logger.info(`${req.ip} REST get all classes request completed`);
        res.status(200).json(data);

    }catch(error){
        console.log("Error is : ",error);
        res.status(400).send("Error Occurred");
        return next(error);

    }         
});


/*GET class by id*/
router.get('/:class_id',async function(req,res,next){     
    try{
        var executeQuery = "SELECT * FROM class_master WHERE class_id=?";
        var data = await runQuery(executeQuery,[req.params.class_id]);
        logger.info(`${req.ip} REST get by class id request completed`,data); 
        res.status(200).json(data[0]);


    }catch(error){
        console.log("Error is: ",error);
        res.status(400).send("Error Occurred");
        return next(error);
    }                
});


/*post class*/
router.post('/',async function(req,res,next){       
    var body=_.pick(req.body,['class_name','parent_class_id','status']); 

    logger.info(`${req.ip} class post request for `,body);
    var valuesArr=[],keysArr=[],comma=[];
    for(key in body){
        keysArr.push(key);
        comma.push("?");
        valuesArr.push(body[key]);
    }
    
    try{
        var executeQuery = "SELECT * FROM FINAL TABLE (INSERT INTO class_master ("+keysArr.toString()+") values ("+comma.toString()+"))";
        var data = await runQuery(executeQuery,valuesArr);
        logger.info(`${req.ip} REST post new class addition request completed for `,data);
        res.status(200).json(data[0]);

    }catch(error){
        console.log("Error is : ",error);
        res.status(400).send("Error Occurred");
        return next(error);
    }            
});

/*patch class*/
router.patch('/:class_id',async function(req,res,next){    
    
    var class_id=req.params.class_id;   
    var body=_.pick(req.body,['class_name','parent_class_id','status']); 

    var valuesArr=[],keysArr=[];
    for(key in body){
        keysArr.push(key+"= ?");        
        valuesArr.push(body[key]);
    }
    try{
        var executeQuery = "SELECT * FROM FINAL TABLE (UPDATE class_master SET "+keysArr.toString()+" WHERE class_id="+class_id+")";
        var data = await runQuery(executeQuery,valuesArr);
        logger.info(`${req.ip} REST patch class by id request completed for `,data);
        res.status(200).json(data[0])

    }catch(error){
        console.log("Error is : ",error);
        res.status(400).send("Error Occurred");
        return next(error);
    }             
});

router.post('/:id/hierarchy/',async function(req,res,next){
    console.log("called");
    if(req.body.hierarchy=="upward")
        str=" where c.parent_class_id=p.class_id";
    else
        str=" where c.class_id=p.parent_class_id";
    try{
        var executeQuery = "with result(class_id,parent_class_id,class_name) as\
        ( select r.class_id,r.parent_class_id,r.class_name\
            from class_master r\
            where r.class_id="+req.params.id+"\
            UNION ALL\
            select p.class_id,p.parent_class_id,p.class_name\
            from result c,class_master p"+str+"\
        )\
        select * from result";

        var data = await runQuery(executeQuery,[]);
        logger.info(`${req.ip} REST get class hierarchy by class id request completed for `,data);
        res.status(200).json(data);       
    }catch(error){
        console.log("Error is : ",error);
        res.status(400).send("Error Occurred");
        return next(error);
    }
});

/**
 * class routing ends here
 * category  routing start from here
 * 
 * 
 */
const categoriesTable="category_master_v2";
const selectColumnList=`category_id, CONCAT(Cast(category_name as Varchar(500)) , CONCAT ('|',Cast(sub_category_name as Varchar(500)))) AS category_name,status,class_id`;
  
 /*GET All category */
 router.get('/:class_id/categories',async function(req,res,next){       
    try{
        var executeQuery = `SELECT ${selectColumnList} FROM ${categoriesTable} WHERE class_id=?`;
        var data = await runQuery(executeQuery,[req.params.class_id]);
        logger.info(`${req.ip} REST get all category request completed`); 
        res.status(200).json(data);
    }catch(error){
        console.log("error is : ",error);
        res.status(400).send("Error Occurred");
        return next(error);
    }            
})


/*GET category by id*/
router.get('/:class_id/categories/:cat_id',async function(req,res,next){ 
    try{
        var executeQuery = `SELECT ${selectColumnList} FROM ${categoriesTable} WHERE class_id=? AND category_id=?`;
        var data = await runQuery(executeQuery,[req.params.class_id,req.params.cat_id]);
        logger.info(`${req.ip} REST get by category id request completed`,data[0]);
        res.status(200).json(data[0]); 

    }catch(error){
        console.log("Error is : ",error);
        res.status(400).send("Error Occurred");
        return next(error);
    }                
});

/*post category for a class*/
router.post('/:class_id/categories/',async function(req,res,next){    
    
    var body=_.pick(req.body,['category_name','sub_category_name','status']);
    body.class_id= req.params.class_id;
    try{
        var executeQuery = `SELECT ${selectColumnList} FROM FINAL TABLE (INSERT INTO ${categoriesTable} (category_name,sub_category_name,class_id,status) values (?,?,?,?))`;
        var data = await runQuery(executeQuery,[body.category_name,body.sub_category_name,body.class_id,body.status]);
        logger.info(`${req.ip} REST post add new category by class id request completed for `,body);
        res.status(200).json(data[0]);

        
    }catch(error){
        console.log("Error is : ",error);
        res.status(400).send("Error Occurred");
        return next(error);
    }                
})

/*patch category for a calss*/
router.patch('/:class_id/categories/:cat_id',async function(req,res,next){ 
    
    var cat_id=req.params.cat_id;   
    var class_id=req.params.class_id;
    var body=_.pick(req.body,['category_name','sub_category_name','status']); 

    var valuesArr=[],keysArr=[];
    for(key in body){
        keysArr.push(key+"= ?");        
        valuesArr.push(body[key]);
    }
    try{
        var executeQuery = `SELECT ${selectColumnList} FROM FINAL TABLE (UPDATE ${categoriesTable} SET `+keysArr.toString()+" WHERE category_id="+cat_id+" AND class_id="+class_id+")";
        var data = await runQuery(executeQuery,valuesArr);
        logger.info(`${req.ip} REST patch category by cat_id and class_id request completed for `,data[0]); 
        res.status(200).json(data[0]);
        
    }catch(error){
        console.log(" Error is : ",error);
        res.status(400).send("Error Occurred");
        return next(error);
    }              
});


/**
 * categories api ends here
 * Sub categories start here
 */

 /*GET All sub categories */
 router.get('/:class_id/categories/:cat_id/subcategories',async function(req,res,next){   
    try{
        var executeQuery = "SELECT * FROM sub_category_master WHERE category_id=? ";
        var data = await runQuery(executeQuery,[req.params.cat_id]);
        logger.info(`${req.ip} REST get all sub categories request completed`);   
        res.status(200).json(data);
    }catch(error){
        console.log(" Error inside get('/') is : ",error);
        res.status(400).send("Error Occurred");
        return next(error);
    }               
})

 /*GET sub categories  by id*/
 router.get('/:class_id/categories/:cat_id/subcategories/:sub_cat_id',async function(req,res,next){   
    
    try{
        var executeQuery = "SELECT * FROM sub_category_master WHERE category_id=? AND sub_category_id=?"; 
        var data = await runQuery(executeQuery,[req.params.cat_id,req.params.sub_cat_id]);
        logger.info(`${req.ip} REST get sub categories by id request completed`,data[0]);
        res.status(200).json(data[0]);
    }catch(error){
        console.log(" Error is : ",error);
        res.status(400).send("Error Occurred");
        return next(error);
    }            
})

/*post sub categories */
router.post('/:class_id/categories/:cat_id/subcategories/',async function(req,res,next){       
    var body=_.pick(req.body,['sub_category_name','status']); 
    body.category_id=req.params.cat_id;   
    try{
        var executeQuery = "SELECT * FROM FINAL TABLE (INSERT INTO sub_category_master (sub_category_name,status,category_id) values (?,?,?))"; 
        var data = await runQuery(executeQuery,[body.sub_category_name,body.status,body.category_id]);
        logger.info(`${req.ip} REST post CI attributes by id request completed for `,body);
        res.status(200).json(data[0]);

    }catch(error){
        console.log(" Error is : ",error);
        res.status(400).send("Error Occurred");
        return next(error);
    }               
})

/*patch request sub categories */
router.patch('/:class_id/categories/:cat_id/subcategories/:sub_cat_id',async function(req,res,next){       
  
    var sub_cat_id=req.params.sub_cat_id; 
    var cat_id=req.params.cat_id;   
    //var class_id=req.params.class_id;
    var body=_.pick(req.body,['sub_category_name','status']); 

    var valuesArr=[],keysArr=[];
    for(key in body){
        keysArr.push(key+"= ?");        
        valuesArr.push(body[key]);
    }

    try{
        var executeQuery = "SELECT * FROM FINAL TABLE (UPDATE sub_category_master SET "+keysArr.toString()+" WHERE category_id="+cat_id+" AND sub_category_id="+sub_cat_id+")";
        var data = await runQuery(executeQuery,valuesArr);
        logger.info(`${req.ip} REST patch sub category by class/cat/sub_id request completed for `,data[0]); 
        res.status(200).json(data[0]);


    }catch(error){
        console.log(" Error is : ",error);
        res.status(400).send("Error Occurred");
        return next(error);
    }   
})


/**
 * attributes master query
 */
/*post category for a class*/
router.post('/:class_id/attributes/',async function(req,res,next){       
    var body=_.pick(req.body,['attribute_name','status','mandatory']);
    body.class_id= req.params.class_id;   
    try{
        var executeQuery = "SELECT * FROM FINAL TABLE (INSERT INTO attribute_master (attribute_name,class_id,status,mandatory) values (?,?,?,?))";
        var data = await runQuery(executeQuery,[body.attribute_name,body.class_id,body.status,body.mandatory]);
        logger.info(`${req.ip} REST post add new attribute by class id request completed for `,data[0]);
        res.status(200).json(data[0]);


    }catch(error){
        console.log("Error is : ",error);
        res.status(400).send("Error Occurred");
        return next(error);
    }             
})

module.exports = router;