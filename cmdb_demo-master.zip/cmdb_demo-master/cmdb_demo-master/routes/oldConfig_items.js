const {runQuery} = require('./../../config/functions');

const {patch_call_cmdb_interface,checkIsExistInDb} = require('./../../config/functions');
const express=require('express');
var router=express.Router();
const _=require('lodash');

/* code generator */
codeGeneratorMethod=(code,id) =>{
    var res=code;
    for(i=0;i<15-(code.length+id.toString().length);i++){
        res+='0';
    }
    res+=id.toString();
    return res;
} 

/**
 * Constant names  
 */


 const ci_code_prefix="ASTCI";

/* REST POST cmdb-spcm-interface request */
router.post("/cmdb-spcm-interface",async function(req,res,next){
 
  //  const attributes=_.pick(req.body,['attributes']).attributes;   

   // const attributes_query='INSERT INTO ci_attribute_mapping (ci_id,attr_id,value) values (?,?,?)';
   

    // if(attributes.length>0){        
    //    const reformattedArray = attributes.map(async function(obj) {        
    //     const result= await runQuery(attributes_query,[obj.ci_id,obj.attr_id,obj.value]);
    //         return result;
    //      });
    // }


    const constantQuery=`SELECT FIELD1_KEY,FIELD1_VALUE FROM MENULIST WHERE MODULE='SPCM_CMDB_INTERFACE'`;

    const constantQueryResult=await runQuery(constantQuery,[]);

    const statusArr={ Deployed:0,Suspended:0,Obsolete:0}
    let service_class_id=2,manufacturer_id=35;
    constantQueryResult.forEach((tempConstant)=>{              
        statusArr.Deployed=tempConstant.FIELD1_KEY=='Deployed'?tempConstant.FIELD1_VALUE:statusArr.Deployed;
        statusArr.Suspended=tempConstant.FIELD1_KEY=='Suspended'?tempConstant.FIELD1_VALUE:statusArr.Suspended;
        statusArr.Obsolete=tempConstant.FIELD1_KEY=='Obsolete'?tempConstant.FIELD1_VALUE:statusArr.Obsolete;
        service_class_id=tempConstant.FIELD1_KEY=='class_id'?tempConstant.FIELD1_VALUE:service_class_id;
        manufacturer_id=tempConstant.FIELD1_KEY=='manufacturer_id'?tempConstant.FIELD1_VALUE:manufacturer_id;
    })


    var body=_.pick(req.body,['ci_name','company_id','company_name','status',
                    'description','created_by','support_company_id','support_company_name',
                    'business_owner_id','business_owner_name', 'technical_owner_id','technical_owner_name',
            'editable','spcm_category_id','spcm_category_name','group_id','group_name','spcm_offering_id' ]); 
    body.ci_code="ci_code123";
    body.class_id=service_class_id;
    body.manufacturer=manufacturer_id;
    body.editable="N";
    body.CATEGORY_ID=0;
    body.SUB_CATEGORY_ID=0; 
    body.OWNER_ID=0;
    body.OWNER_NAME="";
    body.LOCATION_ID=0;
    body.LOCATION_NAME="";   
    body.status=statusArr[body.status]||0; 

    logger.info(`${req.ip} Config Item Post request for `,body);
    var valuesArr=[],keysArr=[],comma=[];
    for(key in body){
        keysArr.push(key);
        comma.push("?");
        valuesArr.push(body[key]);
    }
    keysArr.push('created_at');
    db.query("SELECT ci_id FROM FINAL TABLE (INSERT INTO config_items ("+keysArr.toString()+") values ("+comma.toString()+",CURRENT TIMESTAMP))",valuesArr,function(err,data){
        if(err) return next(err);          
        var new_ci_code=codeGeneratorMethod(ci_code_prefix,data[0].CI_ID);
        console.log(new_ci_code);
        db.query("SELECT * FROM FINAL TABLE (UPDATE config_items SET ci_code=? WHERE ci_id="+data[0].CI_ID+")",[new_ci_code],function(ierr,idata){
            if(ierr) return next(ierr);
            logger.info(`${req.ip} REST Post request completed for `,body);   
            res.status(200).json(idata[0]);     
        })
            
    })  
    
 })


 /* REST patch cmdb-spcm-interface request */
router.patch("/cmdb-spcm-interface/:id",async function(req,res,next){

    var id=req.params.id;      
    try {
  
   // const attributes=_.pick(req.body,['attributes']).attributes;  

  //  const attributes_query='UPDATE ci_attribute_mapping SET value=? WHERE ci_id=? AND attr_id=?';
  
    // try {
    //         if(attributes.length>0){        
    //         const reformattedArray = attributes.map(async function(obj) {        
    //             const result=obj.value!=''? await runQuery(attributes_query,[obj.value,obj.ci_id,obj.attr_id]):false;
    //                 return result;
    //             });
    //         }
    //     } catch (error) {
    //          next(error);   
    //     }

    const constantQuery=`SELECT FIELD1_KEY,FIELD1_VALUE FROM MENULIST WHERE FIELD1_NAME='ServiceClassStatus' AND MODULE='SPCM_CMDB_INTERFACE'`;

    const constantQueryResult=await runQuery(constantQuery,[]);

    const statusArr={ Deployed:0,Suspended:0,Obsolete:0}

    constantQueryResult.forEach((tempConstant)=>{              
        statusArr.Deployed=tempConstant.FIELD1_KEY=='Deployed'?tempConstant.FIELD1_VALUE:statusArr.Deployed;
        statusArr.Suspended=tempConstant.FIELD1_KEY=='Suspended'?tempConstant.FIELD1_VALUE:statusArr.Suspended;
        statusArr.Obsolete=tempConstant.FIELD1_KEY=='Obsolete'?tempConstant.FIELD1_VALUE:statusArr.Obsolete;
    })


    var body=_.pick(req.body,['ci_name','company_id','company_name','status',
    'description','updated_by','support_company_id','support_company_name',
    'business_owner_id','business_owner_name', 'technical_owner_id','technical_owner_name',
    'editable','spcm_category_id','spcm_category_name','group_id','group_name']);

    body.status=statusArr[body.status]||0;

    logger.info(`${req.ip} Config Item patch request for `,body);
    var valuesArr=[],keysArr=[];
    for(key in body){
        keysArr.push(key+"= ?");        
        valuesArr.push(body[key]);
    }
    keysArr.push("updated_at=CURRENT_TIMESTAMP");
    db.query("SELECT * FROM FINAL TABLE (UPDATE config_items SET "+keysArr.toString()+" WHERE ci_id="+id+")",valuesArr,function(err,data){
        if(err) return next(err);
        logger.info(`${req.ip} REST Update By ID request completed for ${id}`);   
        res.status(200).json(data);       
            
    })
    } catch (error) {
             next(error);   
        }
          
 })


 const unique_query=`SELECT COUNT(*) as duplicate FROM config_items
                    WHERE UPPER(ci_name) Like ?`;


/* REST POST request */
router.post("/", async function(req,res,next){

    try {
        
   
    var body=_.pick(req.body,['ci_name','class_id','asset_tag','company_id','company_name','status',
                    'category_id','sub_category_id','group_id','group_name','owner_id',
                'owner_name','location_id','location_name','dataset','manufacturer',
                'environment','metallic','description','created_by',
            'support_company_id','support_company_name','business_owner_id','business_owner_name',
            'technical_owner_id','technical_owner_name']); 
    body.ci_code="ci_code123";

    logger.info(`${req.ip} REST Post request completed for `,body);  
    const isExist=await checkIsExistInDb(unique_query,[body.ci_name.toUpperCase()]) ;
    
    logger.info(`${req.ip} Config Item Post request for `,body);

    if(!isExist ){
    var valuesArr=[],keysArr=[],comma=[];
    for(key in body){
        keysArr.push(key);
        comma.push("?");
        valuesArr.push(body[key]);
    }
    keysArr.push('created_at');
    db.query("SELECT ci_id FROM FINAL TABLE (INSERT INTO config_items ("+keysArr.toString()+") values ("+comma.toString()+",CURRENT TIMESTAMP))",valuesArr,function(err,data){
        if(err) return next(err);          
        var new_ci_code=codeGeneratorMethod(ci_code_prefix,data[0].CI_ID);
        console.log(new_ci_code);
        db.query("SELECT * FROM FINAL TABLE (UPDATE config_items SET ci_code=? WHERE ci_id="+data[0].CI_ID+")",[new_ci_code],function(ierr,idata){
            if(ierr) return next(ierr);
            logger.info(`${req.ip} REST Post request completed for `,body);   
            res.status(200).json(idata);       
                
        })
            
    }) 
}//if
else{
       
    const ci_name="CI name already exist";
    res.status(500).json([{ci_name}]); 
}
    } catch (error) {
         next(error);   
    }
          
 })



/* REST patch request */
router.patch("/:id",async function(req,res,next){    

    let reqParamArray=['ci_name','class_id','asset_tag','company_id','company_name','status',
    'category_id','sub_category_id','group_id','group_name','owner_id',
'owner_name','location_id','location_name','dataset','manufacturer',
'environment','metallic','description','updated_by',
'support_company_id','support_company_name','business_owner_id','business_owner_name',
'technical_owner_id','technical_owner_name'];
    var id=req.params.id; 


       
    var body=_.pick(req.body,reqParamArray); 
    const patch_unique_query=`${unique_query} AND CI_ID NOT IN (?)`;

    const isExist=await checkIsExistInDb(patch_unique_query,[body.ci_name.toUpperCase(),id]) ;

    // try{

    //     let temp=await runQuery('SELECT SPCM_OFFERING_ID FROM config_items WHERE ci_id=? ',[id]);  
    //     if(temp[0].SPCM_OFFERING_ID){
    //         console.log(temp[0].SPCM_OFFERING_ID);
    //         logger.info(`yeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee`);  
    //         reqParamArray=['asset_tag','location_id','location_name',
    //         'dataset','manufacturer','environment','metallic','updated_by'];
    //     }
    //    }catch (err) {        
            
    //         next(err);
    // }



    if(!isExist ){
      
    logger.info(`${req.ip} Config Item patch request for `,body);
    var valuesArr=[],keysArr=[];
    for(key in body){
        keysArr.push(key+"= ?");        
        valuesArr.push(body[key]);
    }
    keysArr.push("updated_at=CURRENT_TIMESTAMP");
    db.query("SELECT * FROM FINAL TABLE (UPDATE config_items SET "+keysArr.toString()+" WHERE ci_id="+id+")",valuesArr,async function(err,data){
        if(err) return next(err);
        logger.info(`${req.ip} REST Update By ID request completed for ${id}`);  
                
        // if(data[0].SPCM_OFFERING_ID){
        //     console.log("Yes:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
         
        //         try{                
        //           let catalogueData={chain_type:'catalogue',
        //           chain_person_id:data[0].BUSINESS_OWNER_ID,
        //           chain_person_name:data[0].BUSINESS_OWNER_NAME
        //         };
        //         let supportData={chain_type:'Support',
        //         chain_company_id:data[0].SUPPORT_COMPANY_ID,
        //         chain_company:data[0].SUPPORT_COMPANY_NAME,
        //         chain_group_id:data[0].GROUP_ID,
        //         chain_group_name:data[0].GROUP_NAME,
        //         chain_person_id:data[0].TECHNICAL_OWNER_ID,
        //         chain_person_name:data[0].TECHNICAL_OWNER_NAME               
        //       };                   
        //           let  tempVar=await patch_call_cmdb_interface([catalogueData,supportData],data[0].SPCM_OFFERING_ID);
        //             console.log("Not Null",tempVar);
        //            }catch (err) {   
        //                 next(err);
        //         }               
        // }
        res.status(200).json(data);       
            
    })

}{
    res.status(400).json({message:"No data found"});  
} 
          
 })




/*GET all CIs */
router.get('/',function(req,res,next){

  
    const queryParams=_.pick(req.query,['searchByList','multipleValueList']); 

    let conditionString='';
    const orderByString=' ORDER BY created_at DESC ';
  
    let isQueryBy=typeof queryParams.searchByList !== 'undefined' && queryParams.searchByList  !== null;
    let isQueryValue=typeof queryParams.multipleValueList !== 'undefined' && queryParams.multipleValueList!== null;
   
    if(isQueryBy&&isQueryValue){
        var searchArray = queryParams.searchByList.split(",");
        var multipleValueListArray = queryParams.multipleValueList.split("|");

        if(searchArray.length==multipleValueListArray.length){

            conditionString=' WHERE ';

            for(let i=0;i<searchArray.length;i++){


                let inValueArray=multipleValueListArray[i].split(",");
                let inValue='';
               
                for(let j=0;j<inValueArray.length;j++){
                    inValue+=j===inValueArray.length-1?`\'${inValueArray[j]}\'`:`\'${inValueArray[j]}\',`;
                }  
             
         
                let tempVar=i===searchArray.length-1?`${searchArray[i]} IN (${inValue}) `:`${searchArray[i]} IN (${inValue}) AND `;          
                conditionString+=tempVar;                  
            }
        }

    }


    logger.info(`${req.ip} REST Get All request received`);  
    str="";
    if(req.query.queryBy){
       str+=" where UPPER("+req.query.queryBy+") LIKE '%"+req.query.value.toUpperCase()+"%' AND company_id="+req.query.company_id;
    }
    db.query("WITH new_config_items AS (SELECT md.field1_key as dataset_name,mf.field1_key as manufacturer_name,me.field1_key as environment_name,ms.field1_key as status_name,mm.field1_key as metallic_name,ci_id,ci_code,ci_name,ci.class_id,ci.editable,ci.spcm_category_id,ci.spcm_category_name,ci.created_at,ci.updated_at,ci.created_by,ci.updated_by,class_name,CONCAT(Cast(category_name as Varchar(500)) , CONCAT ('|',Cast(sub_category_name as Varchar(500)))) AS category_name,description,ci.company_id,company_name,ci.status,metallic,environment,group_name,owner_name,location_id,location_name,manufacturer,dataset,support_company_id, support_company_name,business_owner_id,business_owner_name,technical_owner_id,technical_owner_name,asset_tag from config_items as ci\
        left join class_master as cm on ci.class_id=cm.class_id\
        left join category_master_v2 as cat on cat.category_id=ci.category_id\
        left join menulist as ms on ci.status=ms.FIELD1_VALUE AND ms.field1_name='Status'\
        left join menulist as mm on ci.metallic=mm.FIELD1_VALUE AND mm.field1_name='Metallic'\
        left join menulist as me on ci.environment=me.FIELD1_VALUE AND me.field1_name='Environment'\
        left join menulist as mf on ci.manufacturer=mf.FIELD1_VALUE AND mf.field1_name='Manufacturer'\
        left join menulist as md on ci.dataset=md.FIELD1_VALUE AND md.field1_name='Dataset' "+str+" ) \
        SELECT *  FROM new_config_items "+conditionString+orderByString,function(err,data){
            if(err) return next(err);
        else
            res.status(200).json(data);
    })
})


router.get("/relationship",function(req,res,next){
    db.query("with result(ci_id,ci_name,DESCRIPTION,ci_id_related,class_id,class_name,url,created_by,created_at) as\
	(select rcici.ci_id,rci.ci_name,rci.DESCRIPTION,rcici.ci_id_related,rci.class_id,rcm.class_name,rcm.url,rcici.created_by,rcici.created_at \
				from ci_ci_relationship as rcici \
				left join config_items as rci on rcici.ci_id=rci.ci_id\
				left join class_master as rcm on rci.class_id=rcm.class_id\
				 where UPPER(module) LIKE '%"+req.query.module.toUpperCase()+"%' AND rcici.ci_id=?\
		union\
	 select rcici.ci_id,rci.ci_name,rci.DESCRIPTION,rcici.ci_id_related,rci.class_id,rcm.class_name,rcm.url,rcici.created_by,rcici.created_at \
				from ci_ci_relationship as rcici \
				left join config_items as rci on rcici.ci_id=rci.ci_id\
				left join class_master as rcm on rci.class_id=rcm.class_id\
				 where UPPER(module) LIKE '%"+req.query.module.toUpperCase()+"%' AND rcici.ci_id_related=?\
		)\
	,prefinal(ci_id,ci_name,DESCRIPTION,ci_id_related,class_id,class_name,url,class_id_related,class_name_related,url_related,created_by,created_at) as (\
	  select r.ci_id,r.ci_name,r.DESCRIPTION,r.ci_id_related,r.class_id,r.class_name,r.url,ci.class_id as class_id_related,cm.class_name,cm.url as url_related,r.created_by,r.created_at from\
	  result as r left join config_items as ci on r.ci_id_related=ci.ci_id\
	  left join class_master as cm on ci.class_id=cm.class_id\
	  )\
select p.*,r_name from prefinal as p\
	left join class_class_relationship as ccr on p.class_id=ccr.class_id and p.class_id_related=ccr.class_id_related\
	left join relationship_master as r on ccr.r_id=r.r_id",[req.query.ci_id,req.query.ci_id],function(err,data){
            if(err) return next(err);    
            logger.info(`${req.ip} REST get config item relationship request completed for `,data);   
            res.status(200).json(data);  
             } ) 
})
/*GET CI by id */
router.get('/:id',function(req,res,next){
    db.query("SELECT md.field1_key as dataset_name,mf.field1_key as manufacturer_name,me.field1_key as environment_name,ms.field1_key as status_name,mm.field1_key as metallic_name,ci_id,ci_code,ci_name,class_name,ci.class_id,ci.editable,ci.spcm_category_id,ci.spcm_category_name,ci.created_at,ci.updated_at,ci.created_by,ci.updated_by,company_id,company_name,ci.class_id,cat.category_id,CONCAT(Cast(category_name as Varchar(500)) , CONCAT ('|',Cast(sub_category_name as Varchar(500)))) AS category_name,description,ci.status,metallic,environment,group_id,group_name,owner_id,owner_name,location_id,location_name,manufacturer,dataset,support_company_id, support_company_name,business_owner_id,business_owner_name,technical_owner_id,technical_owner_name,asset_tag from config_items as ci\
        left join class_master as cm on ci.class_id=cm.class_id\
        left join category_master_v2 as cat on cat.category_id=ci.category_id\
     left join menulist as ms on ci.status=ms.FIELD1_VALUE AND ms.field1_name='Status'\
        left join menulist as mm on ci.metallic=mm.FIELD1_VALUE AND mm.field1_name='Metallic'\
        left join menulist as me on ci.environment=me.FIELD1_VALUE AND me.field1_name='Environment'\
        left join menulist as mf on ci.manufacturer=mf.FIELD1_VALUE AND mf.field1_name='Manufacturer'\
        left join menulist as md on ci.dataset=md.FIELD1_VALUE AND md.field1_name='Dataset'\
        WHERE ci_id=?",[req.params.id],function(err,data){
            if(err) return next(err);
        else
            res.status(200).json(data[0]);
    })
})


/*GET CI attributes by id */
router.get('/:id/attributes',function(req,res,next){
    db.query("with result (class_id,parent_class_id,class_name,status) as \
		(\
		  select r.class_id,r.parent_class_id,r.class_name,r.status\
		  from class_master r\
		  where r.class_id IN (\
		  Select class_id \
			from config_items\
			where ci_id=?\
		  )\
		  union all\
		  select p.class_id,p.parent_class_id,p.class_name,p.status\
		  from result c,class_master p\
		  where c.parent_class_id=p.class_id\
		  )\
            Select DISTINCT attribute_id,attribute_name,mandatory,status,class_id,value \
            from attribute_master as am left join ci_attribute_mapping as cam\
            on am.attribute_id=cam.attr_id AND cam.ci_id=?\
            where class_id IN (\
            select class_id from result)",[req.params.id,req.params.id],function(err,data){
                if(err) return next(err);
                else
                    res.status(200).json(data);
            })
})


/*GET CI attributes by id */
router.get('/:id/attributes/:attr_id',function(req,res,next){    
    db.query("  Select attribute_id,attribute_name,mandatory,status,class_id,value \
        from attribute_master as am left join ci_attribute_mapping as cam\
        on am.attribute_id=cam.attr_id AND cam.ci_id=?\
        where  am.attribute_id=?",[req.params.id,req.params.attr_id],function(err,data){
            if(err) return next(err);
            else
                res.status(200).json(data[0]);
        })
             
 })


/*post CI attributes by id */
router.post('/:id/attributes',function(req,res,next){

    var body=_.pick(req.body,['attr_id','value']); 
    body.ci_id=req.params.id;
    db.query("SELECT * FROM FINAL TABLE (INSERT INTO ci_attribute_mapping (ci_id,attr_id,value) values (?,?,?))",[body.ci_id,body.attr_id,body.value],function(err,data){
        if(err) return next(err);    
        logger.info(`${req.ip} REST post CI attributes by id request completed for `,body);   
         res.status(200).json(data[0]);             
    })

    // used for muliple arrtibutes in single list
    // var attArr=[];
    // for(var i = 0; i<body.length; i++){       
    //     var myobject  = '('+configid+','+body[i].attr_id+','+body[i].value+')';
    //     attArr.push(myobject);
    // }  
    // db.query("SELECT * FROM FINAL TABLE (INSERT INTO ci_attribute_mapping values "+attArr.toString()+")",function(err,data){
    //     if(err) return next(err);         
    //     logger.info(`${req.ip} post CI attributes by id request completed for ${id}`);   
    //         res.status(200).json(data);          
            
    // })

})

/*patch CI attributes by id */
router.patch('/:id/attributes/:att_id',function(req,res,next){
    
        var body=_.pick(req.body,['value']); 
        body.ci_id=req.params.id;
        body.attr_id=req.params.att_id;

        db.query("SELECT * FROM FINAL TABLE (UPDATE ci_attribute_mapping SET value=? WHERE ci_id=? AND attr_id=?  )",[body.value,body.ci_id,body.attr_id],function(err,data){
            if(err) return next(err);    
            logger.info(`${req.ip} REST patch CI attributes request completed for `,data);   
             res.status(200).json(data[0]);             
        })
             
    })

router.get('/:id/hierarchy/',function(req,res,next){
    console.log(req.query);
    if(req.query.hierarchy=="upward"){
        str1=" where rcici.ci_id="+req.params.id+") r";
        str2=" where c.ci_id_related=p.ci_id";
        str3=" ";
    }
    else{
        str1=" where rcici.ci_id_related="+req.params.id+") r ";
        str2=" where c.ci_id=p.ci_id_related";
        str3=" select ci.ci_id,ci_name,null,ci.class_id,class_name,url\
                from config_items ci left join class_master cm on ci.class_id=cm.class_id\
                where ci.ci_id="+req.params.id;
    }
    if(!req.query.hierarchy){
        console.log("yo");
        db.query("with result(ci_id,ci_name,ci_id_related,class_id,class_name,url) as\
	(select r.ci_id,r.ci_name,r.ci_id_related,r.class_id,r.class_name,r.url\
	 	from (select rcici.ci_id,rci.ci_name,rcici.ci_id_related,rci.class_id,rcm.class_name,rcm.url \
				from ci_ci_relationship as rcici \
				left join config_items as rci on rcici.ci_id=rci.ci_id\
				left join class_master as rcm on rci.class_id=rcm.class_id\
				 where rcici.ci_id_related="+req.params.id+") r \
	 	UNION ALL\
	 	select p.ci_id,p.ci_name,p.ci_id_related,p.class_id,p.class_name,p.url\
         from result c,(select pcici.ci_id,pci.ci_name,pcici.ci_id_related,pci.class_id,pcm.class_name,pcm.url from\
	 		ci_ci_relationship pcici\
         left join config_items as pci on pcici.ci_id=pci.ci_id\
	 	left join class_master as pcm on pci.class_id=pcm.class_id) p\
	 	 where c.ci_id=p.ci_id_related\
     )\
    ,prefinal (ci_id,ci_name,ci_id_related,class_id,class_name,url) as (\
     select * from result union  select ci.ci_id,ci_name,null,ci.class_id,class_name,url\
                from config_items ci left join class_master cm on ci.class_id=cm.class_id\
                where ci.ci_id="+req.params.id
     +"),final(ci_id,ci_name,ci_id_related,class_id,class_name,url,class_id_related,class_name_related,url_related) as (\
		select p.ci_id,p.ci_name,p.ci_id_related,p.class_id,p.class_name,p.url,ci.class_id as class_id_related,cm.class_name as class_name_related,cm.url as url_related\
        from prefinal as p left join config_items as ci on p.ci_id_related=ci.ci_id\
        left join class_master as cm on ci.class_id=cm.class_id)\
		select f.*,rm.r_name\
        from final as f left join class_class_relationship as ccr on (f.class_id=ccr.class_id AND f.class_id_related=ccr.class_id_related)\
        OR (f.class_id=ccr.class_id_related AND f.class_id_related=ccr.class_id)\
		left join relationship_master as rm on ccr.r_id=rm.r_id",function(err,data){
          if(err) return next(err);    
          db.query("with result(ci_id,ci_name,ci_id_related,class_id,class_name,url) as\
	(select r.ci_id,r.ci_name,r.ci_id_related,r.class_id,r.class_name,r.url\
	 	from (select rcici.ci_id,rci.ci_name,rcici.ci_id_related,rci.class_id,rcm.class_name,rcm.url \
				from ci_ci_relationship as rcici \
				left join config_items as rci on rcici.ci_id=rci.ci_id\
				left join class_master as rcm on rci.class_id=rcm.class_id\
				 where rcici.ci_id="+req.params.id+") r\
	 	UNION ALL\
	 	select p.ci_id,p.ci_name,p.ci_id_related,p.class_id,p.class_name,p.url\
         from result c,(select pcici.ci_id,pci.ci_name,pcici.ci_id_related,pci.class_id,pcm.class_name,pcm.url from\
	 		ci_ci_relationship pcici\
         left join config_items as pci on pcici.ci_id=pci.ci_id\
	 	left join class_master as pcm on pci.class_id=pcm.class_id) p\
	 	  where c.ci_id_related=p.ci_id\
     )\
    ,prefinal (ci_id,ci_name,ci_id_related,class_id,class_name,url) as (\
     select * from result union),final(ci_id,ci_name,ci_id_related,class_id,class_name,url,class_id_related,class_name_related,url_related) as (\
		select p.ci_id,p.ci_name,p.ci_id_related,p.class_id,p.class_name,p.url,ci.class_id as class_id_related,cm.class_name as class_name_related,cm.url as url_related\
        from prefinal as p left join config_items as ci on p.ci_id_related=ci.ci_id\
        left join class_master as cm on ci.class_id=cm.class_id)\
		select f.*,rm.r_name\
        from final as f left join class_class_relationship as ccr on (f.class_id=ccr.class_id AND f.class_id_related=ccr.class_id_related)\
        OR (f.class_id=ccr.class_id_related AND f.class_id_related=ccr.class_id)\
		left join relationship_master as rm on ccr.r_id=rm.r_id",function(err,dataa){
          if(err) return next(err);    
          dataa.forEach(function(val){
              data.push(val);
          })
        logger.info(`${req.ip} REST get class hierarchy by class id request completed for `,data);   
         res.status(200).json(data);  
      })
      })
    
    }
    else{
    db.query("with result(ci_id,ci_name,ci_id_related,class_id,class_name,url) as\
	(select r.ci_id,r.ci_name,r.ci_id_related,r.class_id,r.class_name,r.url\
	 	from (select rcici.ci_id,rci.ci_name,rcici.ci_id_related,rci.class_id,rcm.class_name,rcm.url \
				from ci_ci_relationship as rcici \
				left join config_items as rci on rcici.ci_id=rci.ci_id\
				left join class_master as rcm on rci.class_id=rcm.class_id\
				"+str1+"\
	 	UNION ALL\
	 	select p.ci_id,p.ci_name,p.ci_id_related,p.class_id,p.class_name,p.url\
         from result c,(select pcici.ci_id,pci.ci_name,pcici.ci_id_related,pci.class_id,pcm.class_name,pcm.url from\
	 		ci_ci_relationship pcici\
         left join config_items as pci on pcici.ci_id=pci.ci_id\
	 	left join class_master as pcm on pci.class_id=pcm.class_id) p\
	 	 "+str2+"\
     )\
    ,prefinal (ci_id,ci_name,ci_id_related,class_id,class_name,url) as (\
     select * from result union "+str3
     +"),final(ci_id,ci_name,ci_id_related,class_id,class_name,url,class_id_related,class_name_related as (\
		select p.ci_id,p.ci_name,p.ci_id_related,p.class_id,p.class_name,p.url,ci.class_id as class_id_related,cm.class_name as class_name_related\
        from prefinal as p left join config_items as ci on p.ci_id_related=ci.ci_id\
        left join class_master as pcm on pci.class_id=pcm.class_id)\
		select f.*,rm.r_name\
        from final as f left join class_class_relationship as ccr on (f.class_id=ccr.class_id AND f.class_id_related=ccr.class_id_related)\
        OR (f.class_id=ccr.class_id_related AND f.class_id_related=ccr.class_id)\
		left join relationship_master as rm on ccr.r_id=rm.r_id",function(err,data){
          if(err) return next(err);    
        logger.info(`${req.ip} REST get class hierarchy by class id request completed for `,data);   
         res.status(200).json(data);  
      })
    }
})

router.post("/relationship",function(req,res,next){
    var body=_.pick(req.body,['ci_id','ci_id_related','created_by','r_id','module']); 

    logger.info(`${req.ip} config item relationship post request for `,body);
    var valuesArr=[],keysArr=[],comma=[];
    for(key in body){
        keysArr.push(key);
        comma.push("?");
        valuesArr.push(body[key]);
    }
    keysArr.push("created_at");
    db.query("select * from FINAL TABLE(INSERT INTO ci_ci_relationship ("+keysArr.toString()+") values ("+comma.toString()+",CURRENT TIMESTAMP))",valuesArr,function(err,data){
        if(err) return next(err);    
        logger.info(`${req.ip} REST post config item relationship request completed for `,data);   
         res.status(200).json(data);  
    })
})



module.exports = router;





/**
 * ALTER TABLE CI_CI_RELATIONSHIP
  ADD CONSTRAINT ucCodes UNIQUE (CI_ID_RELATED, CI_ID)
 */

 /**
  * 
  ALTER TABLE CONFIG_ITEMS
ADD  support_company_id int NOT NULL,
support_company_name varchar(500) NOT NULL,
business_owner_id int NOT NULL,
business_owner_name varchar(500) NOT NULL,
technical_owner_id int NOT NULL,
technical_owner_name varchar(500) NOT NULL;


ALTER TABLE CONFIG_ITEMS
ADD  support_company_id int NOT NULL DEFAULT 0;
ALTER TABLE CONFIG_ITEMS
ADD support_company_name varchar(500) NOT NULL DEFAULT '';

ALTER TABLE CONFIG_ITEMS
ADD business_owner_id int NOT NULL DEFAULT 0;

ALTER TABLE CONFIG_ITEMS
ADD business_owner_name varchar(500) NOT NULL DEFAULT '';

ALTER TABLE CONFIG_ITEMS
ADD technical_owner_id int NOT NULL DEFAULT 0;
ALTER TABLE CONFIG_ITEMS
ADD technical_owner_name varchar(500) NOT NULL DEFAULT '';



ALTER TABLE CONFIG_ITEMS
ADD Asset_Tag varchar(500);





{
	
	"ci_name":"helloIAMTEtsing",
	"class_id":1,
	"company_id":1,
	"company_name":"hcl",
	"status":5,
	"category_id":1,
	"sub_category_id":1,
	"group_id":1,
	"group_name":"abc",
	"owner_id":1,
	"owner_name":"abc",
	"location_id":1,"location_name":"abc","dataset":"abc","manufacturer":"abc",
             "environment":1,"metallic":1,"description":"adasdasasda","created_by":1,
            "support_company_id":1,"support_company_name":"abc","business_owner_id":1,"business_owner_name":"acd",
            "technical_owner_id":1,"technical_owner_name":"abc" 
}
  */


  /**
   * 
  
{ ci_name: 'N10m sit amet dolor feugia123',
  class_id: 2,
  company_id: 3215,
  company_name: 'Hindustan Unilever Limited',
  description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc at euismod risus. Donec dui ligula, tincidunt id condimentum ut, mattis quis ex. Sed ac aliquam odio. Etiam convallis, lorem non lobortis egestas, metus magna posuere arcu, eget bibendum purus augue vel urna. Sed mollis eu nulla sagittis lobortis. Mauris
sollicitudin nunc eu mattis blandit. Sed ac iaculis mauris. Nam sit amet dolor feugiat, tempus neque ut, facilisis turpis.',
  spcm_category_id: 1672,
  spcm_category_name: 'HEALTH',
  status: 30,
  created_by: null,
  updated_by: null,
  business_owner_id: 4006,
  business_owner_name: 'HCLT  CIM',
  support_company_id: 3215,
  support_company_name: 'Hindustan Unilever Limited',
  technical_owner_id: 3996,
  technical_owner_name: 'HUL  Portfolio Manager',
  group_id: 2093,
  group_name: 'HUL Portfolio Management' }


{ "ci_name": "N10m sit amet dolor feugia123",
  "class_id": 2,
  "company_id": 3215,
  "company_name": "Hindustan Unilever Limited",
  "description": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc at euismod risus. Donec dui ligula, tincidunt id condimentum ut, mattis quis ex. Sed ac aliquam odio. Etiam convallis, lorem non lobortis egestas, metus magna posuere arcu, eget bibendum purus augue vel urna. Sed mollis eu nulla sagittis lobortis. Mauris sollicitudin nunc eu mattis blandit. Sed ac iaculis mauris. Nam sit amet dolor feugiat, tempus neque ut, facilisis turpis.",
  "spcm_category_id": 1672,
  "spcm_category_name": "HEALTH",
  "status": 30,
   "updated_by": null,
  "business_owner_id": 4006,
  "business_owner_name": "HCLT  CIM",
  "support_company_id": 3215,
  "support_company_name": "Hindustan Unilever Limited",
  "technical_owner_id": 3996,
  "technical_owner_name": "HUL  Portfolio Manager",
  "group_id": 2093,
  "group_name": "HUL Portfolio Management" }


   * 
   */