--Master data of ATTRIBUTE_MASTER table 
INSERT INTO BLUADMIN.ATTRIBUTE_MASTER (ATTRIBUTE_NAME,CLASS_ID,STATUS,MANDATORY) 
VALUES
  ('Serial Number',7,'active','1'),
  ('In-scope',2,'active','1'),
  ('Out-of-scope',2,'active','1'),
  ('RPO',9,'active','1'),
  ('RTO',9,'active','1'),
  ('Number of Users',9,'active','1'),
  ('Application Version',9,'active','1'),
  ('Deployment Date',9,'active','1'),
  ('Operating System',11,'active','1'),
  ('Operating System Version',11,'active','1'),
  ('Serial Number',11,'active','1'),
  ('Product',11,'active','1'),
  ('Model',11,'active','1'),
  ('Deployment Date',11,'active','1'),
  ('Operating System',10,'active','1'),
  ('Operating System Version',10,'active','1'),
  ('Serial Number',10,'active','1'),
  ('Product',10,'active','1'),
  ('Model',10,'active','1'),
  ('Allocation Date',10,'active','1'),
  ('Domain Name',12,'active','1'),
  ('Number of Ports',12,'active','1'),
  ('Product',12,'active','1'),
  ('Model',12,'active','1'),
  ('Deployment Date',12,'active','1'),
  ('DB Purpose',5,'active','1'),
  ('Instance',5,'active','1'),
  ('Deployment Date',5,'active','1'),
  ('Model ID',7,'active','1')
@

--Master data of CATEGORY_MASTER table
INSERT INTO BLUADMIN.CATEGORY_MASTER (CATEGORY_NAME,CLASS_ID,STATUS) 
VALUES
  ('Business',2,'active'),
  ('Application',2,'active'),
  ('Infrastructure',2,'active'),
  ('Business',9,'active'),
  ('ERP',9,'active'),
  ('SAP',9,'active'),
  ('EUC',9,'active'),
  ('Physical',11,'active'),
  ('Virtual',11,'active'),
  ('Laptop',10,'active'),
  ('Desktop',10,'active'),
  ('Hand Held Device',10,'active'),
  ('Oracle',5,'active'),
  ('SQL',5,'active'),
  ('MySQL',5,'active'),
  ('DB2',5,'active'),
  ('Switch',12,'active'),
  ('Router',12,'active'),
  ('Modem',12,'active'),
  ('Load Balancer',12,'active')
@

--Master data of CATEGORY_MASTER_V2 table
INSERT INTO BLUADMIN.CATEGORY_MASTER_V2 (CATEGORY_NAME,SUB_CATEGORY_NAME,STATUS,CLASS_ID) 
VALUES
  ('Physical','Physical','active',11),
  ('Virtual','LPAR','active',11),
  ('Virtual','vPAR','active',11),
  ('Virtual','Virtual Guest','active',11),
  ('Desktop','Mobile','active',10),
  ('Hand Held Device','Scanner','active',10),
  ('Hand Held Device','PDA','active',10),
  ('Router','Blade','active',12),
  ('Modem','DNS','active',12),
  ('Load Balancer','Access Point','active',12),
  ('Load Balancer','Controller','active',12),
  ('Infrastructure','-','active',2),
  ('Application','-','active',2),
  ('Oracle','-','active',5),
  ('ERP','-','active',9),
  ('Laptop','-','active',10),
  ('DB2','-','active',5),
  ('Business','-','active',9),
  ('EUC','-','active',9),
  ('Switch','-','active',12),
  ('SAP','-','active',9),
  ('MySQL','-','active',5),
  ('Business','-','active',2),
  ('SQL','-','active',5)
@

--Master data of CLASS_MASTER table
INSERT INTO BLUADMIN.CLASS_MASTER (CLASS_NAME,PARENT_CLASS_ID,STATUS,URL) 
VALUES
  ('Base Class',NULL,'active','http://icons.iconarchive.com/icons/icons8/ios7/64/Computer-Hardware-Laptop-icon.png'),
  ('Service',1,'active','http://icons.iconarchive.com/icons/iconsmind/outline/64/Fax-icon.png'),
  ('Logical Entity',1,'active','https://flow.microsoft.com/images/favicon.ico'),
  ('System',1,'active','https://www.displayfusion.com/ImagesCommon/Icons/64x64/dfFunctions.png'),
  ('Database',3,'active','http://www.iconsplace.com/icons/preview/black/database-64.png'),
  ('Disc Partition',3,'active','https://launchpad.net/@@/product-logo'),
  ('Computer System',4,'active','https://www.linux-onlineshop.de/media/images/category/info/linux-computer.png'),
  ('Application System',4,'active','https://www.linux-onlineshop.de/media/images/category/info/linux-computer.png'),
  ('Application',8,'active','https://www.linux-onlineshop.de/media/images/category/info/linux-computer.png'),
  ('EUC',7,'active','http://icons.iconarchive.com/icons/icons8/windows-8/64/Mobile-Smartphone-Tablet-icon.png'),
  ('Server',7,'active','http://www.mattson.com/images/icons/technology.png'),
  ('Network',7,'active','https://www.linux-onlineshop.de/media/images/category/info/linux-computer.png')
@


--Master data of MENULIST table
INSERT INTO BLUADMIN.MENULIST (MODULE,FIELD1_NAME,FIELD1_KEY,FIELD1_VALUE,FIELD2_NAME,FIELD2_KEY,FIELD2_VALUE,FIELD3_NAME,FIELD3_KEY,FIELD3_VALUE) 
VALUES
  ('CI','Status','Under Repair','30',NULL,NULL,'3',NULL,NULL,NULL),
  ('SPCM_CMDB_INTERFACE','ServiceClass','class_id','2',NULL,NULL,NULL,NULL,NULL,NULL),
  ('SPCM_CMDB_INTERFACE','ServiceClass','manufacturer_id','35',NULL,NULL,NULL,NULL,NULL,NULL),
  ('CI','StatusTransitions','In stock','5',NULL,NULL,NULL,'In stock','In stock','5'),
  ('CI','StatusTransitions','In stock','5',NULL,NULL,NULL,'In stock','Deployed','10'),
  ('CI','StatusTransitions','Deployed','10',NULL,NULL,'','Deployed','Deployed','10'),
  ('SPCM_CMDB_INTERFACE','ServiceClassStatus','Deployed','10',NULL,NULL,NULL,NULL,NULL,NULL),
  ('SPCM_CMDB_INTERFACE','ServiceClassStatus','Suspended','30',NULL,NULL,NULL,NULL,NULL,NULL),
  ('SPCM_CMDB_INTERFACE','ServiceClassStatus','Obsolete','15',NULL,NULL,NULL,NULL,NULL,NULL),
  ('CI','StatusTransitions','Deployed','10',NULL,NULL,'','Deployed','Under Repair','30'),
  ('CI','StatusTransitions','Deployed','10',NULL,NULL,'','Deployed','Decommissioned','15'),
  ('CI','StatusTransitions','Under Repair','30',NULL,NULL,'','Under Repair','Under Repair','30'),
  ('CI','StatusTransitions','Under Repair','30',NULL,NULL,'','Under Repair','Deployed','10'),
  ('CI','Class','Service','5',NULL,NULL,NULL,NULL,NULL,NULL),
  ('CI','Class','Application','10',NULL,NULL,NULL,NULL,NULL,NULL),
  ('CI','Class','Network','15',NULL,NULL,NULL,NULL,NULL,NULL),
  ('CI','Class','Database','20',NULL,NULL,NULL,NULL,NULL,NULL),
  ('CI','Class','EUC','25',NULL,NULL,NULL,NULL,NULL,NULL),
  ('CI','Class','Server','30',NULL,NULL,NULL,NULL,NULL,NULL),
  ('CI','Metallic','Platinum','5',NULL,NULL,NULL,NULL,NULL,NULL),
  ('CI','Metallic','Gold','10',NULL,NULL,NULL,NULL,NULL,NULL),
  ('CI','Metallic','Silver','15',NULL,NULL,NULL,NULL,NULL,NULL),
  ('CI','Metallic','Bronze','20',NULL,NULL,NULL,NULL,NULL,NULL),
  ('CI','Environment','Production','5',NULL,NULL,NULL,NULL,NULL,NULL),
  ('CI','Environment','QA','10',NULL,NULL,NULL,NULL,NULL,NULL),
  ('CI','Environment','Test','15',NULL,NULL,NULL,NULL,NULL,NULL),
  ('CI','Environment','Development','20',NULL,NULL,NULL,NULL,NULL,NULL),
  ('CI','Manufacturer','Microsoft','5',NULL,NULL,NULL,NULL,NULL,NULL),
  ('CI','Manufacturer','HP','10',NULL,NULL,NULL,NULL,NULL,NULL),
  ('CI','Manufacturer','Oracle','15',NULL,NULL,NULL,NULL,NULL,NULL),
  ('CI','Manufacturer','Dell','20',NULL,NULL,NULL,NULL,NULL,NULL),
  ('CI','Manufacturer','Lenovo','25',NULL,NULL,NULL,NULL,NULL,NULL),
  ('CI','Manufacturer','Cisco','30',NULL,NULL,NULL,NULL,NULL,NULL),
  ('CI','Manufacturer','Others','35',NULL,NULL,NULL,NULL,NULL,NULL),
  ('CI','Dataset','Golden','5',NULL,NULL,NULL,NULL,NULL,NULL),
  ('CI','Dataset','Discovery Tool 2','10',NULL,NULL,NULL,NULL,NULL,NULL),
  ('CI','Dataset','Monitoring Tool 1','15',NULL,NULL,NULL,NULL,NULL,NULL),
  ('CI','Dataset','Monitoring Tool 2','20',NULL,NULL,NULL,NULL,NULL,NULL),
  ('CI','Dataset','Manual','25',NULL,NULL,NULL,NULL,NULL,NULL),
  ('CI','Status','In stock','5',NULL,NULL,'1',NULL,NULL,NULL),
  ('CI','Status','Deployed','10',NULL,NULL,'2',NULL,NULL,NULL),
  ('CI','Status','Decommissioned','15',NULL,NULL,'4',NULL,NULL,NULL),
  ('CI','Status','Disposed','20',NULL,NULL,'5',NULL,NULL,NULL),
  ('CI','Status','Deleted','25',NULL,NULL,'6',NULL,NULL,NULL),
  ('CI','StatusTransitions','Decommissioned','15',NULL,NULL,'','Decommissioned','Decommissioned','15'),
  ('CI','StatusTransitions','Decommissioned','15',NULL,NULL,'','Decommissioned','Disposed','20'),
  ('CI','StatusTransitions','Disposed','20',NULL,'','','Disposed','Disposed','20'),
  ('CI','StatusTransitions','Disposed','20',NULL,NULL,'','Disposed','Deleted','25'),
  ('CI','StatusTransitions','Deleted','25',NULL,NULL,'','Deleted','Deleted','25'),
  ('CI','Manufacturer','HCL','40',NULL,NULL,NULL,NULL,NULL,NULL),
  ('CI','StatusTransitions','Default','0',NULL,NULL,NULL,'Default','In stock','5')
@

--Master data of RELATIONSHIP_MASTER table
INSERT INTO BLUADMIN.RELATIONSHIP_MASTER (R_NAME,STATUS) 
VALUES
  ('Runs on','1'),
  ('Hosted on','1'),
  ('Connected To','1'),
  ('Parent/Child','1'),
  ('Depends on','1'),
  ('Related To','1'),
  ('Used By','1')
@

--Master data of SUB_CATEGORY_MASTER table
INSERT INTO BLUADMIN.SUB_CATEGORY_MASTER (SUB_CATEGORY_NAME,STATUS,CATEGORY_ID) 
VALUES
  ('a1','active',1),
  ('sub_cat2','inactive',1),
  ('updateTEssingCategories','inactive',1),
  ('Physical','active',9),
  ('LPAR','active',10),
  ('vPAR','active',10),
  ('Virtual Guest','active',10),
  ('Mobile','active',12),
  ('Scanner','active',13),
  ('PDA','active',13),
  ('Blade','active',19),
  ('DNS','active',20),
  ('Access Point','active',21),
  ('Controller','active',21)
@


--Master data of PERMISSIONMATRIX table
INSERT INTO BLUADMIN.PERMISSIONMATRIX (ROLE_ID,ROLE_NAME,OPERATION,REGEX,HTTP_GET,HTTP_POST,HTTP_PATCH,HTTP_DELETE,DESCRIPTION) 
VALUES
  (1,'Administrator       ','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items/relationship',1,1,0,1,'READ only'),
  (4,'Service Portfolio Manager','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items/relationship',1,1,0,1,'READ only'),
  (5,'Service Catalog Manager','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items/relationship',1,1,0,1,'READ only'),
  (7,'Contracts Manager','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items/relationship',1,1,0,1,'READ only'),
  (8,'Supplier Manager','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items/relationship',1,1,0,1,'READ only'),
  (9,'Service Publisher','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items/relationship',1,1,0,1,'READ only'),
  (10,'Approver','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items/relationship',1,1,0,1,'READ only'),
  (11,'Service Consumer','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items/relationship',1,1,0,1,'READ only'),
  (12,'Incident User','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items/relationship',1,1,0,1,'READ only'),
  (13,'Incident Manager','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items/relationship',1,1,0,1,'READ only'),
  (14,'Critical Incident Manager','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items/relationship',1,1,0,1,'READ only'),
  (16,'Problem User','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items/relationship',1,1,0,1,'READ only'),
  (17,'Problem Manager','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items/relationship',1,1,0,1,'READ only'),
  (19,'Change User','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items/relationship',1,1,0,1,'READ only'),
  (20,'Change Manager','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items/relationship',1,1,0,1,'READ only'),
  (32,'Incident Admin','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items/relationship',1,1,0,1,'READ only'),
  (33,'Problem Admin','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items/relationship',1,1,0,1,'READ only'),
  (34,'Change Admin','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items/relationship',1,1,0,1,'READ only'),
  (35,'Service Consumer','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items/relationship',1,1,0,1,'READ only'),
  (36,'Service Requestor','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items/relationship',1,1,0,1,'READ only'),
  (37,'Config Manager','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items',1,1,1,1,'READ WRITE UPDATE  DELETE'),
  (38,'Asset Manager','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items',1,1,1,1,'READ WRITE UPDATE  DELETE'),
  (39,'Config Viewer','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items/relationship',1,1,0,1,'READ only'),
  (40,'SLA Manager','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items/relationship',1,1,0,1,'READ only'),
  (41,'AMS Administrator','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items/relationship',1,1,0,1,'READ only'),
  (42,'Problem Manager','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items/relationship',1,1,0,1,'READ only'),
  (43,'Fulfillment User','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items/relationship',1,1,0,1,'READ only'),
  (44,'Fulfillment Manager','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items/relationship',1,1,0,1,'READ only'),
  (45,'SLA User','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items/relationship',1,1,0,1,'READ only'),
  (46,'SLA Viewer','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items/relationship',1,1,0,1,'READ only'),
  (1,'Administrator','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items',1,0,0,0,'READ only'),
  (4,'Service Portfolio Manager','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items',1,0,0,0,'READ only'),
  (5,'Service Catalog Manager','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items',1,0,0,0,'READ only'),
  (7,'Contracts Manager','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items',1,0,0,0,'READ only'),
  (8,'Supplier Manager','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items',1,0,0,0,'READ only'),
  (9,'Service Publisher','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items',1,0,0,0,'READ only'),
  (10,'Approver','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items',1,0,0,0,'READ only'),
  (11,'Service Consumer','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items',1,0,0,0,'READ only'),
  (12,'Incident User','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items',1,0,0,0,'READ only'),
  (13,'Incident Manager','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items',1,0,0,0,'READ only'),
  (14,'Critical Incident Manager','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items',1,0,0,0,'READ only'),
  (16,'Problem User','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items',1,0,0,0,'READ only'),
  (17,'Problem Manager','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items',1,0,0,0,'READ only'),
  (19,'Change User','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items',1,0,0,0,'READ only'),
  (20,'Change Manager','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items',1,0,0,0,'READ only'),
  (32,'Incident Admin','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items',1,0,0,0,'READ only'),
  (33,'Problem Admin','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items',1,0,0,0,'READ only'),
  (34,'Change Admin','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items',1,0,0,0,'READ only'),
  (35,'Service Consumer','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items',1,0,0,0,'READ only'),
  (36,'Service Requestor','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items',1,0,0,0,'READ only'),
  (39,'Config Viewer','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items',1,0,0,0,'READ only'),
  (40,'SLA Manager','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items',1,0,0,0,'READ only'),
  (41,'AMS Administrator','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items',1,0,0,0,'READ only'),
  (42,'Problem Manager','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items',1,0,0,0,'READ only'),
  (43,'Fulfillment User','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items',1,0,0,0,'READ only'),
  (44,'Fulfillment Manager','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items',1,0,0,0,'READ only'),
  (45,'SLA User','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items',1,0,0,0,'READ only'),
  (46,'x','GET','/api/menulist|/api/classes|/api/categories|/api/audit|/api/config_items',1,0,0,0,'READ only')
@



--Master data of CLASS_CLASS_RELATIONSHIP table
INSERT INTO BLUADMIN.CLASS_CLASS_RELATIONSHIP (CLASS_ID,CLASS_ID_RELATED,R_ID) 
VALUES
  (5,11,23),
  (9,11,24),
  (12,11,25),
  (7,11,26),
  (1,11,26),
  (2,11,27),
  (4,11,26),
  (11,11,28),
  (2,9,27),
  (9,2,41),
  (11,5,23),
  (11,9,24),
  (11,12,25),
  (11,7,26),
  (11,1,26),
  (11,2,27),
  (11,4,26)
@


--DML Triggers
--<ScriptOptions statementTerminator="@"/>
create or replace trigger ci_trigger_update after update on config_items referencing old as oldRow new as newRow for each row 
begin atomic


declare lastUpdatedOn bigint;


SET lastUpdatedOn= (SELECT 86400*(DAYS(CURRENT TIMESTAMP - CURRENT TIMEZONE)-DAYS('1970-01-01')) + MIDNIGHT_SECONDS(CURRENT TIMESTAMP - CURRENT TIMEZONE) FROM SYSIBM.SYSDUMMY1);

if(oldRow.COMPANY_ID!=newRow.COMPANY_ID) then insert into AUDIT (ITEM_ID,MODULE,CREATED_ON, CREATED_BY, AUDIT_FIELD, "FROM", "TO" ) 
values (oldRow.CI_ID,'CMDB',lastUpdatedOn, newRow.UPDATED_BY, 'COMPANY_NAME',oldRow.COMPANY_ID, newRow.COMPANY_ID);
 END IF;
 
 if(oldRow.CATEGORY_ID!=newRow.CATEGORY_ID) then insert into AUDIT (ITEM_ID,MODULE,CREATED_ON, CREATED_BY, AUDIT_FIELD, "FROM", "TO" ) 
values (oldRow.CI_ID,'CMDB',lastUpdatedOn, newRow.UPDATED_BY, 'CATEGORY_ID',oldRow.CATEGORY_ID, newRow.CATEGORY_ID);
 END IF;
 
 if(oldRow.SUPPORT_COMPANY_ID!=newRow.SUPPORT_COMPANY_ID) then insert into AUDIT (ITEM_ID,MODULE,CREATED_ON, CREATED_BY, AUDIT_FIELD, "FROM", "TO" ) 
values (oldRow.CI_ID,'CMDB',lastUpdatedOn, newRow.UPDATED_BY, 'SUPPORT COMPANY',oldRow.SUPPORT_COMPANY_NAME, newRow.SUPPORT_COMPANY_NAME);
 END IF;
 
 if(oldRow.METALLIC!=newRow.METALLIC) then insert into AUDIT (ITEM_ID,MODULE,CREATED_ON, CREATED_BY, AUDIT_FIELD, "FROM", "TO" ) 
values (oldRow.CI_ID,'CMDB',lastUpdatedOn, newRow.UPDATED_BY, 'METALLIC',oldRow.METALLIC, newRow.METALLIC);
 END IF;
 
 if(oldRow.ENVIRONMENT!=newRow.ENVIRONMENT) then insert into AUDIT (ITEM_ID,MODULE,CREATED_ON, CREATED_BY, AUDIT_FIELD, "FROM", "TO" ) 
values (oldRow.CI_ID,'CMDB',lastUpdatedOn, newRow.UPDATED_BY, 'ENVIRONMENT',oldRow.ENVIRONMENT, newRow.ENVIRONMENT);
 END IF;
 
 if(oldRow.GROUP_ID!=newRow.GROUP_ID) then insert into AUDIT (ITEM_ID,MODULE,CREATED_ON, CREATED_BY, AUDIT_FIELD, "FROM", "TO" ) 
values (oldRow.CI_ID,'CMDB',lastUpdatedOn, newRow.UPDATED_BY, 'GROUP_NAME',oldRow.GROUP_ID, newRow.GROUP_ID);
 END IF;
 
 if(oldRow.BUSINESS_OWNER_ID!=newRow.BUSINESS_OWNER_ID) then insert into AUDIT (ITEM_ID,MODULE,CREATED_ON, CREATED_BY, AUDIT_FIELD, "FROM", "TO" ) 
values (oldRow.CI_ID,'CMDB',lastUpdatedOn, newRow.UPDATED_BY, 'BUSINESS OWNER',oldRow.BUSINESS_OWNER_NAME, newRow.BUSINESS_OWNER_NAME);
 END IF;
 
  if(oldRow.TECHNICAL_OWNER_ID!=newRow.TECHNICAL_OWNER_ID) then insert into AUDIT (ITEM_ID,MODULE,CREATED_ON, CREATED_BY, AUDIT_FIELD, "FROM", "TO" ) 
values (oldRow.CI_ID,'CMDB',lastUpdatedOn, newRow.UPDATED_BY, 'TECHNICAL OWNER',oldRow.TECHNICAL_OWNER_NAME, newRow.TECHNICAL_OWNER_NAME);
 END IF;
 
 if(oldRow.LOCATION_ID!=newRow.LOCATION_ID) then insert into AUDIT (ITEM_ID,MODULE,CREATED_ON, CREATED_BY, AUDIT_FIELD, "FROM", "TO" ) 
values (oldRow.CI_ID,'CMDB',lastUpdatedOn, newRow.UPDATED_BY, 'LOCATION_NAME',oldRow.LOCATION_ID, newRow.LOCATION_ID);
 END IF;
 
 if(oldRow.STATUS!=newRow.STATUS) then insert into AUDIT (ITEM_ID,MODULE,CREATED_ON, CREATED_BY, AUDIT_FIELD, "FROM", "TO" ) 
values (oldRow.CI_ID,'CMDB',lastUpdatedOn, newRow.UPDATED_BY, 'STATUS',oldRow.STATUS, newRow.STATUS);
 END IF;
 
 if(oldRow.MANUFACTURER!=newRow.MANUFACTURER) then insert into AUDIT (ITEM_ID,MODULE,CREATED_ON, CREATED_BY, AUDIT_FIELD, "FROM", "TO" ) 
values (oldRow.CI_ID,'CMDB',lastUpdatedOn, newRow.UPDATED_BY, 'MANUFACTURER',oldRow.MANUFACTURER, newRow.MANUFACTURER);
 END IF;
 
if(oldRow.CLASS_ID!=newRow.CLASS_ID) then insert into AUDIT (ITEM_ID,MODULE,CREATED_ON, CREATED_BY, AUDIT_FIELD, "FROM", "TO" ) 
values (oldRow.CI_ID,'CMDB',lastUpdatedOn, newRow.UPDATED_BY, 'CLASS',oldRow.CLASS_ID, newRow.CLASS_ID);
 END IF;

 END
 @

COMMIT
@

