#!/bin/bash
cf push "${CF_APP}"
