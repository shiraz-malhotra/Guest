#!/bin/bash
# The default Node.js version is {0}
# To use Node.js {0}, uncomment the following line:
#export PATH=/opt/IBM/node-v0.10.48/bin:$PATH
# To use Node.js {0}, uncomment the following line:
#export PATH=/opt/IBM/node-v0.12/bin:$PATH
# To use Node.js {0}, uncomment the following line:
#export PATH=/opt/IBM/node-v4.4.5/bin:$PATH
# To use Node.js {0}, uncomment the following line:
#export PATH=/opt/IBM/node-v8.11.4/bin:$PATH
export PATH=/opt/IBM/node-v6.7.0/bin:$PATH
npm install