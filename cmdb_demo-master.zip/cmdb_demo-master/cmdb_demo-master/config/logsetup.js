//local files
const config = require('./config.json');
const winston = require('winston');

// logger setup
logger = winston.createLogger({
    transports: [
      new (winston.transports.Console)(),
      new (winston.transports.File)({ filename: config.server.log_file_name })
    ]
});

module.exports = logger;