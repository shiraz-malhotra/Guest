const config = require('./config.json');
const axios=require('axios');
const moment=require('moment');
//var {pool} = require('./serversetup');
var ibmdb = require('ibm_db');
const foundationBaseUrl = process.env.FOUNDATION_BASE_URL;

let Pool = ibmdb.Pool;
pool = new Pool({autoCleanIdle: true});
pool.setMaxPoolSize(2);
let cn = process.env.IBMDB2_CONN_STRING;

// var conn_str=process.env.IBMDB2_CONN_STRING;//||config.database.db2connString;
let envKey =process.env.ED_ARRAY;//||config.security.ED_ARRAY;
/* data base query genrator */
const runQuery=(query,paramsValueArray)=>{
  return new Promise((resolve,reject)=>{
    try
    {
      //console.log("INSIDE RUNQUERY METHOD");
      pool.open(cn, (err, db) => {
      //console.log('inside pool.open')
      if(err) {
        console.log(err, '---error inside runQuery---');
        reject(err);
        return;
      }
      db.query(query,paramsValueArray,function(err,data){

      if(err)  {
          console.log('error in executing Query, ----in runQuery----')
          db.close(() => {
          //console.log('connection Disconnected');
        });
        reject(err);
        return;
        }
        //console.log('connection made again');
        //console.log('no error in query')
        resolve(data);
        db.close(() => {
          //console.log('connection Disconnected');
          return;
        });     
        });
      })
        //console.log(pool, '---POOL---');
     }catch(error){
       reject(error);
     }     
    
  });
};  

const encryptDecrypt=async (input)=>{
  try {

      //let key = ['N', 'R', 'B']; //Can be any chars, and any size array
      if (envKey== undefined || envKey == null || envKey == " " )  console.log('ED_ARRAY Env Variable');

      let key = envKey.split(',');
      let output = [];
  
      for (let i = 0; i < input.length; i++) {
      let charCode = input.charCodeAt(i) ^ key[i % key.length].charCodeAt(0);
      output.push(String.fromCharCode(charCode));
      }
      return output.join("");
  } catch (error) {
      return error;   
  }
}


const patch_call_cmdb_interface=(data,id)=>{
    return new Promise((resolve,reject)=>{
       axios.patch(config.cmdb_interface.url+'/'+id, data)
      .then(function (response) {
        resolve(response.data);
      })
      .catch(function (error) {
        reject(error);
      });
    });
}; 
const checkIsExistInDb=async (unique_query,paramsValueArray)=>{
  try {
  const tempResult=await runQuery(unique_query,paramsValueArray);      
  return tempResult[0].DUPLICATE>0;      
  } catch (error) {
  return error ;
  }
  }; 

const dateFormatToEpoch = (timestampDate,dateFormat)=>{
  //for POST API
  return new Promise((resolve,reject)=>{
    try{
      var epochDate;
      if(dateFormat=='yyyy-MM-dd HH:mm:ss' ){ 
        epochDate = moment(timestampDate, "YYYY-MM-DD hh:mm:ss").unix();

      }else if(dateFormat=='dd-MM-yyyy HH:mm:ss'){
        epochDate  = moment(timestampDate,"DD-MM-YYYY hh:mm:ss").unix();
      }else if(dateFormat=='MM-dd-yyyy HH:mm:ss'){
        epochDate  = moment(timestampDate,"MM-DD-YYYY hh:mm:ss").unix();
      }
      resolve(epochDate);
    }catch(error){
      reject(error);
    }
  })

}

const epochToDateFormat = (dateFormat,offset,data)=>{
  return new Promise((resolve,reject)=>{
    try{
      console.log();
      console.log();
      var epochConvertion = (epoch,dateFormat1)=>{
        if(dateFormat1=='yyyy-MM-dd HH:mm:ss' ){ 
          epoch  = moment.unix(epoch).format("YYYY-MM-DD hh:mm:ss");
        }else if(dateFormat1=='dd-MM-yyyy HH:mm:ss'){
          epoch  = moment.unix(epoch).format("DD-MM-YYYY hh:mm:ss");
        }else if(dateFormat1=='MM-dd-yyyy HH:mm:ss'){
          epoch  = moment.unix(epoch).format("MM-DD-YYYY hh:mm:ss");
        }
        return epoch;
      }

      for(key in data){
        if('CREATED_AT' in data[key]){
          data[key].CREATED_AT = timeZoneCalc(offset,data[key].CREATED_AT);
          data[key].CREATED_AT = epochConvertion(data[key].CREATED_AT,dateFormat);
        }
        if('CI_ID_REPORTED' in data[key]){
          data[key].CI_ID_REPORTED = timeZoneCalc(offset,data[key].CI_ID_REPORTED);
          data[key].CI_ID_REPORTED = epochConvertion(data[key].CI_ID_REPORTED,dateFormat);
        }
        if('CREATED_ON' in data[key]){
          data[key].CREATED_ON = timeZoneCalc(offset,data[key].CREATED_ON);
          data[key].CREATED_ON = epochConvertion(data[key].CREATED_ON,dateFormat);
        }
      }
      resolve(data);
    }catch(error){
      reject(error);
    }
  })
}
const timeZoneCalc = (offset,epochDate)=>{
    try{
      if(offset.includes('-')){
        epochDate = parseInt(epochDate,10) - parseInt(offset, 10);
      }else{
        epochDate = parseInt(epochDate,10) + parseInt(offset, 10);
      }

      return epochDate;
    }catch(error){
      return (error);
    }

}
const keysToBeSearchedInJWT = (body,jwt)=>{
  try{
    for (key in body){
      
      if(key == "created_by")
        body[key] = jwt.full_name;

      if(key == "updated_by")
        body[key] = jwt.updated_by_name;
      
      if(!body[key] || body[key] == "" ){
        
        if(body[key]=== ""){
          //string is empty
          if(!(jwt[key] === "" || jwt[key] == undefined )){
            body[key] = jwt[key];
          }
          
          else{
            body[key] = "";
          }
        }else{
          //integer is empty
          if(!(jwt[key] == undefined))
            body[key] = jwt[key];
          
          else
           body[key] = "0"; 
          
        }   
      }
    }  
    return body;
  }catch(error){
    return (error);
  }

}

async function foundationApiCall(ciData,typeOfRequest,jwt){
  return new Promise(async (resolve,reject)=>{
      try{
          console.log("INSIDE FOUNDATIONAPICALL");
          console.log("jwt is :",jwt);
          //RETRIEVE ALL THE CI INFORMATION WITH PROPER NAME INSTEAD OF ID's data for the API
          var query1 = "WITH new_config_items AS (\
          SELECT mf.field1_key as manufacturer_name,ms.field1_key as status_name,ci_id,ci_code, ci_name ,cm.class_name as class, ci.class_id,ci.editable,ci.spcm_category_id,ci.spcm_category_name,ci.created_at,ci.updated_at,ci.created_by,ci.updated_by,class_name,CONCAT(Cast(category_name as Varchar(500)) , CONCAT ('|',Cast(sub_category_name as Varchar(500)))) AS category_name,description,ci.company_id,company_name,ci.status,metallic,environment,group_name,owner_name,location_id,location_name,manufacturer,dataset,support_company_id, support_company_name,business_owner_id,business_owner_name,technical_owner_id,technical_owner_name,asset_tag from config_items as ci\
          left join class_master as cm on ci.class_id=cm.class_id\
          left join category_master_v2 as cat on cat.category_id=ci.category_id\
          left join menulist as ms on ci.status=ms.FIELD1_VALUE AND ms.field1_name='Status'\
          left join menulist as mf on ci.manufacturer=mf.FIELD1_VALUE AND mf.field1_name='Manufacturer'  )\
          SELECT ci_id,ci_name,class,company_id,status_name,manufacturer_name,location_name,business_owner_id,business_owner_name,technical_owner_id,technical_owner_name\
          FROM new_config_items  where ci_id ="+ciData.CI_ID+" ORDER BY created_at ";
          var data = await runQuery(query1,[]);
          var finalData = data[0];

          //NOW RETRIEVE SERIAL NUMBER AND MODEL ID OF THE CI FROM CI_ATTRIBUTE_MAPPING TABLE
          var  query2 = "SELECT CI_ATTRIBUTE_MAPPING.CI_ID , CI_ATTRIBUTE_MAPPING.VALUE , ATTRIBUTE_NAME FROM CI_ATTRIBUTE_MAPPING\
          LEFT JOIN ATTRIBUTE_MASTER ON  CI_ATTRIBUTE_MAPPING.ATTR_ID = ATTRIBUTE_MASTER.ATTRIBUTE_ID\
          WHERE CI_ID = "+ciData.CI_ID+"  AND ATTRIBUTE_NAME in ('Model ID','Serial Number'); ";
          console.log("query2 is :",query2);
          var data2 = await runQuery(query2,[]); 
          if(data2.length == 2){               
              for(var x in data2){
                  var str = data2[x].ATTRIBUTE_NAME;
                  str = str.toUpperCase(); //Convert STring to uppercase
                  str = str.replace(/ /g, "_"); //for replacing spaces with '_'
                  finalData[str]= data2[x].VALUE;
              }
          }else if(data2.length ==1){
              if(data2[0].ATTRIBUTE_NAME == 'Model ID'){
                  var str = data2[0].ATTRIBUTE_NAME;
                  str = str.toUpperCase(); //Convert STring to uppercase
                  str = str.replace(/ /g, "_"); //for replacing spaces with '_'
                  finalData[str]= data2[0].VALUE;
                  finalData['SERIAL_NUMBER'] = "";
              }else{
                  var str = data2[0].ATTRIBUTE_NAME;
                  str = str.toUpperCase(); //Convert STring to uppercase
                  str = str.replace(/ /g, "_"); //for replacing spaces with '_'
                  finalData[str]= data2[0].VALUE;
                  finalData['MODEL_ID'] = "";
              }

          }
          else{
            
              finalData['SERIAL_NUMBER'] = '';
              finalData['MODEL_ID'] = '';
          }
          console.log("FINAL DATA  is :",finalData);
          var payload=[];
          if(((finalData.BUSINESS_OWNER_ID)&& (finalData.BUSINESS_OWNER_NAME)) || ((finalData.TECHNICAL_OWNER_ID)&&(finalData.TECHNICAL_OWNER_NAME))){
              if((finalData.BUSINESS_OWNER_ID)&&(finalData.BUSINESS_OWNER_NAME)){
                  console.log("business_owner is present");
                  const obj1={
                      "ciId" : finalData.CI_ID ,
                      "userId": finalData.BUSINESS_OWNER_ID,
                      "ownerType": "BUSINESS OWNER",
                      "assetInfo": "Name: "+finalData.CI_NAME+" , Serial No.: "+finalData.SERIAL_NUMBER +" , Make: "+finalData.MANUFACTURER_NAME+" , Model: "+finalData.MODEL_ID+" , Class: "+finalData.CLASS+" , Location: "+finalData.LOCATION_NAME+" , Status: "+finalData.STATUS_NAME

                  };
                  payload.push(obj1);
                 
                  
              }
              if(((finalData.TECHNICAL_OWNER_ID)&&(finalData.TECHNICAL_OWNER_NAME))){
                  console.log("technical_owner is present");
                  const obj2={
                      "ciId" : finalData.CI_ID ,
                      "userId":finalData.TECHNICAL_OWNER_ID,
                      "ownerType": "TECHNICAL OWNER",
                      "assetInfo": "Name: "+finalData.CI_NAME+" , Serial No.: "+finalData.SERIAL_NUMBER +" , Make: "+finalData.MANUFACTURER_NAME+" , Model: "+finalData.MODEL_ID+" , Class: "+finalData.CLASS+" , Location: "+finalData.LOCATION_NAME+" , Status: "+finalData.STATUS_NAME

                  };
                  payload.push(obj2);


              }
          }else{
              console.log("NO OWNER FOR  CI_ID: ",finalData.CI_ID);
             
          }

          if(payload.length){
              console.log("Calll Foundation API");
              payload = JSON.stringify(payload);
              console.log("After stringify the payload is :",payload);
              console.log("typeOfRequest: ",typeOfRequest);
              if(typeOfRequest.toUpperCase()=='POST'){
                  console.log("POST REQUEST TO BE MADE TO THE FOUNDATION");
                  var foundationUrl = foundationBaseUrl+"/api/AssetCreation";
                  console.log("Foundation url is : ", foundationUrl);
                  const config = {
                    headers: {
                      'x-user-payload': jwt,
                      'Content-Type':'application/json'
                    }
                  };
                  
                  axios.post(foundationUrl,payload,config)
                  .then(function(response){
                    console.log("Response from the FOUNDATION API is :",response.data);
                  })
                  .catch(function(error){
                    console.log("error is :",error);
                  });

    
              }else{
                  console.log("POST REQUEST TO BE MADE TO THE FOUNDATION ENEN THOUGH A PATCH HAS TO BEEN DONE");
                  var foundationUrl = foundationBaseUrl+"/api/AssetCreation";
                  console.log("Foundation url is : ", foundationUrl);
                  const config = {
                    headers: {
                      'x-user-payload': jwt,
                      'Content-Type':'application/json'
                    }
                  };
                 
                  
                  axios.post(foundationUrl,payload,config)
                  .then(function(response){
                    console.log("Response from the FOUNDATION API is :",response.data);
                  })
                  .catch(function(error){
                    console.log("error is :",error);
                  });
                  
          
              }
              

          }else{

              console.log("do not call foundation api");

          }
          resolve("DONE");
      }catch(error){
      reject(error);
    }
  })     
};



module.exports={runQuery,patch_call_cmdb_interface,checkIsExistInDb,encryptDecrypt,epochToDateFormat,timeZoneCalc,dateFormatToEpoch,keysToBeSearchedInJWT,foundationApiCall}
