const jwt = require('jsonwebtoken');

const config = require('./config.json');
const {runQuery,encryptDecrypt} = require('./functions');

// SEC MIDDLEWARE START HERE

const jwtSecret=process.env.JWTSECRET;//||config.security.JWTSECRET;
const CLIENT_PAYLOAD_KEY=process.env.CLIENT_PAYLOAD_KEY;//||config.security.CLIENT_PAYLOAD_KEY;
const SECKEYNAME=process.env.API_SECKEYNAME;//||config.security.API_SECKEYNAME;
const SECKEYVALUE=process.env.API_SECKEYVALUE;//||config.security.API_SECKEYVALUE;


const SEC_MIDDLEWARE = async (req, res, next)=> {   
    try{
    if(SECKEYNAME== undefined || SECKEYNAME == null || SECKEYNAME == " " ) {
        console.log("SECKEYNAME is empty!")
        return res.status(400).send({auth: false, message: 'SECKEYNAME is empty!'});
    
    }
    const token = req.headers[CLIENT_PAYLOAD_KEY] //x-auth-token

    if (!token) return res.status(400).send({ auth: false, message: 'Request validation details not found!' });
    console.log("Token is :",token);

    
    let  decoded =  jwt.verify(token, jwtSecret);

    if(req.headers['x-user-payload']){
        const decode64token = Buffer.from(decoded.encode64payload, 'base64').toString("ascii");       
        decoded = await encryptDecrypt(decode64token);
        decoded=JSON.parse(decoded);
        req.decodedJWT = decoded;
        console.log("JWT IS :",req.decodedJWT);
    }
    
    if(decoded[SECKEYNAME]!=SECKEYVALUE) return res.status(400).send({ auth: false, message: 'Request key validation error!' });
  
    const sqlQuery=` SELECT REGEX from BLUADMIN.PERMISSIONMATRIX WHERE HTTP_${req.method}=1 AND ROLE_ID in (${decoded.role_id})`;

  
    let result=await runQuery(sqlQuery,[]);

    result=result.map(function (item) { return item.REGEX; });

    const regexPatterns=new RegExp(result.join("|"));

    if(result.length>0&&regexPatterns.test(req.path)){
        console.log("Requested IP Address:",req.connection.remoteAddress);
        next();
    }else
    {
        return res.status(401).send({ auth: false, message: 'Unauthorized' });
    }
    }catch(error){
        console.log("Error is: ", error);
        res.send({message:`${error}`});
    }

}

// MIDDLEWARE ADDED

module.exports={SEC_MIDDLEWARE}