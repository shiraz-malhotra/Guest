//local files
const config = require('./config.json');
var ibmdb = require('ibm_db');
var conn_str=process.env.IBMDB2_CONN_STRING;//||config.database.db2connString;

//ibm_db Pool has been created in order to implement connection pooling
var Pool = ibmdb.Pool
	, pool = new Pool()
    , cn = conn_str;
pool.open(cn, function (err, dbCon) {
	if (err) {
		return console.log(err);
  }
  db = dbCon;
  console.log("Connection to database is been made");
});
module.exports = pool;
/**
CREATE TABLE config_items(
  ci_id int NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
  ci_code varchar(20) NOT NULL,
  ci_name varchar(500) NOT NULL,
  class_id int NOT NULL,   
  description VARCHAR(5000),
  company_id int NOT NULL, 
  company_name varchar(500) NOT NULL,
  status varchar(10) NOT NULL,  
  category_id int NOT NULL, 
  sub_category_id int NOT NULL, 
  metallic varchar(500),
  environment varchar(500),
  group_id int NOT NULL, 
  group_name varchar(500) NOT NULL,
  owner_id int NOT NULL,
  owner_name varchar(500) NOT NULL,
  location_id int NOT NULL,
  location_name varchar(500) NOT NULL,
  manufacturer varchar(500),
  dataset varchar(500),
  PRIMARY KEY (ci_id)
)

INSERT INTO config_items (ci_code, ci_name, class_id,company_id,company_name,status,category_id,
  sub_category_id,group_id,group_name,owner_id,owner_name,location_id,location_name)  
VALUES ('ci_code', 'ci_name', 1,2,'company_name','status',3,
  4,5,'group_name',6,'owner_name',7,'location_name')
y



ALTER TABLE CONFIG_ITEMS
ADD editable  char(1) default 'Y';
ALTER TABLE CONFIG_ITEMS
ADD CHECK (editable in ('Y', 'N'));


ALTER TABLE CONFIG_ITEMS
ADD spcm_CATEGORY_ID INT;

ALTER TABLE CONFIG_ITEMS
ADD spcm_CATEGORY_NAME  VARCHAR(500);


ALTER TABLE CONFIG_ITEMS
ADD spcm_offering_id INT;

 */