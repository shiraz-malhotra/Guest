//local files
const config = require('./config.json');
const logger=require('./logsetup');
// const connection=require('./dbsetup');
const pool= require('./dbsetup');
// environment setup
process.env.NODE_ENV=process.env.NODE_ENV;//||config.server.environment;
logger.info("Current Environment ******** ",process.env.NODE_ENV);

module.exports = {config,pool};


