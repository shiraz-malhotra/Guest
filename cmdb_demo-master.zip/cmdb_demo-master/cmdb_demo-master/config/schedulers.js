const {runQuery} = require('./functions');
const config = require('./config');
const chunkSize = process.env.CHUNK_SIZE || 200;
var schedule = require('node-schedule');
const ci_code_prefix="ASTCI";

const ciCodeUpdation = ( executeDataa)=>{
    return new Promise((resolve,reject)=>{
      try{
        var code = [],new_ci_code,ciId =[], caseArr = [],str;
        for(key in executeDataa){
            var x = executeDataa[key];
            for(keys in x)
            {
                ciId.push(x.CI_ID);
                new_ci_code=codeGeneratorMethod(ci_code_prefix,x.CI_ID);
                code.push(new_ci_code);
                str = "WHEN CI_ID = "+ x.CI_ID+" THEN '"+new_ci_code+"'";
                caseArr.push(str);
            }
        }
        var xy = caseArr.join(" ");
        resolve(xy);
      }catch(error){
        reject(error);
      }
    })     
};

async function getIdForManufaturer(x,keyDs,valueDs){
    return new Promise(async (resolve,reject)=>{
        try{
            var index,returnVal;
            if(keyDs.includes(x.toUpperCase())){
                index = keyDs.indexOf(x.toUpperCase());
                returnVal = valueDs[index];
            }else{
                //Initiate an insert query;
                var executeQuery1 ="select MAX(cast(FIELD1_VALUE as Integer)) as MAXCOUNT from menulist where field1_name='Manufacturer'";   
                var executeData1 = await runQuery(executeQuery1,[]);
                var val  = executeData1[0].MAXCOUNT +5;
                var excuteQuery2 = "SELECT FIELD1_VALUE FROM FINAL TABLE (INSERT INTO BLUADMIN.MENULIST (MODULE,FIELD1_NAME,FIELD1_KEY,FIELD1_VALUE,FIELD2_NAME,FIELD2_KEY,FIELD2_VALUE,FIELD3_NAME,FIELD3_KEY,FIELD3_VALUE) VALUES ('CI','Manufacturer','"+x+"','"+ val+"',NULL,NULL,NULL,NULL,NULL,NULL));";
                var executeData2 = await runQuery(excuteQuery2,[]);
                returnVal = executeData2[0].FIELD1_VALUE;
            }
  
            resolve(returnVal);
        }catch(error){
        reject(error);
      }
    })     
};


async function getCiId(x,data){
    return new Promise(async (resolve,reject)=>{
        try{
            var returnVal;
            for(var keys in data){
                var y = data[keys];
                if(y.EXT_SYS_ID == x){
                    returnVal = y.CI_ID;
                }
            }
            console.log("from inside func returnVal is :",returnVal);
            resolve(returnVal);
        }catch(error){
        reject(error);
      }
    })     
};

async function getAttId(classId , attName){
    return new Promise(async (resolve,reject)=>{
        try{
            var returnVal;
            var fetchAttribute = "SELECT ATTRIBUTE_ID from ATTRIBUTE_MASTER WHERE CLASS_ID ="+classId+"  AND ATTRIBUTE_NAME ='"+attName+"'";
            var attributeData = await runQuery(fetchAttribute,[classId]);

            if( attributeData[0]== null || attributeData[0]==undefined ){
                var executeQuery = "SELECT ATTRIBUTE_ID FROM FINAL TABLE (INSERT INTO BLUADMIN.ATTRIBUTE_MASTER (ATTRIBUTE_NAME,CLASS_ID,STATUS,MANDATORY) VALUES('"+attName+"',"+classId+",'active','1'));";
                var queryData = await runQuery(executeQuery,[]);
                returnVal = queryData[0].ATTRIBUTE_ID;
            }else
                returnVal = attributeData[0].ATTRIBUTE_ID;
            
        
            resolve(returnVal);
        }catch(error){
        reject(error);
      }
    })     
};
async function attrMappingForExistCi(mappedData,ciIdExist,attIdArr,attValArr){
    return new Promise(async (resolve,reject)=>{
        try{
            for(key in mappedData){
                var y = mappedData[key];
                
                if(ciIdExist.includes(y.CI_ID) && attIdArr.includes(y.ATTR_ID) ){
                    
                    index = ciIdExist.indexOf(y.CI_ID);
                    if(attValArr[index]!=""){
                    var executeQuery = "UPDATE BLUADMIN.CI_ATTRIBUTE_MAPPING SET VALUE ='"+attValArr[index]+"'  WHERE CI_ID = "+ciIdExist[index]+" AND   ATTR_ID ="+attIdArr[index];
                    console.log("executeQuery:",executeQuery);
                    var executeData = await runQuery(executeQuery,[]);
                    ciIdExist.splice(index, 1);
                    attIdArr.splice(index,1);
                    attValArr.splice(index,1);
                    }

                }
                
            }
            
            if(attIdArr.length!=0){
                var str,valAtt=[];
                for(var i =0;i<attIdArr.length;i++){
                    str = "( "+ciIdExist[i] + " , "+ attIdArr[i] + " , '"+attValArr[i]+"')";
                    valAtt.push(str);
                }
               
                var executeQuerry = 'INSERT INTO BLUADMIN.CI_ATTRIBUTE_MAPPING (CI_ID,ATTR_ID,"VALUE") VALUES '+valAtt.join(",");
                console.log("executeQuerry:",executeQuerry); 
                var executeData = await runQuery(executeQuerry,[]);
            }
        
                
            
            resolve("DONE");
        }catch(error){
        reject(error);
      }
    })     
};

//SCHEDULER RUNS IN EVERY 30 MINUTES 

var j  = schedule.scheduleJob('0 * * * *',async function(){

    var start = new Date();
       
    var currentJobId=0;
    try{
    //GO TO JOB_PENDING TABLE. FETCH THE JOB_ID WHICH IS IN PENDING STAGE IN ASC ORDER
    const queryPendingJob = "SELECT JOB_ID, CUSTOMER FROM JOB_PENDING WHERE UPPER(STATUS) = 'PENDING' ORDER BY CREATED_AT ASC FETCH FIRST 1 ROW ONLY ;"
    const pendingJobData = await runQuery(queryPendingJob,[]);
    
    if(pendingJobData.length !=0){
        //CHECK FOR NO OVERLAP RUNS FOR SAME CUSTOMER
        currentJobId = pendingJobData[0].JOB_ID;
        var customer = pendingJobData[0].CUSTOMER;
        console.log("Current job id is: ",currentJobId);

        const queryWIP = "SELECT * FROM JOB_PENDING WHERE UPPER(CUSTOMER) = '"+customer.toUpperCase()+"' AND UPPER(STATUS) = 'WORK_IN_PROGRESS';"
        const wipData = await runQuery(queryWIP,[]);

        if(wipData.length != 0){
            
            //IF THERE IS SOME OVERLAPPING CUSTOMER RUN, THEN WAIT FOR NEXT scheduled time
            console.log("DON'T DO ANYTHING AS SOME JOB WITH SAME CUSTOMER IS IN WORK_IN_PROGRESS STATE");
            console.log("***********CURRENT SCHEDULED JOB DONE***********");

        }else{
            
            //IF THERE IS NO OVERLAPPING CUSTOMER RUN, THEN START PROCESSING THE CURRENT JOB_ID
            console.log("DO THE ENTIRE WORK NOW");
            //change the status of that job_id in the JOB_PENDING table to WORK_IN_PROGRESS
            const queryStatus="UPDATE JOB_PENDING SET STATUS = 'WORK_IN_PROGRESS' WHERE JOB_ID = ?";
            const queryStatusData = await runQuery(queryStatus,[currentJobId]);

            const queryPendingCi = "SELECT TEMP_ID,EXT_SYS_ID,EXT_SOURCE,CI_CODE,CI_NAME,CLASS_ID,DESCRIPTION,COMPANY_ID,COMPANY_NAME,STATUS,CATEGORY_ID,SUB_CATEGORY_ID,METALLIC,ENVIRONMENT,GROUP_ID,GROUP_NAME,OWNER_ID,OWNER_NAME,LOCATION_ID,LOCATION_NAME,MANUFACTURER,DATASET,CREATED_BY,UPDATED_BY,UPDATED_AT,SUPPORT_COMPANY_ID,SUPPORT_COMPANY_NAME,BUSINESS_OWNER_ID,BUSINESS_OWNER_NAME,TECHNICAL_OWNER_ID,TECHNICAL_OWNER_NAME,ASSET_TAG,EDITABLE,SPCM_CATEGORY_ID,SPCM_CATEGORY_NAME,SPCM_OFFERING_ID,CREATED_AT,JOB_ID,SERIAL_NUMBER,MODEL_ID,CI_TRANS_STATUS,ERR_DESCRIPTION,ERR_CODE FROM TEMP_CONFIG_ITEMS WHERE JOB_ID = ? AND UPPER(CI_TRANS_STATUS) = 'PENDING' ";
            const pendingCiData = await runQuery(queryPendingCi,[currentJobId]);
            //console.log("CI's which are in PENDING state are: ",pendingCiData);
            console.log("\n\n\n\nPENDING DATA retrived");

            if(pendingCiData.length>0){
            //biforcating array of json objects in chunk size
            var results =[];
            var finalStatus='COMPLETED WITH VALID CI';
            while(pendingCiData.length){
                results.push(pendingCiData.splice(0,chunkSize));
            }
            //Retrieving existing EXT_SYS_ID from the main CONFIG_ITEMS table
            var queryciInMainTab  = "SELECT EXT_SYS_ID FROM CONFIG_ITEMS WHERE EXT_SYS_ID NOT LIKE ''";
            var ciInMainTab = await runQuery(queryciInMainTab,[]);
            var existSysId = ciInMainTab.map(data => data.EXT_SYS_ID);
            console.log("EXISTING EXT_SYS_ID IN CONFIG_ITEMS TABLE:",existSysId);

            //GETTING  MANUFATURE FROM MENULIST
            var executeForManufacture = "SELECT distinct(field1_key),field1_value  from menulist WHERE field1_name='Manufacturer' AND module='CI' ORDER BY field1_key ASC";
            var executeDataManufacture = await runQuery(executeForManufacture,[]);
            var keyDs=[], valueDs=[];
            for(var key in executeDataManufacture){
                var x = executeDataManufacture[key];
                keyDs.push(x.FIELD1_KEY.toUpperCase());
                valueDs.push(x.FIELD1_VALUE);
            } 

            //Traversing the chunkzise array objects and processing it
            for(var i =0;i<results.length;i++){
                // for(var j=0;j<results[i].length;j++){
                //     var x = results[i];
                    //console.log("\t\t",x[j]);
                    
                    //CHECK ON EACH CI
                    var err_code=[],err_description=[],temp_id=[];
                    var existingClasses = Object.values(config.classes);
                    var mandatoryKeys = Object.keys(config.mandatory);
                    var checkedCi = results[i].filter(function (ciArr) {
                        


                        //Check 1:MANDATORY FIELDS
                        errCheck2 = (ciArr)=>{
                            var f = true;
                            var keysInJson=Object.keys(ciArr);
                            var valuesInJson=Object.values(ciArr);
                            var str= "";
                            for (var key in keysInJson){
                                if(mandatoryKeys.includes(keysInJson[key])){
                                    if(((keysInJson[key].includes("ID"))&&(valuesInJson[key]==0)) || (valuesInJson[key]===""))
                                        str=str +"   "+ keysInJson[key];    
                                }
                            }
                            if(str !=""){
                                err_description.push("Mandatory field(s) empty for"+ str );
                                err_code.push('E01');
                                temp_id.push("'"+ciArr.TEMP_ID+"'");
                                f = false;
                            }if(f){
                                console.log("\n"+ciArr.TEMP_ID+"PASSED AT CHECK2");
                                console.log("f is :",f);
                            }else{
                                console.log("\n"+ciArr.TEMP_ID+"FAILED AT CHECK2");
                                console.log("f is :",f);
                            }
                            
                    
                            return f;
                        }    
                
                        //Check 2: LENGTH OF FIELDS
                        errCheck1 = (ciArr)=>{
                            var arrVal=[],arrKey=[],f=true;
                        
                            val1 = (( ciArr.EXT_SYS_ID).length <= config.columns_length.EXT_SYS_ID)?true:false; 
                            val2 = ((ciArr.EXT_SOURCE).length <= config.columns_length.EXT_SOURCE)?true:false;
                            val3 = ((ciArr.CI_NAME).length <=config.columns_length.CI_NAME)?true:false;
                            val4 = ((ciArr.DESCRIPTION).length <= config.columns_length.DESCRIPTION?true:false);
                            if(ciArr.COMPANY_ID == null || ciArr.COMPANY_ID ==" " ){
                                val5 = true;
                            }else{
                                val5 = ((ciArr.COMPANY_ID.toString()).length <= config.columns_length.COMPANY_ID?true:false);
                                
                            }
                            if(ciArr.CLASS_ID == null || ciArr.CLASS_ID == " "){
                                val6 = true;
                            }else{
                                val6 = ((ciArr.CLASS_ID.toString()).length <= config.columns_length.CLASS_ID?true:false);
                                
                            }
                            if(ciArr.STATUS == null || ciArr.STATUS == " "){
                                val7 = true;
                            }else{
                                val7 = ((ciArr.STATUS.toString()).length <= config.columns_length.STATUS?true:false);
                                
                            }
                            if(ciArr.GROUP_ID == null || ciArr.GROUP_ID == " "){
                                val8 = true;
                                
                            }else{
                                val8 = ((ciArr.GROUP_ID.toString()).length <= config.columns_length.GROUP_ID?true:false);
                            }
                            val9 = ((ciArr.GROUP_NAME).length <= config.columns_length.GROUP_NAME?true:false);
                            if(ciArr.ENVIRONMENT == null || ciArr.ENVIRONMENT == " "){
                                val10 = true;
                            }else{
                                val10 = ((ciArr.ENVIRONMENT.toString()).length <= config.columns_length.ENVIRONMENT?true:false);
                                
                            }
                            if(ciArr.BUSINESS_OWNER_ID == null || ciArr.BUSINESS_OWNER_I== " "){
                                val11 = true;
                                
                            }else{
                                val11 = ((ciArr.BUSINESS_OWNER_ID.toString()).length <= config.columns_length.BUSINESS_OWNER_ID?true:false);
                                
                            }
                           
                            
                            val12 = ((ciArr.BUSINESS_OWNER_NAME).length <= config.columns_length.BUSINESS_OWNER_NAME?true:false);

                            if(ciArr.TECHNICAL_OWNER_ID == null || ciArr.TECHNICAL_OWNER_ID == " "){
                                val13 = true;
                            }else{
                                val13 = ((ciArr.TECHNICAL_OWNER_ID.toString()).length <= config.columns_length.TECHNICAL_OWNER_ID?true:false);
                                
                            }
                            
                            
                            val14 = ((ciArr.TECHNICAL_OWNER_NAME).length <= config.columns_length.TECHNICAL_OWNER_NAME?true:false);

                            if(ciArr.SUPPORT_COMPANY_ID == null || ciArr.SUPPORT_COMPANY_ID == " "){
                                val15 = true;
                            }else{
                                val15 = ((ciArr.SUPPORT_COMPANY_ID.toString()).length <= config.columns_length.SUPPORT_COMPANY_ID?true:false);
                                
                            }
                            
                            val16 = ((ciArr.SUPPORT_COMPANY_NAME).length <= config.columns_length.SUPPORT_COMPANY_NAME?true:false);
                            val17 = ((ciArr.MANUFACTURER).length <= config.columns_length.MANUFACTURER?true:false);
                            val18 = ((ciArr.SERIAL_NUMBER).length <= config.columns_length.SERIAL_NUMBER?true:false);
                            val19 = ((ciArr.MODEL_ID).length <= config.columns_length.MODEL_ID?true:false);
                            val20 = ((ciArr.COMPANY_NAME).length <= config.columns_length.COMPANY_NAME?true:false);
                        
                            arrKey.push(val1,val2,val3,val4,val5,val6,val7,val8,val9,val10,val11,val12,val13,val14,val15,val16,val17,val18,val19,val20);
                            arrVal.push("EXT_SYS_ID","EXT_SOURCE","CI_NAME","DESCRIPTION","COMPANY_ID","CLASS_ID","STATUS","GROUP_ID","GROUP_NAME","ENVIRONMENT","BUSINESS_OWNER_ID","BUSINESS_OWNER_NAME","TECHNICAL_OWNER_ID","TECHNICAL_OWNER_NAME","SUPPORT_COMPANY_ID","SUPPORT_COMPANY_NAME","MANUFACTURER","SERIAL_NUMBER","MODEL_ID","COMPANY_NAME");
                            var invalCi=[];
                            for(var keyss in arrKey){
                                if(arrKey[keyss]==false){
                                    invalCi.push(arrVal[keyss]);
                                
                                }
                            }
                            if(invalCi.length > 0){
                                err_description.push("Data size exceeded for "+invalCi.join(","));
                                err_code.push('E02');
                                temp_id.push("'"+ciArr.TEMP_ID+"'");
                                f = false;
                            }
                            if(f){
                                console.log("\n"+ciArr.TEMP_ID+"PASSED AT CHECK1");
                                console.log("f is :",f);
                            }else{
                                console.log("\n"+ciArr.TEMP_ID+"FAILED AT CHECK1");
                                console.log("f is :",f);
                            }
                            return f;
                        }
        
                        
        
                        //Check :CLASS NOT DEFINED
                        errCheck3 = (ciArr)=>{
                        
                            var f = true;
                            if(!(existingClasses.includes(ciArr.CLASS_ID.toString()))){
                                temp_id.push("'"+ciArr.TEMP_ID+"'");
                                err_code.push('E03');
                                err_description.push('CLASS NOT DEFINED');
                                f = false;
                            }
                            if(f){
                                console.log("\n"+ciArr.TEMP_ID+"PASSED AT CHECK3");
                                console.log("f is :",f);
                            }else{
                                console.log("\n"+ciArr.TEMP_ID+"FAILED AT CHECK3");
                                console.log("f is :",f);
                            }
                            return f;
                        } 
                        errCheck4 = (ciArr)=>{
                            var arrVall=[],arrKeyy=[],f=true;
                            console.log("INSIDE ERROR CHECK 4");
                    
                            vall1 = ((ciArr.COMPANY_ID.match(/[a-z]/i)) ? false:true);
                            vall2 = ((ciArr.CLASS_ID.match(/[a-z]/i)) ? false:true);
                            vall3 = ((ciArr.GROUP_ID.match(/[a-z]/i)) ? false:true);
                            vall4 = ((ciArr.BUSINESS_OWNER_ID.match(/[a-z]/i)) ? false:true);
                            vall5 = ((ciArr.TECHNICAL_OWNER_ID.match(/[a-z]/i)) ? false:true);
                            vall6 = ((ciArr.SUPPORT_COMPANY_ID.match(/[a-z]/i)) ? false:true);
                            vall7 = ((ciArr.CATEGORY_ID.match(/[a-z]/i)) ? false:true);
                            vall8 = ((ciArr.SUB_CATEGORY_ID.match(/[a-z]/i)) ? false:true);
                            vall9 = ((ciArr.OWNER_ID.match(/[a-z]/i)) ? false:true);
                            vall10 = ((ciArr.LOCATION_ID.match(/[a-z]/i)) ? false:true);
                            
                            
                            arrKeyy.push(vall1,vall2,vall3,vall4,vall5,vall6,vall7,vall8,vall9,vall10);
                            arrVall.push("COMPANY_ID","CLASS_ID","GROUP_ID","BUSINESS_OWNER_ID","TECHNICAL_OWNER_ID","SUPPORT_COMPANY_ID","CATEGORY_ID","SUB_CATEGORY_ID","OWNER_ID","LOCATION_ID");
                            var invalCi=[];
                            for(var keyss in arrKeyy){
                                if(arrKeyy[keyss]==false){
                                    invalCi.push(arrVall[keyss]);
                                
                                }
                            }
                            if(invalCi.length > 0){
                                err_description.push("DATATYPE MISMATCH FOR "+invalCi.join(","));
                                err_code.push('E04');
                                temp_id.push("'"+ciArr.TEMP_ID+"'");
                                f = false;
                            }
                            if(f){
                                console.log("\n"+ciArr.TEMP_ID+"PASSED AT CHECK4");
                        
                            }else{
                                console.log("\n"+ciArr.TEMP_ID+"FAILED AT CHECK4");
                            
                            }
                            return f;
                        }
                       
                        return errCheck1(ciArr) && errCheck2(ciArr) && errCheck3(ciArr) && errCheck4(ciArr);
            
                    });
                    
                    console.log("\n\nERROR CHECKING ON CIs DONE");
                    var invalidCi=[];
                    //if invalid ci are present then change their ci_trans_status to INVALID 
                    
                    if(temp_id.length > 0){
                        finalStatus='COMPLETED WITH INVALID CI';

                        for(var key in temp_id){
                            var queryInvalidCi = "SELECT EXT_SYS_ID FROM FINAL TABLE(UPDATE BLUADMIN.TEMP_CONFIG_ITEMS SET CI_TRANS_STATUS = 'INVALID',ERR_CODE='"+err_code[key]+"',ERR_DESCRIPTION='"+err_description[key]+"' WHERE TEMP_ID ="+temp_id[key]+" AND JOB_ID = "+currentJobId+")";
                            console.log("queryInvalidCi is :",queryInvalidCi);
                            var invalidCiUpdated = await runQuery(queryInvalidCi,[]);
                            invalidCi.push("'"+invalidCiUpdated[0].EXT_SYS_ID+"'");
                        }
                    }
            
                    //DATA AUGMENTATION
                    var x = results[i];
                    for(var j =0;j<x.length;j++){
                        
                        //Updating the manufature for the ci's
                        var x1 = await getIdForManufaturer(x[j].MANUFACTURER,keyDs,valueDs);
                        var queryUpdateManufacture = "UPDATE TEMP_CONFIG_ITEMS SET MANUFACTURER = ? WHERE TEMP_ID = ?";
                        var updatedManufacturer = await runQuery(queryUpdateManufacture,[x1,x[j].TEMP_ID]);
                        
                    }
                    

                    if(checkedCi.length > 0){

                        //STEP 4: CI's PASSING ALL THE CHECK HAVE VALID CI_TRANS_STATUS AND REST HAVE INVALID CI_TRANS_STATUS.ON BASIS OF VALID AND INVALID TRANSFER THEM IN CONFIG_ITEMS TABLE
                        //FIRSTLY, FOR Valid CI's
                        var validCi=checkedCi.map(key=>key.TEMP_ID);
                        console.log("strValidCi : ",validCi);
                        var queryValidCi = "SELECT EXT_SYS_ID FROM FINAL TABLE(UPDATE BLUADMIN.TEMP_CONFIG_ITEMS SET CI_TRANS_STATUS = 'VALID' WHERE TEMP_ID IN ("+validCi.join(',')+") AND JOB_ID = "+currentJobId +" )";
                        console.log("queryValidCI:",queryValidCi);
                        var validCiUpdated = await runQuery(queryValidCi,[]);
                        console.log( "\n\nVALID STATUS UPDATED IN TEMP_CONFIG_ITEMS TABLE");
                        
                        //TRANSFER FROM TEMP_CONFIG_ITEMS to CONFIG_ITEMS WHERE CI_TRANS_STATUS = 'VALID'
                        //UPSERTION DATA FROM TEMP_CONFIG_ITEMS TABLE TO CONFIG_ITEMS TABLE  
                        var existCi = "SELECT CI_ID , CI_NAME,EXT_SYS_ID FROM CONFIG_ITEMS";
                        var existCiData  = await runQuery(existCi,[]);
                        var name=[],ciIdCheck=[];
                        for(key in existCiData ){
                            var x  = existCiData[key]
                            name.push(x.EXT_SYS_ID);
                            ciIdCheck.push(x.CI_ID);
                        }
                        var executeQuery4 = "SELECT EXT_SYS_ID, CLASS_ID , MODEL_ID, SERIAL_NUMBER FROM TEMP_CONFIG_ITEMS WHERE JOB_ID = "+currentJobId+" AND CI_TRANS_STATUS = 'VALID'";
                        var executeData4 = await runQuery(executeQuery4,[]);

                        
                        var attId,cId,ciInsertion=[],extSysIdNew=[],attValArr=[],ciIdExist=[],attIdArr=[],valAttNewCI=[],extSysIdExist=[],attIDNew=[],attValNew=[],extSysForAtt=[];
                        for(key in executeData4){
                            var y = executeData4[key];
                            var index;
                            if(name.includes(y.EXT_SYS_ID)){
                                console.log("EXIST");
                                index = name.indexOf(y.EXT_SYS_ID);
                                extSysIdExist.push(y.EXT_SYS_ID);
                                if(y.SERIAL_NUMBER!=""){  
                                    attId = await getAttId(y.CLASS_ID,'Serial Number');
                                    attIdArr.push(attId);
                                    ciIdExist.push(ciIdCheck[index]);
                                    attValArr.push(y.SERIAL_NUMBER);
                                    
                                }
                                if(y.MODEL_ID!="" ){
                                    attId = await getAttId(y.CLASS_ID,'Model ID');
                                    attIdArr.push(attId);
                                    ciIdExist.push(ciIdCheck[index]);
                                    attValArr.push(y.MODEL_ID);
                                }
                            }else{
                            
                                console.log("DOES NOT EXIST");
                                extSysIdNew.push(y.EXT_SYS_ID);
                                ciInsertion.push("'"+y.EXT_SYS_ID+"'");
                                if(y.SERIAL_NUMBER!=""){            
                                    attId = await getAttId(y.CLASS_ID,'Serial Number');
                                    attIDNew.push(attId);
                                    attValNew.push("'"+y.SERIAL_NUMBER+"'");
                                    extSysForAtt.push(y.EXT_SYS_ID);
                                }
                                if(y.MODEL_ID!="" ){
                                    attId = await getAttId(y.CLASS_ID,'Model ID');
                                    attIDNew.push(attId);
                                    attValNew.push("'"+y.MODEL_ID+"'");
                                    extSysForAtt.push(y.EXT_SYS_ID);
                                }
                                
                            }
                        }
                        var sqlInsert,sqlUpdate,sqlInsertData,sqlUpdateData;
                        if(ciInsertion.length!=0){
                            //CI FOR INSERTION
                            val = ciInsertion.join(',');
                            sqlInsert = "SELECT EXT_SYS_ID,CI_ID,CI_NAME FROM FINAL TABLE(INSERT INTO BLUADMIN.CONFIG_ITEMS (CI_CODE,CI_NAME,CLASS_ID,DESCRIPTION,COMPANY_ID,COMPANY_NAME,STATUS,CATEGORY_ID,SUB_CATEGORY_ID,METALLIC,ENVIRONMENT,GROUP_ID,GROUP_NAME,OWNER_ID,OWNER_NAME,LOCATION_ID,LOCATION_NAME,MANUFACTURER,DATASET,CREATED_BY,SUPPORT_COMPANY_ID,SUPPORT_COMPANY_NAME,BUSINESS_OWNER_ID,BUSINESS_OWNER_NAME,TECHNICAL_OWNER_ID,TECHNICAL_OWNER_NAME,ASSET_TAG,EDITABLE,SPCM_CATEGORY_ID,SPCM_CATEGORY_NAME,SPCM_OFFERING_ID,CREATED_AT,EXT_SYS_ID,EXT_SOURCE)\
                            SELECT CI_CODE,CI_NAME,CLASS_ID,DESCRIPTION,COMPANY_ID,COMPANY_NAME,STATUS,CATEGORY_ID,SUB_CATEGORY_ID,METALLIC,ENVIRONMENT,GROUP_ID,GROUP_NAME,OWNER_ID,OWNER_NAME,LOCATION_ID,LOCATION_NAME,MANUFACTURER,DATASET,CREATED_BY,SUPPORT_COMPANY_ID,SUPPORT_COMPANY_NAME,BUSINESS_OWNER_ID,BUSINESS_OWNER_NAME,TECHNICAL_OWNER_ID,TECHNICAL_OWNER_NAME,ASSET_TAG,EDITABLE,SPCM_CATEGORY_ID,SPCM_CATEGORY_NAME,SPCM_OFFERING_ID,CREATED_AT,EXT_SYS_ID,EXT_SOURCE FROM BLUADMIN.TEMP_CONFIG_ITEMS WHERE EXT_SYS_ID IN("+val+") AND CI_TRANS_STATUS='VALID' AND JOB_ID = "+currentJobId+")";
                            sqlInsertData = await runQuery(sqlInsert,[]);
                           
                            //STEP :AFTER MOVING CIs WITH  VALID STATUS TO CONFIG_ITEMS TABLE, CHANGE CI_TRANS_STATUS = 'SYNCED' IN TEMP_CONFIG_ITEMS
                            var executeQuery7a = "SELECT EXT_SYS_ID FROM FINAL TABLE(UPDATE BLUADMIN.TEMP_CONFIG_ITEMS SET CI_TRANS_STATUS = 'SYNCED' WHERE EXT_SYS_ID IN ("+val+") AND JOB_ID = "+currentJobId+" )";
                            var executeData7 = await runQuery(executeQuery7a,[]);
                            console.log("\n\nSTEP 5: SYNCED STATUS UPDATED IN TEMP_CONFIG_ITEMS TABLE");

                            var str='',ciAttrMapping=[];
                            for(key in extSysForAtt){
                                str=" ";
                                console.log("\nextSysForAtt[key] is :",extSysForAtt[key]);
                                console.log("\nsqlInsertData is :",sqlInsertData);
                                var ci_id = await getCiId(extSysForAtt[key],sqlInsertData);
                                console.log("ci_id is:",ci_id);
                                str ="("+ci_id+" , "+attIDNew[key] +", "+attValNew[key]+" )";
                                ciAttrMapping.push(str);     
                            }
                        
                            var executeAttribute = 'INSERT INTO BLUADMIN.CI_ATTRIBUTE_MAPPING (CI_ID,ATTR_ID,"VALUE") VALUES '+ciAttrMapping.join(",");
                            console.log("executeAttributemapping for INSERTION : ",executeAttribute);
                            var executeAttData = await runQuery(executeAttribute,[]);

                            //Code for maintaining CI in FOUNDATION table

                            console.log("\n\nSTEP 6.1: CI_ATTRIBUTE_MAPPING OF VALID CI");
                            var executeQuery8 = "SELECT EXT_SYS_ID FROM FINAL TABLE(UPDATE BLUADMIN.TEMP_CONFIG_ITEMS SET CI_TRANS_STATUS = 'COMPLETED' WHERE EXT_SYS_ID IN ("+val+") AND JOB_ID ="+currentJobId+" )";
                            var executeData8 = await runQuery(executeQuery8,[]);
                            console.log("\n\nSTEP 6.2: SYNCED STATUS UPDATED TO  COMPLETED IN TEMP_CONFIG_ITEMS TABLE AFTER COMPLETING CI_ATTRIBUTE_MAPPING OF VALID CI");
                            

                            
                        }

                        if(extSysIdExist.length>0){
                            sqlUpdate = "SELECT EXT_SYS_ID FROM FINAL TABLE( UPDATE CONFIG_ITEMS O  SET\
                            O.EXT_SYS_ID = T.EXT_SYS_ID,O.EXT_SOURCE = T.EXT_SOURCE,O.CI_CODE = T.CI_CODE,O.CI_NAME = T.CI_NAME,O.CLASS_ID =T.CLASS_ID,O.DESCRIPTION = T.DESCRIPTION,O.COMPANY_ID = T.COMPANY_ID,O.COMPANY_NAME = T.COMPANY_NAME,O.STATUS = T.STATUS,O.CATEGORY_ID = T.CATEGORY_ID,O.SUB_CATEGORY_ID =  T.SUB_CATEGORY_ID,O.METALLIC = T.METALLIC,O.ENVIRONMENT = T.ENVIRONMENT,O.GROUP_ID = T.GROUP_ID,O.GROUP_NAME = T.GROUP_NAME,O.OWNER_ID = T.OWNER_ID,O.OWNER_NAME = T.OWNER_NAME,O.LOCATION_ID = T.LOCATION_ID,O.LOCATION_NAME = T.LOCATION_NAME,O.MANUFACTURER = T.MANUFACTURER,O.DATASET = T.DATASET ,O.UPDATED_BY = T.UPDATED_BY,O.UPDATED_AT = CURRENT TIMESTAMP,O.SUPPORT_COMPANY_ID = T.SUPPORT_COMPANY_ID,O.SUPPORT_COMPANY_NAME = T.SUPPORT_COMPANY_NAME,O.BUSINESS_OWNER_ID = T.BUSINESS_OWNER_ID,O.BUSINESS_OWNER_NAME = T.BUSINESS_OWNER_NAME,O.TECHNICAL_OWNER_ID = T.TECHNICAL_OWNER_ID,O.TECHNICAL_OWNER_NAME = T.TECHNICAL_OWNER_NAME,O.ASSET_TAG = T.ASSET_TAG,O.EDITABLE = T.EDITABLE,O.SPCM_CATEGORY_ID = T.SPCM_CATEGORY_ID,O.SPCM_CATEGORY_NAME = T.SPCM_CATEGORY_NAME,O.SPCM_OFFERING_ID = T.SPCM_OFFERING_ID \
                            FROM TEMP_CONFIG_ITEMS T WHERE O.EXT_SYS_ID = T.EXT_SYS_ID AND  T.CI_TRANS_STATUS='VALID' AND T.JOB_ID = "+currentJobId+" )";
                            
                            sqlUpdateData = await runQuery(sqlUpdate,[]);

                           
                            var ciValExist = sqlUpdateData.map(key=>"'"+key.EXT_SYS_ID+"'");
                            console.log("ciValExist is : ",ciValExist);

                            //STEP :AFTER MOVING CIs WITH  VALID STATUS TO CONFIG_ITEMS TABLE, CHANGE CI_TRANS_STATUS = 'SYNCED' IN TEMP_CONFIG_ITEMS
                            var executeQuery7b = "UPDATE BLUADMIN.TEMP_CONFIG_ITEMS SET CI_TRANS_STATUS = 'SYNCED' WHERE EXT_SYS_ID IN ("+ciValExist.join(',')+") AND JOB_ID = "+currentJobId;
                            console.log("executeQuery 7b is : ",executeQuery7b);
                            var executeData7b = await runQuery(executeQuery7b,[]);
                            console.log("\n\nSTEP 5: SYNCED STATUS UPDATED IN TEMP_CONFIG_ITEMS TABLE");
                         
                            var queryMapping = 'SELECT CI_ID,ATTR_ID,"VALUE" FROM CI_ATTRIBUTE_MAPPING';
                            var mappedData = await runQuery(queryMapping,[]);
                            var attMap = await attrMappingForExistCi(mappedData,ciIdExist,attIdArr,attValArr);

                            //Code for maintaining CI in FOUNDATION table
                            console.log("\n\nSTEP 6.1: CI_ATTRIBUTE_MAPPING OF VALID CI");
                            var executeQuery8 = "UPDATE BLUADMIN.TEMP_CONFIG_ITEMS SET CI_TRANS_STATUS = 'COMPLETED' WHERE EXT_SYS_ID IN ("+ciValExist.join(',')+") AND JOB_ID ="+currentJobId;
                            var executeData8 = await runQuery(executeQuery8,[]);
                            console.log("\n\nSTEP 6.2: SYNCED STATUS UPDATED TO  COMPLETED IN TEMP_CONFIG_ITEMS TABLE AFTER COMPLETING CI_ATTRIBUTE_MAPPING OF VALID CI");
                    
                        }
                        
                        //CODE TO UPDATE CI_CODE in MAIN_ABLE
                        console.log("UPDATING CI_CODE");
                        var executeQuery = "SELECT CI_ID FROM CONFIG_ITEMS WHERE CI_CODE LIKE 'C1000'";
                        var executeData123= await runQuery(executeQuery,[]);
                        console.log("cicode executeData",executeData123);
                        var ciCodeUpdatedArr;
                        ciCodeUpdatedArr = await ciCodeUpdation(executeData123);
                        var executeQueryy = "SELECT COUNT (*) FROM FINAL TABLE( update CONFIG_ITEMS set CI_CODE = CASE  "+ciCodeUpdatedArr+" else CI_CODE end )";
                        console.log("final query for cicode updation is * is :",executeQueryy);
                        var executeDataa = await runQuery (executeQueryy,[]);
                        console.log("cicode final updation is :")
                        console.log("CI_CODE updation is done in the MAIN CONFIG_ITEMS TABLE ");

            
                }

                //}//closure for inner for loop   
                }//closure for outer for loop
              
            var queryCompletedStatus = "UPDATE JOB_PENDING SET STATUS = 'COMPLETED' WHERE JOB_ID = ? ";
            var updatingFinalStatus = await runQuery(queryCompletedStatus,[currentJobId]);
            console.log("***********CURRENT SCHEDULED JOB DONE***********");
            }//closure of if(any ci present in pending state for the current job id)
            else{
                //NO PENDING JOB TO PROCESS 
                console.log("No PENDING JOB FOR CURRENT JOB ID IS PRESENT ")
                var queryCompletedStatus = "UPDATE JOB_PENDING SET STATUS = 'COMPLETED' WHERE JOB_ID = ? ";
                var updatingFinalStatus = await runQuery(queryCompletedStatus,[currentJobId]);
                console.log("***********CURRENT SCHEDULED JOB DONE***********");
            }
        }//closure of else part
        

    }else{
        console.log("No tasks is PENDING in the JOB_PENDING");
        
    }
  
        var end = new Date() - start;
        if(currentJobId!=0){
            console.log("Execution time of the scheduler for jobid : "+currentJobId+"   is :" +end);
        }else{
            console.log("Execution time of the scheduler  is :",end);
        }
    
    }catch(error){
        var end = new Date() - start;
        if(currentJobId!=0){
            console.log("Current Job Id in the catch block is :",currentJobId);
            console.log("Error occured while processing jobs.So, close job's status with completed without success");
            var queryFailure = "UPDATE JOB_PENDING SET STATUS = 'COMPLETED WITHOUT SUCCESS'\
            WHERE JOB_ID =?";
            var failureUpdate = await runQuery(queryFailure,[currentJobId]);
            console.log("Execution time of the scheduler for jobid : "+currentJobId+"   is :" +end);
        }else{
            console.log("Execution time of the scheduler is",end);
        }
        console.log("Error is :",error);
        
    }
    
});


module.exports=j;

